# Security & Optimization TODO

## 🔴 Critical (Implement ASAP)

### 1. Fix CORS Configuration
**File:** `app/main.py:42`
**Current:**
```python
allow_origins=["*"]  # Configure this for production
```
**Fix:**
```python
allow_origins=[
    "https://yourdomain.com",
    "https://app.yourdomain.com",
    settings.cors_origins  # From environment
]
```

### 2. Add Rate Limiting
**Install:**
```bash
pip install slowapi
```
**Implementation:**
```python
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded

limiter = Limiter(key_func=get_remote_address)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# On sensitive endpoints:
@router.post("/auth/login")
@limiter.limit("5/minute")
async def login_user(...):
    ...
```

### 3. Improve PIN Security
**File:** `app/api/auth.py:154-159`
**Current:** Default PIN = last 4 digits of phone
**Fix:** Force users to set custom PIN during registration
```python
# Remove default PIN logic
# Require PIN during registration
# Add PIN strength validation (no sequential, no repeated)
```

---

## 🟡 High Priority (Within 1 Week)

### 4. Add Database Indexes
**File:** `app/db/models.py`
```python
from sqlalchemy import Index

class User(Base):
    __tablename__ = "users"
    # ... existing fields ...
    
    __table_args__ = (
        Index('ix_users_phone_number', 'phone_number'),
        Index('ix_users_email', 'email'),
    )

class PaymentMethod(Base):
    __table_args__ = (
        Index('ix_payment_methods_user_id', 'user_id'),
    )

class Transaction(Base):
    __table_args__ = (
        Index('ix_transactions_user_id', 'user_id'),
        Index('ix_transactions_created_at', 'created_at'),
    )
```

### 5. Add PostgreSQL Connection Pooling
**File:** `app/db/database.py:17-21`
```python
else:
    # PostgreSQL configuration
    engine = create_engine(
        settings.database_url,
        pool_size=20,          # Max connections in pool
        max_overflow=10,       # Max overflow connections
        pool_pre_ping=True,    # Verify connections before use
        pool_recycle=3600,     # Recycle connections after 1 hour
        echo=settings.debug
    )
```

### 6. Add Response Compression
**File:** `app/main.py`
```python
from fastapi.middleware.gzip import GZipMiddleware

app.add_middleware(GZipMiddleware, minimum_size=1000)
```

---

## 🟢 Medium Priority (Within 2 Weeks)

### 7. Implement Redis Caching
**Install:**
```bash
pip install redis aioredis
```
**Implementation:**
```python
# app/core/cache.py
import aioredis
from app.core.config import settings

redis = aioredis.from_url(
    settings.redis_url,
    encoding="utf-8",
    decode_responses=True
)

async def get_cached(key: str):
    return await redis.get(key)

async def set_cached(key: str, value: str, expire: int = 300):
    await redis.setex(key, expire, value)
```

### 8. Add HTTPS Redirect Middleware
**File:** `app/main.py`
```python
from starlette.middleware.httpsredirect import HTTPSRedirectMiddleware

if not settings.debug:
    app.add_middleware(HTTPSRedirectMiddleware)
```

### 9. Improve Error Messages
**File:** `app/api/auth.py:332`
**Current:**
```python
detail=f"Internal server error: {str(e)}"
```
**Fix:**
```python
# Log the error
logger.error(f"Registration error: {str(e)}", exc_info=True)
# Return generic message
detail="Registration failed. Please try again later."
```

### 10. Add Request ID Tracking
**File:** `app/main.py`
```python
import uuid
from starlette.middleware.base import BaseHTTPMiddleware

class RequestIDMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        request_id = str(uuid.uuid4())
        request.state.request_id = request_id
        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        return response

app.add_middleware(RequestIDMiddleware)
```

---

## 🔵 Low Priority (Within 1 Month)

### 11. Add API Versioning
**Current:** `/cb/auth/login`
**Recommended:** `/api/v1/auth/login`

### 12. Implement Health Checks
```python
@app.get("/health/live")
async def liveness():
    return {"status": "alive"}

@app.get("/health/ready")
async def readiness(db: Session = Depends(get_db)):
    # Check database connection
    try:
        db.execute("SELECT 1")
        return {"status": "ready", "database": "connected"}
    except:
        raise HTTPException(503, "Database unavailable")
```

### 13. Add Prometheus Metrics
```bash
pip install prometheus-fastapi-instrumentator
```
```python
from prometheus_fastapi_instrumentator import Instrumentator

Instrumentator().instrument(app).expose(app)
```

### 14. Implement Circuit Breaker
```bash
pip install pybreaker
```
```python
from pybreaker import CircuitBreaker

stripe_breaker = CircuitBreaker(fail_max=5, timeout_duration=60)

@stripe_breaker
def call_stripe_api():
    # Stripe API calls
    pass
```

---

## Environment Variables to Add

```bash
# .env
# CORS
CORS_ORIGINS=https://yourdomain.com,https://app.yourdomain.com

# Rate Limiting
RATE_LIMIT_ENABLED=True
RATE_LIMIT_PER_MINUTE=60

# Redis
REDIS_URL=redis://localhost:6379/0

# Security
HTTPS_ONLY=True
SECURE_COOKIES=True

# Monitoring
SENTRY_DSN=your_sentry_dsn
PROMETHEUS_ENABLED=True
```

---

## Security Checklist

### Authentication & Authorization
- [x] JWT tokens with expiration
- [x] Password hashing with bcrypt
- [ ] Rate limiting on auth endpoints
- [ ] Account lockout after failed attempts
- [ ] 2FA support (future)

### Data Protection
- [x] No sensitive data in logs
- [x] Environment variables for secrets
- [ ] Encryption at rest (database)
- [ ] Encryption in transit (HTTPS only)
- [ ] PII data masking in logs

### API Security
- [ ] CORS properly configured
- [ ] Rate limiting enabled
- [ ] Input validation on all endpoints
- [ ] SQL injection prevention (using ORM)
- [ ] XSS prevention
- [ ] CSRF protection

### Infrastructure
- [ ] HTTPS redirect
- [ ] Security headers
- [ ] Database connection pooling
- [ ] Redis for session management
- [ ] Regular security updates

---

## Quick Wins (Can Implement in 1 Hour)

1. **Fix CORS** - 5 minutes
2. **Add compression** - 2 minutes
3. **Add security headers** - 10 minutes
4. **Add request ID tracking** - 15 minutes
5. **Improve error messages** - 20 minutes
6. **Add health checks** - 10 minutes

---

## Testing After Changes

```bash
# 1. Security scan
pip install bandit
bandit -r app/

# 2. Dependency vulnerabilities
pip install safety
safety check

# 3. Load testing
pip install locust
locust -f tests/load_test.py

# 4. API testing
pytest tests/ -v --cov=app
```

---

**Priority Order:**
1. CORS Configuration
2. Rate Limiting
3. PIN Security
4. Database Indexes
5. Connection Pooling
6. Response Compression
7. Redis Caching
8. Everything else

**Estimated Total Time:** 2-3 days for high priority items
