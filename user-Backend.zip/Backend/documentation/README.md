# Customer Payment API

A comprehensive FastAPI backend for a payment system with face recognition capabilities. This system supports user authentication, face enrollment/verification, payment method management, auto-pay settings, and Stripe payment processing.

## Features

- **User Authentication**: JWT-based authentication with access and refresh tokens
- **Face Recognition**: Face enrollment and verification using face_recognition library
- **Payment Processing**: Stripe integration for payment methods and transactions
- **Auto-Pay**: Merchant-specific automatic payment approvals
- **Database**: PostgreSQL with UUID-based schema
- **Real-time**: Redis for face encoding storage and caching

## Tech Stack

- **FastAPI**: Modern Python web framework
- **PostgreSQL**: Primary database with UUID support
- **Redis**: Cache and face encoding storage
- **Stripe**: Payment processing
- **SQLAlchemy**: ORM and database migrations
- **Face Recognition**: OpenCV and face_recognition libraries
- **JWT**: Authentication tokens

## Prerequisites

- Python 3.8+
- PostgreSQL 12+
- Redis 6+
- Stripe Account (for payment processing)

## Installation

1. **Clone and navigate to the backend directory**:
   ```bash
   cd Backend
   ```

2. **Create a virtual environment**:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Set up environment variables**:
   ```bash
   cp env.example .env
   ```
   
   Edit `.env` with your configuration:
   ```env
   DATABASE_URL=postgresql://username:password@localhost:5432/customer_db
   SECRET_KEY=your-super-secret-key-here-change-in-production
   STRIPE_SECRET_KEY=sk_test_your_stripe_secret_key
   STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret
   REDIS_URL=redis://localhost:6379/0
   ```

5. **Set up PostgreSQL database**:
   ```sql
   CREATE DATABASE customer_db;
   CREATE EXTENSION IF NOT EXISTS pgcrypto;
   ```

6. **Run database migrations**:
   ```bash
   alembic upgrade head
   ```

7. **Start the development server**:
   ```bash
   python -m app.main
   ```
   
   Or with uvicorn:
   ```bash
   uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
   ```

## API Documentation

Once the server is running, visit:
- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

## API Endpoints

### Authentication

- `POST /auth/register` - Register new user
- `POST /auth/login` - Login user
- `POST /auth/refresh` - Refresh access token
- `POST /auth/logout` - Logout user

### User Management

- `GET /users/me` - Get current user profile
- `PUT /users/me` - Update user profile
- `GET /users/me/face-status` - Get face enrollment status
- `DELETE /users/me/face-enrollment` - Delete face enrollment

### Face Recognition

- `POST /face/enroll` - Enroll user face (user access)
- `POST /face/verify` - Verify face (merchant access)

### Payment Methods

- `GET /users/me/payment-methods` - Get payment methods
- `POST /users/me/payment-methods` - Add payment method
- `PUT /users/me/payment-methods/{id}` - Update payment method
- `DELETE /users/me/payment-methods/{id}` - Delete payment method

### Auto-Pay Management

- `GET /users/me/auto-pay` - Get auto-pay approvals
- `POST /users/me/auto-pay` - Create/update auto-pay approval
- `DELETE /users/me/auto-pay/{merchant_id}` - Delete auto-pay approval

### Payments

- `GET /users/me/payments` - Get payment requests
- `POST /users/me/payments` - Create payment request
- `POST /users/me/payments/{id}/approve` - Approve payment
- `POST /users/me/payments/{id}/decline` - Decline payment

### Webhooks

- `POST /users/webhook/stripe` - Stripe webhook handler

## Usage Examples

### 1. Register User

```bash
curl -X POST "http://localhost:8000/auth/register" \
  -H "Content-Type: application/json" \
  -d '{
    "phone_number": "+15551234567",
    "email": "user@example.com",
    "password": "securepassword123",
    "profile_info": {"first_name": "John", "last_name": "Doe"}
  }'
```

### 2. Login

```bash
curl -X POST "http://localhost:8000/auth/login" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "+15551234567",
    "password": "securepassword123"
  }'
```

### 3. Face Enrollment

```bash
curl -X POST "http://localhost:8000/face/enroll" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "image_base64": "base64_encoded_image_data"
  }'
```

### 4. Create Payment Request

```bash
curl -X POST "http://localhost:8000/users/me/payments" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "merchant_id": "merchant-uuid",
    "amount": 2500,
    "currency": "USD",
    "description": "Coffee",
    "face_scan_id": "user-face-uuid"
  }'
```

## Database Schema

The system uses PostgreSQL with the following main tables:

- **Users**: User accounts with face enrollment data
- **PaymentMethods**: Stripe payment methods
- **AutoPayApprovals**: Merchant-specific auto-payment settings
- **IncomingPaymentRequests**: Payment requests from merchants
- **Transactions**: Completed payment records
- **RefreshTokens**: JWT refresh token management

## Security Features

- JWT-based authentication with access and refresh tokens
- Password hashing using bcrypt
- Face liveness detection to prevent spoofing
- Stripe webhook signature verification
- CORS configuration for cross-origin requests
- Input validation using Pydantic models

## Development

### Running Tests

```bash
# Install test dependencies
pip install pytest pytest-asyncio httpx

# Run tests
pytest
```

### Database Migrations

```bash
# Create new migration
alembic revision --autogenerate -m "description"

# Apply migrations
alembic upgrade head

# Rollback migration
alembic downgrade -1
```

### Code Quality

```bash
# Format code
black .

# Check code style
flake8

# Type checking
mypy .
```

## Production Deployment

1. **Environment Setup**:
   - Set `DEBUG=False`
   - Use production database
   - Configure proper CORS origins
   - Set secure secret keys

2. **Database**:
   - Use connection pooling
   - Set up database backups
   - Configure SSL connections

3. **Redis**:
   - Use Redis Cluster for high availability
   - Configure persistence if needed

4. **Monitoring**:
   - Set up logging and monitoring
   - Configure health checks
   - Monitor Stripe webhook deliveries

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## License

This project is licensed under the MIT License.

## Support

For support and questions, please create an issue in the repository. 