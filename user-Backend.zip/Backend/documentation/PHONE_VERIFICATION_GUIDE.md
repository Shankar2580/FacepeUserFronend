# Phone Verification Setup (Email Disabled)

## Quick Setup Guide

### 1. Phone Number Format
**Important**: Phone numbers must be in **E.164 format**:

**🇺🇸 United States (+1):**
- ✅ `+15551234567` (US number - 12 digits total)
- ❌ `1234567890` (missing +1)
- ❌ `+1 (555) 123-4567` (has spaces/brackets)

**🇮🇳 India (+91):**
- ✅ `+919876543210` (India number - 13 digits total)
- ❌ `919876543210` (missing +)
- ❌ `+91 98765 43210` (has spaces)

**Other Countries:**
- ✅ `+447912345678` (UK number)
- ❌ `1234567890` (missing country code)
- ❌ `+1 (234) 567-8900` (has spaces/brackets)

### 2. Simplified Registration Flow
```
1. User enters phone number → Send SMS code
2. User enters SMS code → Verify phone  
3. User completes registration → Account created
```

**Email verification is temporarily disabled.**

### 3. Registration Fields (Simplified)
```json
{
  "full_name": "John Doe",
  "email": "john.doe@example.com", 
  "phone_number": "+1234567890",
  "password": "MyPass123!"
}
```

**Required fields:**
- ✅ **full_name**: First and last name (2+ words)
- ✅ **email**: Valid email address (required now)
- ✅ **phone_number**: E.164 format (+1234567890)
- ✅ **password**: Strong password (see requirements below)

### 4. Password Requirements
**Password must have ALL of these:**
- ✅ **At least 8 characters long**
- ✅ **At least 1 number** (0-9)
- ✅ **At least 1 letter** (a-z, A-Z)
- ✅ **At least 1 special character** (!@#$%^&*(),.?":{}|<>)

**Examples:**
- ✅ `MyPass123!` (valid)
- ✅ `SecureP@ssw0rd` (valid)
- ❌ `password` (no number, no special char)
- ❌ `12345678` (no letter, no special char)
- ❌ `Pass123` (too short)

## 🧪 **Development Mode (See OTPs)**

### Option 1: **Development Mode Bypass** (Easiest)
Add to your `.env` file:
```env
DEBUG=True
VERIFICATION_DEV_MODE=True
```

**In development mode:**
- ✅ **OTP is always: `123456`**
- ✅ **No actual SMS sent** (saves money)
- ✅ **Works with any phone number**
- ✅ **You can see OTP in console logs**

### Option 2: **Test Phone Numbers**
Use these special numbers (always accept `123456`):
- `+15005550006` (US test number)
- `+15005550001` (US test number)  
- `+1234567890` (Generic test number)

### Option 3: **Prelude.so Dashboard Logs**
When using real credentials, check OTPs in:
- [Prelude.so Dashboard > Authentications](https://app.prelude.so/authentications)
- Shows actual sent codes and verification attempts

## Prelude.so Setup (Required for Production)

1. **Create Prelude.so Account:**
   - Go to [Prelude.so Sign Up](https://app.prelude.so/sign-up)
   - Navigate to **Settings > API Keys**
   - Generate your API key

2. **Add to .env file:**
   ```env
   # For Production
   PRELUDE_API_KEY=your_prelude_api_key
   
   # For Development (bypass Prelude.so)
   DEBUG=True
   VERIFICATION_DEV_MODE=True
   ```

## API Usage

### Step 1: Send Phone Verification
```bash
curl -X POST "http://localhost:8000/verification/send-phone-code" \
  -H "Content-Type: application/json" \
  -d '{"phone_number": "+1234567890"}'
```

**Response:**
```json
{"success": true, "message": "Verification code sent to +1234567890"}
```

**Console Log (Dev Mode):**
```
🧪 DEV MODE: SMS verification sent to +1234567890 - Use code: 123456
```

### Step 2: Verify Phone Code
```bash
curl -X POST "http://localhost:8000/verification/verify-phone-code" \
  -H "Content-Type: application/json" \
  -d '{"phone_number": "+1234567890", "code": "123456"}'
```

**Response:**
```json
{"success": true, "message": "Phone number verified successfully"}
```

### Step 3: Register User (Updated Format)
```bash
curl -X POST "http://localhost:8000/auth/register" \
  -H "Content-Type: application/json" \
  -d '{
    "full_name": "John Doe",
    "email": "john.doe@example.com",
    "phone_number": "+1234567890",
    "password": "MyPass123!"
  }'
```

**Response:**
```json
{
  "user_id": "uuid",
  "full_name": "John Doe",
  "email": "john.doe@example.com",
  "phone_number": "+1234567890",
  "message": "User registered successfully. Phone number is verified."
}
```

## Testing Scenarios

### 🧪 **Development Testing** (OTP visible)
```env
# .env file
DEBUG=True
VERIFICATION_DEV_MODE=True
```
- ✅ Use any phone number
- ✅ Always use code: `123456`
- ✅ See OTP in console logs
- ✅ No SMS charges

### 🚀 **Production Testing** (Real SMS)
```env
# .env file  
DEBUG=False
VERIFICATION_DEV_MODE=False
PRELUDE_API_KEY=your_prelude_api_key
```
- ✅ Real SMS sent to your phone
- ✅ Check Prelude.so Dashboard for logs
- ✅ Use your actual phone number

### 🎯 **Hybrid Testing** (Test numbers with real Prelude.so)
- Use test numbers: `+15005550006`
- Real Prelude.so connection
- Predictable codes in Prelude.so dashboard

## Complete Registration Test

1. **Start the server:**
   ```bash
   cd Backend
   uvicorn app.main:app --reload
   ```

2. **Development Mode Test:**
   ```bash
   # Step 1: Send verification code
   curl -X POST "http://localhost:8000/verification/send-phone-code" \
     -H "Content-Type: application/json" \
     -d '{"phone_number": "+1234567890"}'
   
   # Step 2: Verify phone code
   curl -X POST "http://localhost:8000/verification/verify-phone-code" \
     -H "Content-Type: application/json" \
     -d '{"phone_number": "+1234567890", "code": "123456"}'
   
   # Step 3: Register user with strong password
   curl -X POST "http://localhost:8000/auth/register" \
     -H "Content-Type: application/json" \
     -d '{
       "full_name": "John Doe",
       "email": "john.doe@example.com", 
       "phone_number": "+1234567890",
       "password": "MyPass123!"
     }'
   ```

## Password Validation Examples

### ✅ **Valid Passwords:**
- `MyPass123!` - has letter, number, special char
- `SecureP@ssw0rd` - has all requirements
- `Hello123#` - simple but valid
- `Test1234$` - meets all criteria

### ❌ **Invalid Passwords:**
- `password` → Missing number and special char
- `PASSWORD123` → Missing special char
- `Pass123` → Too short (under 8 chars)
- `MyPassword!` → Missing number
- `12345678!` → Missing letter

## Console Logs

Watch your terminal for these logs:

```bash
# Development Mode
🧪 DEV MODE: SMS verification sent to +1234567890 - Use code: 123456
🧪 DEV MODE: Phone verification approved for +1234567890

# Production Mode  
INFO: SMS verification sent to +919876543210, status: pending
INFO: Phone verification check for +919876543210, status: approved

# Password Validation Errors
ValueError: Password must contain at least one number
ValueError: Password must contain at least one special character
```

## Error Handling

The API will return clear error messages:

```json
// Phone format error
{"detail": "Phone number must be in E.164 format (start with +)"}

// Password validation errors
{"detail": "Password must be at least 8 characters long"}
{"detail": "Password must contain at least one number"}
{"detail": "Password must contain at least one special character"}

// Name validation error
{"detail": "Please provide both first and last name"}

// Duplicate registration
{"detail": "Phone number already registered"}
{"detail": "Email already registered"}
```

## Country Code Examples

| Country | Format | Example |
|---------|--------|---------|
| USA | +1XXXXXXXXXX | +1234567890 |
| India | +91XXXXXXXXXX | +919876543210 |
| UK | +44XXXXXXXXXXX | +447912345678 |
| Canada | +1XXXXXXXXXX | +1416555123 |

## Notes

- **Development mode OTP: always `123456`**
- **Verification codes expire in 2 minutes** (production)
- **Each code can only be used once** (production)
- **Email field is now required** for registration
- **Strong password validation** enforced
- **Full name must have at least 2 words** (first + last name)
- **Rate limiting** prevents spam (built into Twilio) 