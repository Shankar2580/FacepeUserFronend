# Prelude.so Phone Verification Setup Guide

This guide explains how to set up phone verification using **Prelude.so** - a modern, cost-effective SMS verification service that replaces Firebase/Twilio.

## Why Prelude.so?

✅ **60% cost reduction** compared to Twilio  
✅ **95% successful verification** rate worldwide  
✅ **99% fraud blocked** with built-in anti-fraud protection  
✅ **Multi-routing** across 30+ providers globally  
✅ **5 messaging channels** (SMS, WhatsApp, Viber, RCS, Zalo)  
✅ **Real-time analytics** and conversion tracking  

## Prerequisites

1. **Prelude.so Account**: Sign up at [prelude.so](https://prelude.so)
2. **API Key**: Generate your API key in the Prelude dashboard

## Quick Setup

### Step 1: Get Your Prelude API Key

1. Go to [Prelude.so Sign Up](https://app.prelude.so/sign-up)
2. Create your account
3. Navigate to **Settings > API Keys**
4. Generate a **v2 API key**
5. Copy the API key (starts with `pk_` or similar)

### Step 2: Environment Configuration

Add your Prelude API key to your `.env` file:

```env
# Prelude.so Configuration (SMS Verification)
PRELUDE_API_KEY=your_prelude_api_key_here

# Development/Testing Configuration
DEBUG=True
VERIFICATION_DEV_MODE=True
```

**Where to find your API key:**
- Prelude Dashboard → Settings → API Keys

## Phone Verification Flow

The new verification process uses Prelude.so's simple 2-endpoint API:

### Step 1: Send Verification Code
```bash
POST /verification/send-phone-code
{
  "phone_number": "+1234567890"
}
```

### Step 2: Verify Code
```bash
POST /verification/verify-phone-code
{
  "phone_number": "+1234567890",
  "code": "123456"
}
```

### Step 3: Complete Registration
```bash
POST /auth/register
{
  "phone_number": "+1234567890",
  "email": "user@example.com",
  "password": "securepassword123",
  "full_name": "John Doe"
}
```

## Phone Number Format

**Required:** E.164 International Format

✅ **Correct:**
- `+1234567890` (US)
- `+919876543210` (India)  
- `+447912345678` (UK)
- `+33123456789` (France)

❌ **Incorrect:**
- `1234567890` (missing country code)
- `+1 (234) 567-8900` (has spaces/brackets)
- `(234) 567-8900` (missing +1)

## Testing Your Integration

### 🧪 Development Mode (Free Testing)

Enable development mode in your `.env`:
```env
DEBUG=True
VERIFICATION_DEV_MODE=True
```

**In development mode:**
- ✅ **OTP is always: `123456`**
- ✅ **No actual SMS sent** (saves money)
- ✅ **Works with any phone number**
- ✅ **You can see verification logs in console**

### Test Phone Numbers

Special test numbers (always accept `123456`):
- `+15005550006` (US test number)
- `+15005550001` (US test number)
- `+1234567890` (Generic test number)

### 🚀 Production Testing (Real SMS)

For production testing with real SMS:
```env
DEBUG=False
VERIFICATION_DEV_MODE=False
PRELUDE_API_KEY=your_real_api_key
```

## API Usage Examples

### Send Verification Code

```bash
curl -X POST "http://localhost:8000/verification/send-phone-code" \
  -H "Content-Type: application/json" \
  -d '{"phone_number": "+1234567890"}'
```

**Response:**
```json
{
  "success": true, 
  "message": "Verification code sent to +1234567890"
}
```

**Console Log (Dev Mode):**
```
🧪 DEV MODE: SMS verification sent to +1234567890 - Use code: 123456
```

### Verify Code

```bash
curl -X POST "http://localhost:8000/verification/verify-phone-code" \
  -H "Content-Type: application/json" \
  -d '{"phone_number": "+1234567890", "code": "123456"}'
```

**Response:**
```json
{
  "success": true,
  "message": "Phone number verified successfully"
}
```

## Complete Registration Test

1. **Start the server:**
   ```bash
   cd Backend
   uvicorn app.main:app --reload
   ```

2. **Send verification code:**
   ```bash
   curl -X POST "http://localhost:8000/verification/send-phone-code" \
     -H "Content-Type: application/json" \
     -d '{"phone_number": "+1234567890"}'
   ```

3. **Verify phone code (use 123456 in dev mode):**
   ```bash
   curl -X POST "http://localhost:8000/verification/verify-phone-code" \
     -H "Content-Type: application/json" \
     -d '{"phone_number": "+1234567890", "code": "123456"}'
   ```

4. **Register user:**
   ```bash
   curl -X POST "http://localhost:8000/auth/register" \
     -H "Content-Type: application/json" \
     -d '{
       "full_name": "John Doe",
       "email": "john.doe@example.com",
       "phone_number": "+1234567890",
       "password": "MyPass123!"
     }'
   ```

## Error Handling

The system handles various error scenarios:

- **Invalid phone number format**: Must be in E.164 format (+1234567890)
- **Invalid API key**: Check your Prelude API key
- **Expired codes**: Verification codes expire after 2 minutes
- **Wrong codes**: Invalid code error responses
- **Rate limiting**: Prelude's built-in rate limiting
- **Service unavailable**: Graceful degradation when Prelude is unavailable

## Security Features

1. **2-Minute Code Expiry**: Verification codes expire automatically
2. **Rate Limiting**: Built-in protection against abuse
3. **Fraud Detection**: Advanced AI-powered fraud prevention
4. **Global Routing**: Intelligent routing for best delivery rates
5. **Multiple Channels**: Fallback to WhatsApp, Viber, etc. when SMS fails

## Frontend Integration

Your React Native app should implement this flow:

1. **Phone Input Screen**: User enters phone → API call to send code
2. **Code Verification Screen**: User enters 6-digit code → API call to verify  
3. **Registration Form**: User completes profile → API call to register

**No changes needed** to your React Native app! The API endpoints remain the same.

## Advanced Features

### Multi-Channel Routing

Prelude automatically uses the best channel per country:
- **SMS**: Default worldwide
- **WhatsApp**: Brazil, India, Mexico
- **Viber**: Ukraine, Eastern Europe
- **RCS**: Android devices in supported regions
- **Zalo**: Vietnam

### Fraud Protection

Prelude includes 4 layers of fraud protection:
- Device fingerprinting
- Behavioral analysis  
- Network analysis
- AI-powered risk scoring

### Analytics Dashboard

Monitor your verification performance:
- Conversion rates by country
- Average delivery time
- Cost per verification
- Fraud detection metrics

## Migration from Firebase/Twilio

### What Changed
- ✅ **SMS sending**: Now handled by Prelude.so
- ✅ **Code verification**: Now handled by Prelude.so  
- ✅ **Phone validation**: Enhanced validation
- ✅ **Fraud protection**: Advanced AI protection
- ✅ **Global routing**: Multi-provider routing

### What Stayed the Same
- ✅ **API endpoints**: Same URLs and request format
- ✅ **Database structure**: No changes needed
- ✅ **User registration**: Same flow
- ✅ **Development mode**: Still works for testing

## Cost Comparison

### Prelude.so Pricing
- **Better rates**: 30-60% cheaper than Twilio
- **No markup**: Direct wholesale pricing
- **No monthly fees**: Pay only for what you use
- **Free tier**: Generous free verification credits

### Benefits over Firebase/Twilio
- ✅ **Lower cost per SMS**
- ✅ **Better global delivery rates**
- ✅ **Built-in fraud protection**
- ✅ **Multi-channel support**
- ✅ **Real-time analytics**
- ✅ **No account setup fees**

## Production Deployment

### Environment Variables for Production
```env
# Production Configuration
DEBUG=False
VERIFICATION_DEV_MODE=False
PRELUDE_API_KEY=your_production_api_key

# Database
DATABASE_URL=your_production_database_url

# Other settings
SECRET_KEY=your_production_secret_key
```

### Cloud Deployment Notes

For platforms like Render, Heroku, etc., set your environment variables:
- `PRELUDE_API_KEY`: Your production Prelude API key
- `VERIFICATION_DEV_MODE`: Set to `False`
- `DEBUG`: Set to `False`

## Troubleshooting

### Common Issues

1. **"PRELUDE_API_KEY not found"**
   - Check your `.env` file has the API key
   - Verify the API key is valid in Prelude dashboard
   - Ensure the key starts with the correct prefix

2. **"Invalid phone number format"**
   - Phone numbers must be in E.164 format (+1234567890)
   - No spaces, brackets, or special characters
   - Must include country code with +

3. **"Failed to send verification code"**
   - Check your Prelude account credits/billing
   - Verify the phone number is valid
   - Check network connectivity

4. **"Invalid or expired verification code"**
   - Codes expire after 2 minutes
   - Each code can only be used once
   - Make sure you're using the latest code received

### Getting Help

1. Check Prelude dashboard for delivery logs
2. Review application logs for detailed error messages
3. Verify your API key and account status
4. Contact Prelude support via their dashboard

## Next Steps

After implementing Prelude verification, consider:

1. **Enhanced Fraud Protection**: Enable additional fraud signals
2. **Multi-Channel Setup**: Configure WhatsApp, Viber for specific regions
3. **Analytics Integration**: Set up conversion tracking
4. **Custom Templates**: Brand your verification messages
5. **Webhook Integration**: Set up real-time delivery notifications

---

## Summary

Prelude.so provides a superior phone verification experience with:
- 🚀 **Easy migration** from Firebase/Twilio
- 💰 **Significant cost savings** (30-60% reduction)
- 🛡️ **Advanced fraud protection**
- 🌍 **Global reach** with multi-provider routing
- 📊 **Real-time analytics** and insights

Your phone verification is now powered by Prelude.so! 🎉 