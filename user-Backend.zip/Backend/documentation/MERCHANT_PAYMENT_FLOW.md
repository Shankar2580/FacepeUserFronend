# Merchant Payment Request Flow

This document explains the complete merchant-to-user payment request system with real Stripe payment processing.

## 🏗️ Architecture Overview

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Merchant      │    │   Your API      │    │   User App      │
│   Terminal      │    │   (Backend)     │    │   (Frontend)    │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         │ 1. Create Payment     │                       │
         │    Request            │                       │
         ├──────────────────────►│                       │
         │                       │                       │
         │                       │ 2. Store Request     │
         │                       │    in Database       │
         │                       │                       │
         │                       │ 3. Send Push         │
         │                       │    Notification      │
         │                       ├──────────────────────►│
         │                       │                       │
         │                       │ 4. User Views        │
         │                       │    Payment Requests  │
         │                       │◄──────────────────────┤
         │                       │                       │
         │                       │ 5. User Approves     │
         │                       │    Payment           │
         │                       │◄──────────────────────┤
         │                       │                       │
         │                       │ 6. Process with      │
         │                       │    Stripe            │
         │                       ├─────────────────────► │
         │                       │                      Stripe
         │ 7. Payment Result     │                       │
         │◄──────────────────────┤                       │
         │                       │                       │
```

## 🚀 Quick Start

### 1. Set Up Stripe Configuration

```bash
cd Backend
python setup_stripe_env.py
```

This will guide you through setting up your Stripe API keys.

### 2. Start the Backend Server

```bash
python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### 3. Test the Complete Flow

```bash
python test_merchant_payment_flow.py
```

## 📡 API Endpoints

### Merchant Endpoints

#### Create Payment Request
```http
POST /payment-requests
Content-Type: application/json

{
  "user_id": "user_123",
  "merchant_id": "merchant_starbucks_001", 
  "amount": 4.75,
  "currency": "USD",
  "description": "Grande Latte + Blueberry Muffin",
  "face_scan_id": "face_scan_12345",
  "stripe_payment_intent_id": null,
  "merchant_payment_request_id": "starbucks_order_789",
  "merchant_name": "Starbucks Coffee"
}
```

**Response:**
```json
{
  "success": true,
  "request_id": "uuid-here",
  "status": "PENDING",
  "message": "Payment request created for user@example.com",
  "user_notified": true
}
```

### User Endpoints

#### Get Payment Requests
```http
GET /users/me/payment-requests
Authorization: Bearer <user_token>
```

**Response:**
```json
[
  {
    "id": "uuid-here",
    "merchant_name": "Starbucks",
    "amount": 4.75,
    "currency": "USD", 
    "description": "Grande Latte + Blueberry Muffin",
    "status": "PENDING",
    "expires_at": "2024-01-15T10:30:00Z",
    "created_at": "2024-01-15T09:30:00Z"
  }
]
```

#### Approve Payment Request
```http
POST /users/me/payments/{request_id}/approve
Authorization: Bearer <user_token>
```

**Response:**
```json
{
  "status": "COMPLETED",
  "transaction_id": "pi_stripe_payment_intent_id"
}
```

#### Decline Payment Request
```http
POST /users/me/payments/{request_id}/decline
Authorization: Bearer <user_token>
```

**Response:**
```json
{
  "status": "DECLINED"
}
```

## 💳 Stripe Integration

### Payment Processing Flow

1. **Payment Intent Creation**: When user approves, system creates Stripe PaymentIntent
2. **Marketplace Fees**: Automatically calculates 2.9% + 30¢ application fee
3. **Off-Session Payments**: Uses saved payment methods for seamless experience
4. **Error Handling**: Comprehensive error handling for card declines, insufficient funds, etc.

### Marketplace Model

```javascript
// Example Stripe PaymentIntent with marketplace fee
{
  "amount": 475,  // $4.75 in cents
  "currency": "usd",
  "application_fee_amount": 44,  // 2.9% + 30¢ = 44¢
  "customer": "cus_customer_id",
  "payment_method": "pm_saved_card",
  "confirm": true,
  "off_session": true
}
```

### Connect Integration (Optional)

For full marketplace functionality, you can integrate Stripe Connect:

1. **Merchant Onboarding**: Use Stripe Connect Express for merchant accounts
2. **Direct Charges**: Charge customers and transfer to merchant accounts
3. **Split Payments**: Automatically split payments between platform and merchants

## 🔧 Configuration

### Environment Variables

```bash
# Stripe Configuration
STRIPE_SECRET_KEY=sk_test_...
STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...

# Database
DATABASE_URL=sqlite:///./customer_db.db

# JWT
SECRET_KEY=your-secret-key
ACCESS_TOKEN_EXPIRE_MINUTES=30
```

### Marketplace Fee Configuration

Currently set to **2.9% + 30¢** per transaction. To modify:

```python
# In app/stripe_service.py
application_fee = int((payment_request.amount * 0.029) + 30)
```

## 🧪 Testing

### Test Data

The system includes sample merchants:
- `merchant_starbucks_001` → "Starbucks"
- `merchant_amazon_001` → "Amazon" 
- `merchant_uber_001` → "Uber"
- `merchant_netflix_001` → "Netflix"

### Test Cards (Stripe Test Mode)

```
Success: 4242424242424242
Decline: 4000000000000002
Insufficient Funds: 4000000000009995
```

### Manual Testing

1. **Create Payment Request**:
   ```bash
   curl -X POST http://localhost:8000/payment-requests \
     -H "Content-Type: application/json" \
     -d '{
       "user_id": "user_123",
       "merchant_id": "merchant_starbucks_001",
       "amount": 4.75,
       "currency": "USD",
       "description": "Test Payment",
       "face_scan_id": "test_face_123",
       "merchant_payment_request_id": "test_001",
       "merchant_name": "Test Merchant"
     }'
   ```

2. **Check Frontend**: Payment should appear in user's app home page

3. **Approve Payment**: Click approve button in frontend

## 🔒 Security Considerations

### Authentication
- Merchant endpoints should be secured with API keys
- User endpoints require JWT authentication
- Face scan validation for payment requests

### Stripe Security
- Never expose secret keys in frontend
- Use webhooks for payment confirmations
- Implement idempotency for payment requests

### Data Protection
- Encrypt sensitive payment data
- Log all payment attempts for audit
- Implement rate limiting on payment endpoints

## 🚨 Error Handling

### Common Error Scenarios

1. **User Not Found**: 404 when user_id doesn't exist
2. **Card Declined**: Stripe returns card_error with user-friendly message
3. **Insufficient Funds**: Specific error code for insufficient funds
4. **Network Issues**: Retry logic for temporary failures

### Error Response Format

```json
{
  "success": false,
  "error": "Card error: Your card was declined",
  "error_code": "card_declined",
  "action": "try_different_card"
}
```

## 📊 Monitoring & Analytics

### Key Metrics to Track

- Payment request creation rate
- Approval/decline rates
- Payment success rates
- Average transaction amounts
- Merchant performance

### Webhook Events

Set up webhooks for:
- `payment_intent.succeeded`
- `payment_intent.payment_failed`
- `charge.dispute.created`

## 🔄 Deployment

### Production Checklist

- [ ] Set up production Stripe account
- [ ] Configure webhook endpoints
- [ ] Set up monitoring and alerting
- [ ] Implement proper logging
- [ ] Set up database backups
- [ ] Configure SSL certificates
- [ ] Set up rate limiting
- [ ] Implement fraud detection

### Environment Setup

```bash
# Production environment variables
STRIPE_SECRET_KEY=sk_live_...
STRIPE_PUBLISHABLE_KEY=pk_live_...
DATABASE_URL=postgresql://...
DEBUG=false
```

## 📚 Additional Resources

- [Stripe Connect Documentation](https://stripe.com/docs/connect)
- [Payment Intents API](https://stripe.com/docs/payments/payment-intents)
- [Stripe Webhooks](https://stripe.com/docs/webhooks)
- [Marketplace Payments Guide](https://stripe.com/docs/connect/charges)

## 🤝 Support

For questions about this implementation:

1. Check the test scripts for examples
2. Review the API documentation
3. Test with Stripe's test cards
4. Monitor webhook events in Stripe Dashboard

---

**Note**: This implementation provides a complete foundation for merchant payment requests with real Stripe processing. Customize the marketplace fees, error handling, and business logic according to your specific requirements. 