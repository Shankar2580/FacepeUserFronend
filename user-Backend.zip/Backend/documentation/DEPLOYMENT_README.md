# Payment Backend API - Deployment Guide

## 🚀 Quick Start

This is a FastAPI backend for a payment system with face recognition capabilities. Follow this guide to deploy the application to GitHub and Render.

## 📋 Prerequisites

- Python 3.8+
- Git
- GitHub account
- Render account (for deployment)
- Stripe account (for payment processing)
- Prelude.so account (for SMS verification, optional)

## 🛠️ Setup Instructions

### 1. Local Development Setup

Run the setup script to prepare your development environment:

```powershell
# Run this in PowerShell
.\setup-dev-environment.ps1
```

This script will:
- Create a Python virtual environment
- Install all dependencies
- Create a `.env` file from the template
- Set up the database

### 2. Configure Environment Variables

Edit the `.env` file with your actual configuration:

```env
# Database (use PostgreSQL for production)
DATABASE_URL=postgresql://user:password@localhost:5432/payment_db

# Security
SECRET_KEY=your-very-long-secret-key-here
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30

# Stripe Configuration
STRIPE_PUBLISHABLE_KEY=pk_test_your_key
STRIPE_SECRET_KEY=sk_test_your_key
STRIPE_WEBHOOK_SECRET=whsec_your_secret

# Prelude.so (Optional SMS Verification)
PRELUDE_API_KEY=your_prelude_api_key
```

### 3. Test Local Setup

```powershell
# Start the development server
python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Visit `http://localhost:8000/docs` to view the API documentation.

## 🌐 GitHub Deployment

### Initial Setup

1. Create a new repository on GitHub
2. Run the deployment script:

```powershell
# Replace with your actual GitHub repository URL
.\deploy-to-github.ps1 -GitHubRepoUrl "https://github.com/yourusername/your-repo.git"
```

### Updating Code

To push updates to GitHub:

```powershell
.\update-github.ps1 -CommitMessage "Your commit message here"
```

## ☁️ Render Deployment

### Option 1: Using render.yaml (Recommended)

1. Connect your GitHub repository to Render
2. The `render.yaml` file will automatically configure:
   - Web service with Gunicorn
   - PostgreSQL database
   - Environment variables

### Option 2: Manual Setup

1. Create a new Web Service on Render
2. Connect your GitHub repository
3. Configure the following settings:

**Build Command:**
```bash
pip install -r requirements.txt
```

**Start Command:**
```bash
gunicorn app.main:app --host 0.0.0.0 --port $PORT --workers 4 --worker-class uvicorn.workers.UvicornWorker
```

**Environment Variables:**
- `DATABASE_URL`: Your PostgreSQL connection string
- `SECRET_KEY`: A secure secret key
- `STRIPE_SECRET_KEY`: Your Stripe secret key
- `STRIPE_PUBLISHABLE_KEY`: Your Stripe publishable key
- `STRIPE_WEBHOOK_SECRET`: Your Stripe webhook secret
- `DEBUG`: `false`
- `PRELUDE_API_KEY`: Your Prelude.so API key (optional)

## 🗄️ Database Setup

### Development (SQLite)
The application will automatically create a SQLite database for development.

### Production (PostgreSQL)
1. Create a PostgreSQL database on Render
2. Update the `DATABASE_URL` environment variable
3. Run migrations:
```bash
alembic upgrade head
```

## 🔐 Security Configuration

### Stripe Webhooks
1. Configure webhooks in your Stripe dashboard
2. Set the endpoint URL to: `https://your-app.onrender.com/webhook/stripe`
3. Add the webhook secret to your environment variables

### CORS Configuration
Update the CORS origins in `app/main.py` for production:

```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://your-frontend-domain.com"],  # Replace with your frontend URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

## 📁 Project Structure

```
Backend/
├── app/
│   ├── routers/           # API route handlers
│   ├── main.py           # FastAPI application
│   ├── models.py         # Database models
│   ├── schemas.py        # Pydantic schemas
│   ├── database.py       # Database configuration
│   ├── config.py         # Application configuration
│   └── services/         # Business logic services
├── alembic/              # Database migrations
├── requirements.txt      # Python dependencies
├── .gitignore           # Git ignore rules
├── render.yaml          # Render configuration
└── *.ps1                # PowerShell deployment scripts
```

## 🧪 Testing

Run the test suite:

```powershell
# Run specific tests
python test_payment_flow.py
python test_webhook_integration.py

# Run all tests
pytest
```

## 🔧 Common Issues

### 1. Face Recognition Dependencies
If you encounter issues with face recognition on Render:
- The `opencv-python-headless` package is used for better server compatibility
- Consider using a different plan with more resources

### 2. Database Migrations
If migrations fail:
```bash
# Reset migrations (development only)
alembic downgrade base
alembic upgrade head
```

### 3. Environment Variables
Make sure all required environment variables are set in your deployment platform.

## 📚 API Documentation

Once deployed, your API documentation will be available at:
- Swagger UI: `https://your-app.onrender.com/docs`
- ReDoc: `https://your-app.onrender.com/redoc`

## 🤝 Team Collaboration

### For New Team Members

1. Clone the repository:
```bash
git clone https://github.com/yourusername/your-repo.git
cd your-repo
```

2. Run the setup script:
```powershell
.\setup-dev-environment.ps1
```

3. Configure your `.env` file with development settings

### Making Changes

1. Create a feature branch:
```bash
git checkout -b feature/your-feature-name
```

2. Make your changes and test locally

3. Push changes:
```powershell
.\update-github.ps1 -CommitMessage "Add your feature description"
```

4. Create a pull request on GitHub

## 📞 Support

If you encounter any issues:
1. Check the logs in Render dashboard
2. Verify all environment variables are set correctly
3. Ensure your database is properly configured
4. Check the API documentation for correct endpoint usage

## 🔄 Continuous Deployment

Render automatically deploys when you push to your main branch. To set up automatic deployments:

1. Connect your GitHub repository to Render
2. Enable auto-deploy on the main branch
3. Configure build and start commands as specified above

---

**Note:** Remember to never commit sensitive information like API keys or database passwords to your repository. Always use environment variables for sensitive configuration. 