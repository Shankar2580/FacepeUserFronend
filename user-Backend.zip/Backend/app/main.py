import logging

from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
import uvicorn
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded

from app.core.config import settings
from app.services.deletion_scheduler import (
    shutdown_deletion_scheduler,
    start_deletion_scheduler,
)
from app.db.database import create_tables
from app.core.rate_limit import limiter
from app.api import (
    auth, users, payment_methods, 
    autopay, payments, payment_requests, merchant_payment_requests, verification, transactions, face_registration, webhooks
)


logging.basicConfig(
    level=logging.DEBUG if settings.debug else logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan events"""
    import logging
    logger = logging.getLogger(__name__)
    
    # Startup
    logger.info("Starting up Customer Payment API...")
    create_tables()
    logger.info("Database tables created/verified")
    start_deletion_scheduler()
    
    yield
    
    # Shutdown
    logger.info("Shutting down Customer Payment API...")
    shutdown_deletion_scheduler()

# Create FastAPI application
app = FastAPI(
    title="Payment System with Face Recognition",
    description="A comprehensive payment system API with face recognition capabilities",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

# Add rate limiting
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure this for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global exception handler
@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": "HTTP_ERROR",
            "message": exc.detail,
            "status_code": exc.status_code
        }
    )

@app.exception_handler(Exception)
async def general_exception_handler(request, exc):
    import logging
    logger = logging.getLogger(__name__)
    logger.error(f"Unhandled exception: {type(exc).__name__}", exc_info=True)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "error": "INTERNAL_SERVER_ERROR",
            "message": "An unexpected error occurred"
        }
    )

# Health check endpoint
@app.get("/cb/health")
@app.get("/cb/health")
def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": settings.app_name,
        "version": settings.app_version
    }


# Root endpoint
@app.get("/cb/")
@app.get("/cb/")
def root():
    """Root endpoint"""
    return {
        "message": "Payment System API",
        "version": settings.app_version,
        "docs": "/docs"
    }


# Include routers
app.include_router(auth.router, prefix="/cb")
app.include_router(users.router, prefix="/cb")
app.include_router(payment_methods.router, prefix="/cb")
app.include_router(autopay.router, prefix="/cb")
app.include_router(transactions.router, prefix="/cb")
app.include_router(payments.router, prefix="/cb")
app.include_router(payment_requests.router, prefix="/cb")
app.include_router(merchant_payment_requests.router, prefix="/cb")
app.include_router(face_registration.router, prefix="/cb")
app.include_router(verification.router, prefix="/cb")
app.include_router(webhooks.router, prefix="/cb")

# Legacy router includes (kept for compatibility if needed, but prefixing is recommended)
# app.include_router(verification.router) 
# app.include_router(auth.router)
# app.include_router(users.router)
# app.include_router(payment_methods.router)
# app.include_router(auto_pay.router)
# app.include_router(autopay.router)
# app.include_router(transactions.router)
# app.include_router(payments.router)
# app.include_router(payment_requests.router)
# app.include_router(merchant_payment_requests.router)
# app.include_router(webhooks.router)
# app.include_router(face_registration.router)


if __name__ == "__main__":
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.debug,
        log_level="debug" if settings.debug else "info"
    ) 