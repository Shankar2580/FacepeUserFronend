from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
import logging

from app.db.database import get_db
from app.db.models import User
from app.core.security import verify_token, TokenData
from app.services.stripe_service import stripe_service, StripeService
from app.services.webhook_service import webhook_service, WebhookService

security = HTTPBearer()

def get_stripe_service() -> StripeService:
    """Dependency provider that returns the singleton StripeService instance."""
    return stripe_service

def get_webhook_service() -> WebhookService:
    """Dependency provider that returns the singleton WebhookService instance."""
    return webhook_service

def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db)
) -> User:
    """Get the current authenticated user"""
    logger = logging.getLogger(__name__)
    
    try:
        logger.info("Authenticating user with token")
        token_data = verify_token(credentials.credentials)
        logger.info(f"Token verified for user_id: {token_data.user_id}")
        
        user = db.query(User).filter(User.id == token_data.user_id).first()
        if user is None:
            logger.error(f"User not found in database for user_id: {token_data.user_id}")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="User not found",
                headers={"WWW-Authenticate": "Bearer"},
            )
        
        logger.info(f"User authenticated successfully: {user.email}")
        return user
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error during authentication: {str(e)}")
        logger.error(f"Error type: {type(e).__name__}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication failed",
            headers={"WWW-Authenticate": "Bearer"},
        )

def get_current_merchant(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> TokenData:
    """Get the current authenticated merchant"""
    token_data = verify_token(credentials.credentials)
    if token_data.role != "merchant":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Merchant access required"
        )
    return token_data 