#!/usr/bin/env python3
"""
Webhook service to notify Merchant Backend about payment status changes
"""
import httpx
import json
import hmac
import hashlib
import time
import logging
from datetime import datetime
from typing import Dict, Any, Optional
from app.db.models import IncomingPaymentRequest, User
from app.core.config import Settings
from app.db.database import get_db
from sqlalchemy.orm import Session

settings = Settings()

logger = logging.getLogger(__name__)


class WebhookService:
    def __init__(self):
        # Merchant Backend webhook endpoint - use local nginx proxy for development
        self.merchant_webhook_url = settings.merchant_webhook_url   
        self.timeout = 10
        self.webhook_secret = settings.merchant_webhook_secret
        logger.info(f"WebhookService initialized with secret: {self.webhook_secret[:10]}...{self.webhook_secret[-10:]}")
        logger.info(f"Webhook URL: {self.merchant_webhook_url}")
    
    def generate_signature(self, payload: str, timestamp: str) -> str:
        """
        Generate HMAC-SHA256 signature for webhook security
        
        Args:
            payload: JSON payload as string
            timestamp: Unix timestamp as string
            
        Returns:
            Signature in format: t=timestamp,v1=signature
        """
        message = f"{timestamp}.{payload}"
        signature = hmac.new(
            self.webhook_secret.encode(),
            message.encode(),
            hashlib.sha256
        ).hexdigest()
        return f"t={timestamp},v1={signature}"
    
    def _get_customer_name(self, user_id: str) -> str:
        """
        Get customer's full name from database
        
        Args:
            user_id: User ID to lookup
            
        Returns:
            Customer's full name or "Customer" as fallback
        """
        try:
            # Get database session
            db = next(get_db())
            
            # Find user by ID
            user = db.query(User).filter(User.id == user_id).first()
            
            if user and user.full_name:
                return user.full_name
            else:
                return "Customer"  # Fallback if no name found
                
        except Exception as e:
            logger.error(f"Error fetching customer name: {e}")
            return "Customer"  # Fallback on error
        finally:
            db.close()
        
    async def notify_merchant_backend(
        self, 
        payment_request: IncomingPaymentRequest, 
        status: str,
        transaction_id: Optional[str] = None,
        failure_reason: Optional[str] = None,
        failure_message: Optional[str] = None
    ) -> bool:
        """Send status update to Merchant Backend
        
        Args:
            payment_request: The payment request object
            status: Status to send ("COMPLETED", "DECLINED", "FAILED")
            transaction_id: Optional transaction ID for successful payments
            failure_reason: Optional failure reason code (e.g., "card_declined", "insufficient_funds")
            failure_message: Optional human-readable failure message
            
        Returns:
            bool: True if notification was successful, False otherwise
        """
        
        # Get customer's full name
        customer_name = self._get_customer_name(payment_request.user_id)
        
        # Prepare webhook data
        webhook_data = {
            "payment_request_id": payment_request.merchant_payment_request_id or payment_request.id,  # Use merchant's original ID if available
            "merchant_payment_request_id": payment_request.merchant_payment_request_id,  # Also send as separate field for clarity
            "user_id": payment_request.user_id,
            "customer_name": customer_name,  # Include customer's real name
            "merchant_id": payment_request.merchant_id,
            "status": status,
            "stripe_payment_intent_id": payment_request.stripe_payment_intent_id,
            "amount": payment_request.amount,  # In cents
            "currency": payment_request.currency,
            "description": payment_request.description,
            "updated_at": datetime.utcnow().isoformat()
        }
        
        # Add transaction ID for successful payments
        if transaction_id:
            webhook_data["transaction_id"] = transaction_id
        
        # Add failure information for failed/declined payments
        if failure_reason:
            webhook_data["failure_reason"] = failure_reason
        if failure_message:
            webhook_data["failure_message"] = failure_message
            
        logger.info(f"Sending webhook to Merchant Backend - Status: {status}, Payment ID: {payment_request.id}, Amount: ${payment_request.amount/100:.2f}")
        if failure_reason:
            logger.info(f"   → Failure reason: {failure_reason} - {failure_message or 'No message'}")
        
        try:
            # Generate signature for webhook security
            # IMPORTANT: Sign the exact payload that will be sent
            payload = json.dumps(webhook_data, separators=(',', ':'))
            timestamp = str(int(time.time()))
            signature = self.generate_signature(payload, timestamp)
            
            logger.info(f"🔐 Webhook signature generated")
            logger.info(f"   → Using secret: {self.webhook_secret[:10]}...{self.webhook_secret[-10:]}")
            logger.info(f"   → Timestamp: {timestamp}")
            logger.info(f"   → Payload length: {len(payload)} bytes")
            logger.info(f"   → Signature: {signature}")
            logger.info(f"   → Payload sent: {payload}")
            
            # Send webhook notification with signature using async httpx
            # Use content= instead of json= to send the exact signed payload
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.post(
                    self.merchant_webhook_url,
                    content=payload,
                    headers={
                        "Content-Type": "application/json",
                        "User-Agent": "CustomerPaymentService/1.0",
                        "X-Webhook-Signature": signature,
                        "X-Webhook-Timestamp": timestamp
                    }
                )
            
            if response.status_code == 200:
                logger.info(f"✅ Successfully notified merchant: {status}")
                return True
            else:
                logger.error(f"❌ Failed to notify merchant: HTTP {response.status_code}")
                logger.error(f"   → URL: {self.merchant_webhook_url}")
                logger.error(f"   → Headers sent: X-Webhook-Signature={signature[:50]}..., X-Webhook-Timestamp={timestamp}")
                try:
                    error_data = response.json()
                    logger.error(f"   → Error details: {error_data}")
                except:
                    logger.error(f"   → Raw response: {response.text}")
                return False
                
        except httpx.ConnectError:
            logger.error("Webhook error: Could not connect to Merchant Backend")
            return False
            
        except httpx.TimeoutException:
            logger.error(f"Webhook error: Timeout after {self.timeout} seconds")
            return False
            
        except Exception as e:
            logger.error(f"Webhook error: {e}", exc_info=True)
            return False
    
    async def notify_payment_completed(
        self, 
        payment_request: IncomingPaymentRequest, 
        transaction_id: str
    ) -> bool:
        """Notify merchant that payment was completed successfully"""
        
        try:
            return await self.notify_merchant_backend(payment_request, "COMPLETED", transaction_id)
        except Exception as e:
            logger.error(f"Error in notify_payment_completed: {e}", exc_info=True)
            return False
    
    async def notify_payment_declined(
        self, 
        payment_request: IncomingPaymentRequest,
        decline_reason: Optional[str] = None
    ) -> bool:
        """Notify merchant that payment was declined by user"""
        
        try:
            return await self.notify_merchant_backend(
                payment_request, 
                "DECLINED",
                failure_reason="user_declined",
                failure_message=decline_reason or "Customer declined the payment"
            )
        except Exception as e:
            logger.error(f"Error in notify_payment_declined: {e}", exc_info=True)
            return False
    
    async def notify_payment_failed(
        self, 
        payment_request: IncomingPaymentRequest,
        failure_reason: Optional[str] = None,
        failure_message: Optional[str] = None
    ) -> bool:
        """Notify merchant that payment failed
        
        Args:
            payment_request: The payment request
            failure_reason: Reason code (e.g., "card_declined", "insufficient_funds", "expired_card")
            failure_message: Human-readable error message
        """
        
        try:
            return await self.notify_merchant_backend(
                payment_request, 
                "FAILED",
                failure_reason=failure_reason or "payment_processing_error",
                failure_message=failure_message or "Payment processing failed"
            )
        except Exception as e:
            logger.error(f"Error in notify_payment_failed: {e}", exc_info=True)
            return False


# Global webhook service instance
webhook_service = WebhookService() 