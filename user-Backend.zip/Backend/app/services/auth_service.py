from sqlalchemy.orm import Session
from typing import Optional, Dict, Any
from datetime import datetime, timedelta

from app.db.models import User, RefreshToken
from app.core.security import (
    verify_password,
    create_access_token,
    create_refresh_token_string,
    verify_token,
)
from app.core.config import settings
from jose import jwt


class AuthService:
    def authenticate_user(self, identifier: str, password: str, db: Session) -> Optional[User]:
        """Authenticate a user by phone number or email and password"""
        user = db.query(User).filter(User.phone_number == identifier).first()
        if not user:
            identifier_lower = identifier.lower()
            user = db.query(User).filter(User.email == identifier_lower).first()

        if not user or not verify_password(password, user.password_hash):
            return None
        return user

    def create_tokens_for_user(self, user: User, db: Session) -> Dict[str, Any]:
        """Create both access and refresh tokens for a user"""
        access_token_expires = timedelta(minutes=settings.access_token_expire_minutes)
        access_token = create_access_token(
            data={"user_id": str(user.id), "role": "user"},
            expires_delta=access_token_expires,
        )
        
        refresh_token_str, expires_at = create_refresh_token_string(user.id, db)
        
        db_token = RefreshToken(
            user_id=user.id,
            token=refresh_token_str,
            expires_at=expires_at
        )
        db.add(db_token)
        db.commit()

        return {
            "access_token": access_token,
            "refresh_token": refresh_token_str,
            "token_type": "bearer",
            "expires_in": settings.access_token_expire_minutes * 60,
        }

    def validate_refresh_token(self, token: str, db: Session) -> Optional[User]:
        """Validate a refresh token and return the associated user"""
        try:
            payload = jwt.decode(token, settings.secret_key, algorithms=[settings.algorithm])
            user_id = payload.get("user_id")
            token_type = payload.get("type")

            if not user_id or token_type != "refresh":
                return None

            db_token = (
                db.query(RefreshToken)
                .filter(
                    RefreshToken.token == token,
                    RefreshToken.is_revoked == False,
                    RefreshToken.expires_at > datetime.utcnow(),
                )
                .first()
            )

            if not db_token:
                return None

            user = db.query(User).filter(User.id == user_id).first()
            return user

        except jwt.ExpiredSignatureError:
            return None
        except jwt.JWTError:
            return None

    def revoke_refresh_token(self, token: str, db: Session) -> bool:
        """Revoke a refresh token"""
        db_token = db.query(RefreshToken).filter(RefreshToken.token == token).first()
        if db_token:
            db_token.is_revoked = True
            db.commit()
            return True
        return False


auth_service = AuthService()
