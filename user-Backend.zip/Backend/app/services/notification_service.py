import json
from typing import Dict, Any, Optional, List
from sqlalchemy.orm import Session
from app.db.models import User, Notification
from app.schemas.notification import NotificationCreate, NotificationType
import httpx
import asyncio
from datetime import datetime
import logging
from app.core.config import Settings

settings = Settings()

logger = logging.getLogger(__name__)

class NotificationService:
    """Service for handling notifications and push notifications"""
    
    def __init__(self):
        # Expo Push Notifications endpoint
        self.expo_push_url = settings.expo_push_url
        
    async def create_notification(
        self, 
        db: Session, 
        user_id: str, 
        title: str, 
        body: str, 
        notification_type: NotificationType,
        data: Optional[Dict[str, Any]] = None,
        send_push: bool = True
    ) -> Notification:
        """Create a notification and optionally send push notification"""
        
        # Create notification in database
        notification = Notification(
            user_id=user_id,
            title=title,
            body=body,
            type=notification_type.value,
            data=json.dumps(data) if data else None
        )
        
        db.add(notification)
        db.commit()
        db.refresh(notification)
        
        # Send push notification if enabled
        if send_push:
            user = db.query(User).filter(User.id == user_id).first()
            if user and user.push_notifications_enabled and user.expo_push_token:
                await self.send_push_notification(
                    expo_token=user.expo_push_token,
                    title=title,
                    body=body,
                    data=data
                )
                notification.sent_at = datetime.utcnow()
                db.commit()
        
        return notification
    
    async def send_push_notification(
        self,
        expo_token: str,
        title: str,
        body: str,
        data: Optional[Dict[str, Any]] = None
    ) -> bool:
        """Send push notification via Expo Push API"""
        
        if not expo_token or not expo_token.startswith('ExponentPushToken'):
            logger.warning(f"Invalid Expo push token: {expo_token}")
            return False
        
        payload = {
            "to": expo_token,
            "title": title,
            "body": body,
            "sound": "default",
            "badge": 1
        }
        
        if data:
            payload["data"] = data
        
        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    self.expo_push_url,
                    json=payload,
                    headers={
                        "Accept": "application/json",
                        "Content-Type": "application/json"
                    },
                    timeout=10.0
                )
                
                if response.status_code == 200:
                    result = response.json()
                    if result.get("data", {}).get("status") == "ok":
                        logger.info(f"Push notification sent successfully to {expo_token}")
                        return True
                    else:
                        logger.error(f"Expo push error: {result}")
                        return False
                else:
                    logger.error(f"Failed to send push notification: {response.status_code} - {response.text}")
                    return False
                    
        except Exception as e:
            logger.error(f"Error sending push notification: {str(e)}")
            return False
    
    async def notify_payment_request(
        self, 
        db: Session, 
        user_id: str, 
        merchant_name: str, 
        amount: float,
        request_id: str
    ):
        """Send notification for new payment request"""
        
        title = "Payment Request"
        body = f"{merchant_name} is requesting ${amount:.2f}"
        
        await self.create_notification(
            db=db,
            user_id=user_id,
            title=title,
            body=body,
            notification_type=NotificationType.PAYMENT_REQUEST,
            data={
                "request_id": request_id,
                "merchant_name": merchant_name,
                "amount": amount,
                "action": "payment_request"
            }
        )
    
    async def notify_payment_approved(
        self, 
        db: Session, 
        user_id: str, 
        merchant_name: str, 
        amount: float,
        transaction_id: str,
        is_auto_paid: bool = False
    ):
        """Send notification for payment approval"""
        
        if is_auto_paid:
            title = "AutoPay Payment"
            body = f"${amount:.2f} automatically paid to {merchant_name}"
            notification_type = NotificationType.AUTO_PAYMENT
        else:
            title = "Payment Approved"
            body = f"${amount:.2f} payment to {merchant_name} was successful"
            notification_type = NotificationType.PAYMENT_APPROVED
        
        await self.create_notification(
            db=db,
            user_id=user_id,
            title=title,
            body=body,
            notification_type=notification_type,
            data={
                "transaction_id": transaction_id,
                "merchant_name": merchant_name,
                "amount": amount,
                "is_auto_paid": is_auto_paid,
                "action": "payment_completed"
            }
        )
    
    async def notify_payment_declined(
        self, 
        db: Session, 
        user_id: str, 
        merchant_name: str, 
        amount: float,
        request_id: str
    ):
        """Send notification for payment decline"""
        
        title = "Payment Declined"
        body = f"${amount:.2f} payment request from {merchant_name} was declined"
        
        await self.create_notification(
            db=db,
            user_id=user_id,
            title=title,
            body=body,
            notification_type=NotificationType.PAYMENT_DECLINED,
            data={
                "request_id": request_id,
                "merchant_name": merchant_name,
                "amount": amount,
                "action": "payment_declined"
            }
        )
    
    async def notify_payment_failed(
        self, 
        db: Session, 
        user_id: str, 
        merchant_name: str, 
        amount: float,
        error_message: str
    ):
        """Send notification for payment failure"""
        
        title = "Payment Failed"
        body = f"Payment of ${amount:.2f} to {merchant_name} failed"
        
        await self.create_notification(
            db=db,
            user_id=user_id,
            title=title,
            body=body,
            notification_type=NotificationType.SYSTEM,
            data={
                "merchant_name": merchant_name,
                "amount": amount,
                "error": error_message,
                "action": "payment_failed"
            }
        )
    
    def get_user_notifications(
        self, 
        db: Session, 
        user_id: str, 
        limit: int = 50,
        unread_only: bool = False
    ) -> List[Notification]:
        """Get notifications for a user"""
        
        query = db.query(Notification).filter(Notification.user_id == user_id)
        
        if unread_only:
            query = query.filter(Notification.is_read == False)
        
        return query.order_by(Notification.created_at.desc()).limit(limit).all()
    
    def mark_notification_read(
        self, 
        db: Session, 
        notification_id: str, 
        user_id: str
    ) -> bool:
        """Mark a notification as read"""
        
        notification = db.query(Notification).filter(
            Notification.id == notification_id,
            Notification.user_id == user_id
        ).first()
        
        if notification:
            notification.is_read = True
            db.commit()
            return True
        
        return False
    
    def mark_all_notifications_read(
        self, 
        db: Session, 
        user_id: str
    ) -> int:
        """Mark all notifications as read for a user"""
        
        updated_count = db.query(Notification).filter(
            Notification.user_id == user_id,
            Notification.is_read == False
        ).update({"is_read": True})
        
        db.commit()
        return updated_count
    
    def get_unread_count(
        self, 
        db: Session, 
        user_id: str
    ) -> int:
        """Get count of unread notifications for a user"""
        
        return db.query(Notification).filter(
            Notification.user_id == user_id,
            Notification.is_read == False
        ).count()


# Global notification service instance
notification_service = NotificationService() 