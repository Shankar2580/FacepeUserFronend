import logging
from datetime import datetime
from typing import List

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from sqlalchemy.orm import Session

from app.db.database import SessionLocal
from app.db.models import User

logger = logging.getLogger(__name__)
_scheduler = AsyncIOScheduler()
_job_id = "purge_soft_deleted_users"


def _purge_due_users() -> None:
    """Delete users whose deletion grace period has expired."""
    db: Session = SessionLocal()
    try:
        now = datetime.utcnow()
        candidates: List[User] = (
            db.query(User)
            .filter(
                User.deletion_effective_at.isnot(None),
                User.deletion_effective_at <= now,
                User.deleted_at.is_(None),
            )
            .all()
        )

        if not candidates:
            return

        deleted_ids = []
        for user in candidates:
            deleted_ids.append(user.id)
            db.delete(user)

        db.commit()
        logger.info("Purged %d users after grace period: %s", len(deleted_ids), deleted_ids)
    except Exception:
        db.rollback()
        logger.exception("Failed purging expired user deletions")
    finally:
        db.close()


def start_deletion_scheduler() -> None:
    """Ensure the purge job is scheduled and the scheduler is running."""
    if _scheduler.get_job(_job_id) is None:
        _scheduler.add_job(
            _purge_due_users,
            CronTrigger(hour=2, minute=0),
            id=_job_id,
            replace_existing=True,
        )

    if not _scheduler.running:
        logger.info("Starting deletion scheduler")
        _scheduler.start()


def shutdown_deletion_scheduler() -> None:
    """Stop the scheduler gracefully."""
    if _scheduler.running:
        logger.info("Shutting down deletion scheduler")
        _scheduler.shutdown(wait=False)
