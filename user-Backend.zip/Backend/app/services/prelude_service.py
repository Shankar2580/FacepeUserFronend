import logging
import os
from typing import Optional

from prelude_python_sdk import AsyncPrelude

from app.core.config import settings
from app.services.verification_cache import verification_cache

logger = logging.getLogger(__name__)

class PreludeVerificationService:
    """
    Prelude.so SMS verification service using official Python SDK
    Replaces Firebase/Twilio for phone number verification
    """
    
    def __init__(self):
        """Initialize Prelude client with API key"""
        self.client = self._get_prelude_client()

    def _get_prelude_client(self) -> Optional[AsyncPrelude]:
        """Get Prelude client instance with API key"""
        api_key = getattr(settings, "prelude_api_key", None) or os.getenv("PRELUDE_API_KEY")

        if not api_key:
            logger.error("❌ PRELUDE_API_KEY not found in environment variables")
            logger.error("💡 Set PRELUDE_API_KEY environment variable to enable SMS verification")
            return None

        try:
            logger.info("✅ Prelude client initialized successfully")
            return AsyncPrelude(api_token=api_key)
        except Exception as e:
            logger.error(f"❌ Failed to initialize Prelude client: {str(e)}")
            logger.error("💡 This might be due to network issues or invalid API key")
            return None

    @staticmethod
    def _format_phone_number(phone_number: str) -> Optional[str]:
        """Format phone number to E.164-compatible string"""
        if not phone_number:
            return None

        cleaned = "".join(c for c in phone_number if c.isdigit() or c == "+")

        if not cleaned:
            return None

        if not cleaned.startswith("+"):
            cleaned = "+1" + cleaned.lstrip("0")

        digits_only = cleaned.replace("+", "")
        if len(digits_only) < 10:
            return None

        return cleaned
    
    async def send_phone_verification(self, phone_number: str) -> bool:
        """
        Send SMS verification code using Prelude.so official SDK
        
        Args:
            phone_number (str): Phone number in E.164 format (e.g., +1234567890)
        
        Returns:
            bool: True if SMS sent successfully, False otherwise
        """
        try:
            formatted_phone = self._format_phone_number(phone_number)

            if not formatted_phone:
                logger.error(f"❌ Invalid phone number format: {phone_number}. Must contain at least 10 digits")
                return False

            if not self.client:
                logger.error("❌ Prelude client not initialized. Cannot send verification code")
                return False

            logger.info(f"📱 Prelude: Sending SMS verification to {formatted_phone}")

            verification = await self.client.verification.create(
                target={
                    "type": "phone_number",
                    "value": formatted_phone
                }
            )

            if verification and getattr(verification, "id", None):
                logger.info(f"✅ Prelude: SMS verification sent successfully to {formatted_phone}")
                logger.info(f"📊 Verification ID: {verification.id}")
                return True

            logger.error(f"❌ Prelude: Failed to send verification to {formatted_phone}")
            return False

        except Exception as e:
            logger.error(f"❌ Prelude SDK error: {str(e)}")
            return False
    
    async def verify_phone_code(self, phone_number: str, code: str) -> bool:
        """
        Verify SMS code using Prelude.so official SDK
        Now uses verification cache to prevent double API calls
        
        Args:
            phone_number (str): Phone number in E.164 format
            code (str): 4-8 digit verification code
        
        Returns:
            bool: True if verification successful, False otherwise
        """
        try:
            formatted_phone = self._format_phone_number(phone_number)

            if not formatted_phone:
                logger.error(f"❌ Invalid phone number format: {phone_number}")
                return False

            if not code or not code.isdigit():
                logger.error(f"❌ Invalid verification code: {code}")
                return False

            if verification_cache.is_verified(formatted_phone, code):
                logger.info(f"✅ Using cached verification for {formatted_phone}")
                return True

            if not self.client:
                logger.error("❌ Prelude client not available - cannot verify code")
                return False

            logger.info(f"🔍 Prelude: Verifying code {code} for {formatted_phone}")

            try:
                check = await self.client.verification.check(
                    target={
                        "type": "phone_number",
                        "value": formatted_phone
                    },
                    code=code
                )
            except Exception as api_error:
                logger.error(f"❌ Prelude API call failed: {str(api_error)}")
                logger.error(f"❌ API Error type: {type(api_error).__name__}")

                error_msg = str(api_error).lower()
                if "already verified" in error_msg or "already used" in error_msg or "code has been used" in error_msg:
                    logger.info(f"✅ Prelude: Code appears to be already verified for {formatted_phone}")
                    verification_cache.mark_verified(formatted_phone, code)
                    return True

                return False

            logger.info(f"🔍 Prelude API Raw Response: {check}")
            logger.info(f"🔍 Response type: {type(check)}")

            if not check:
                logger.error(f"❌ Prelude: No response received for {formatted_phone}")
                return False

            status = None
            if hasattr(check, "status"):
                status = check.status
            elif hasattr(check, "verification_status"):
                status = check.verification_status
            elif isinstance(check, dict):
                status = check.get("status") or check.get("verification_status") or check.get("state")

            if status is not None:
                status_lower = str(status).lower().strip()
                success_statuses = {
                    "success",
                    "successful",
                    "verified",
                    "valid",
                    "approved",
                    "completed",
                    "passed",
                    "confirmed",
                    "true",
                    "ok",
                }

                if status_lower in success_statuses:
                    logger.info(f"✅ Prelude: Phone verification successful for {formatted_phone} (status: {status})")
                    verification_cache.mark_verified(formatted_phone, code)
                    return True

                logger.warning(f"❌ Prelude: Verification failed for {formatted_phone}. Status: {status}")
                if hasattr(check, "__dict__"):
                    logger.info(f"🔍 Full response object: {check.__dict__}")
                return False

            response_str = str(check).lower()
            if "success" in response_str or "verified" in response_str or "valid" in response_str:
                logger.info(f"✅ Prelude: Phone verification successful based on response content for {formatted_phone}")
                verification_cache.mark_verified(formatted_phone, code)
                return True

            logger.error(f"❌ Prelude: Unable to verify code for {formatted_phone}")
            return False

        except Exception as e:
            logger.error(f"❌ Prelude SDK verification error: {str(e)}")
            logger.error(f"❌ Error type: {type(e).__name__}")
            return False
    
    async def send_email_verification(self, email: str) -> bool:
        """
        Email verification placeholder (Prelude focuses on SMS)
        
        Args:
            email (str): Email address
            
        Returns:
            bool: Always returns True (placeholder implementation)
        """
        # Prelude.so primarily focuses on SMS verification
        # For email verification, you might want to use a different service
        logger.warning(f"⚠️ Email verification not implemented with Prelude.so for {email}")
        logger.info("💡 Consider using a dedicated email service like SendGrid or AWS SES")
        return True
    
    async def verify_email_code(self, email: str, code: str) -> bool:
        """
        Email verification placeholder (Prelude focuses on SMS)
        
        Args:
            email (str): Email address
            code (str): Verification code
            
        Returns:
            bool: True for development mode with code 123456, False otherwise
        """
        # Development mode
        if hasattr(settings, 'development_mode') and settings.development_mode:
            if code == "123456":
                logger.info(f"🧪 Development mode: Email verification successful for {email}")
                return True
        
        logger.warning(f"⚠️ Email verification not implemented with Prelude.so for {email}")
        return False

# Create global instance
prelude_verification_service = PreludeVerificationService() 