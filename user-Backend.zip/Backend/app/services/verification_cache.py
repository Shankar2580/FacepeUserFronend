# Verification Cache System
# To prevent double verification calls to Prelude API

import time
import hashlib
from typing import Dict, Optional
import logging

logger = logging.getLogger(__name__)

class VerificationCache:
    """
    Cache successful phone verifications to avoid calling Prelude API multiple times
    with the same code (which causes 'already used' errors)
    """
    
    def __init__(self):
        self._cache: Dict[str, Dict] = {}
        self._expiry_time = 300  # 5 minutes expiry
    
    def _generate_key(self, phone_number: str, code: str) -> str:
        """Generate cache key for phone + code combination"""
        combined = f"{phone_number}:{code}"
        return hashlib.md5(combined.encode()).hexdigest()
    
    def _cleanup_expired(self):
        """Remove expired entries from cache"""
        current_time = time.time()
        expired_keys = [
            key for key, data in self._cache.items()
            if current_time - data['timestamp'] > self._expiry_time
        ]
        for key in expired_keys:
            del self._cache[key]
            logger.info(f"🧹 Expired verification cache entry removed")
    
    def is_verified(self, phone_number: str, code: str) -> bool:
        """Check if this phone + code combination was recently verified"""
        self._cleanup_expired()
        key = self._generate_key(phone_number, code)
        
        if key in self._cache:
            logger.info(f"✅ Found cached verification for {phone_number}")
            return True
        
        return False
    
    def mark_verified(self, phone_number: str, code: str) -> None:
        """Mark this phone + code combination as verified"""
        key = self._generate_key(phone_number, code)
        self._cache[key] = {
            'phone_number': phone_number,
            'timestamp': time.time(),
            'verified': True
        }
        logger.info(f"💾 Cached successful verification for {phone_number}")
    
    def invalidate(self, phone_number: str, code: str) -> None:
        """Remove verification from cache (e.g., after successful registration)"""
        key = self._generate_key(phone_number, code)
        if key in self._cache:
            del self._cache[key]
            logger.info(f"🗑️ Invalidated verification cache for {phone_number}")
    
    def get_cache_info(self) -> Dict:
        """Get cache statistics for debugging"""
        self._cleanup_expired()
        return {
            'total_entries': len(self._cache),
            'expiry_time_seconds': self._expiry_time
        }

# Global verification cache instance
verification_cache = VerificationCache() 