import stripe
import uuid
from typing import Optional, Dict, Any
from sqlalchemy.orm import Session
from app.core.config import settings
from app.db.models import User, PaymentMethod, Transaction, IncomingPaymentRequest
import logging

# Set up logging
logger = logging.getLogger(__name__)

# Configure Stripe only if key is provided
if settings.stripe_secret_key and settings.stripe_secret_key.strip():
    stripe.api_key = settings.stripe_secret_key
    logger.info("Stripe service initialized successfully")
else:
    logger.warning("Stripe secret key is not configured. Please set STRIPE_SECRET_KEY environment variable.")


class StripeService:
    def __init__(self):
        self.api_key = settings.stripe_secret_key
        if not self.api_key or not self.api_key.strip():
            logger.warning("Stripe secret key is not configured")
        else:
            logger.info("Stripe service initialized with API key")
    
    def _check_stripe_config(self) -> bool:
        """Check if Stripe is properly configured"""
        if not self.api_key or not self.api_key.strip():
            logger.error("Stripe secret key is not configured. Please set STRIPE_SECRET_KEY environment variable.")
            return False
        return True
    
    def _calculate_application_fee(self, amount_cents: int) -> int:
        """Calculate application fee for marketplace payments"""
        # Convert to percentage fee + fixed fee
        percentage_fee = int(amount_cents * (settings.stripe_application_fee_percent / 100))
        total_fee = percentage_fee + settings.stripe_application_fee_fixed
        
        # Ensure fee doesn't exceed the payment amount
        max_fee = int(amount_cents * 0.5)  # Max 50% of payment
        return min(total_fee, max_fee)
    
    def create_customer(self, user: User) -> Optional[str]:
        """Create a new Stripe customer"""
        try:
            if not self._check_stripe_config():
                return None
                
            logger.info(f"Creating Stripe customer for user {user.id}")
            customer = stripe.Customer.create(
                phone=user.phone_number,
                email=user.email,
                metadata={
                    "user_id": str(user.id),
                    "phone_number": user.phone_number
                }
            )
            logger.info(f"Stripe customer created successfully: {customer.id}")
            return customer.id
        except stripe.error.StripeError as e:
            logger.error(f"Stripe error creating customer: {str(e)}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error creating Stripe customer: {str(e)}")
            return None
    
    def get_or_create_customer(self, user: User, db: Session) -> Optional[str]:
        """Get existing customer or create new one"""
        if not self._check_stripe_config():
            return None
            
        if user.stripe_customer_id:
            try:
                # Verify customer exists
                logger.info(f"Verifying existing Stripe customer: {user.stripe_customer_id}")
                stripe.Customer.retrieve(user.stripe_customer_id)
                return user.stripe_customer_id
            except stripe.error.InvalidRequestError:
                # Customer doesn't exist, create new one
                logger.warning(f"Stripe customer {user.stripe_customer_id} not found, creating new one")
                pass
        
        # Create new customer
        customer_id = self.create_customer(user)
        if customer_id:
            user.stripe_customer_id = customer_id
            db.commit()
            logger.info(f"Updated user {user.id} with Stripe customer ID: {customer_id}")
        
        return customer_id
    
    def create_setup_intent(self, customer_id: str, metadata: Optional[Dict[str, str]] = None) -> Optional[Dict[str, Any]]:
        """Create a Setup Intent for saving payment methods"""
        try:
            if not self._check_stripe_config():
                return None
                
            logger.info(f"Creating Setup Intent for customer: {customer_id}")
            setup_intent = stripe.SetupIntent.create(
                customer=customer_id,
                usage="off_session",
                metadata=metadata or {},
                automatic_payment_methods={
                    "enabled": True,
                    "allow_redirects": "never"
                }
            )
            
            logger.info(f"Setup Intent created successfully: {setup_intent.id}")
            
            return {
                "id": setup_intent.id,
                "client_secret": setup_intent.client_secret,
                "status": setup_intent.status
            }
        except stripe.error.StripeError as e:
            logger.error(f"Stripe error creating Setup Intent: {str(e)}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error creating Setup Intent: {str(e)}")
            return None
    
    def confirm_setup_intent(self, setup_intent_id: str) -> Optional[Dict[str, Any]]:
        """Confirm a Setup Intent"""
        try:
            if not self._check_stripe_config():
                logger.error("Stripe configuration check failed")
                return None
                
            logger.info(f"Retrieving Setup Intent: {setup_intent_id}")
            logger.info("Using configured Stripe API key")
            
            setup_intent = stripe.SetupIntent.retrieve(setup_intent_id)
            
            logger.info(f"Setup Intent retrieved successfully - ID: {setup_intent.id}, Status: {setup_intent.status}")
            
            return {
                "id": setup_intent.id,
                "status": setup_intent.status,
                "payment_method": setup_intent.payment_method
            }
        except stripe.error.InvalidRequestError as e:
            logger.error(f"Invalid Setup Intent ID {setup_intent_id}: {str(e)}")
            logger.error(f"Error code: {e.code}, Error type: {e.type}")
            return None
        except stripe.error.StripeError as e:
            logger.error(f"Stripe error confirming Setup Intent {setup_intent_id}: {str(e)}")
            logger.error(f"Error code: {getattr(e, 'code', 'N/A')}, Error type: {getattr(e, 'type', 'N/A')}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error confirming Setup Intent {setup_intent_id}: {str(e)}")
            return None
    
    def create_payment_intent_with_saved_card(
        self, 
        amount: int, 
        currency: str, 
        customer_id: str,
        payment_method_id: str,
        description: Optional[str] = None,
        metadata: Optional[Dict[str, str]] = None
    ) -> Optional[Dict[str, Any]]:
        """Create a payment intent with saved payment method for off-session payments"""
        try:
            intent = stripe.PaymentIntent.create(
                amount=amount,
                currency=currency.lower(),
                customer=customer_id,
                payment_method=payment_method_id,
                description=description,
                metadata=metadata or {},
                confirm=True,
                off_session=True,  # This indicates it's an off-session payment
            )
            
            return {
                "id": intent.id,
                "status": intent.status,
                "client_secret": intent.client_secret
            }
        except stripe.error.CardError as e:
            # Handle card errors (declined, insufficient funds, etc.)
            return {
                "error": {
                    "type": "card_error",
                    "code": e.code,
                    "message": e.user_message
                }
            }
        except stripe.error.StripeError as e:
            logger.error(f"Error creating payment intent with saved card: {str(e)}")
            return None
    
    def attach_payment_method(self, payment_method_id: str, customer_id: str) -> bool:
        """Attach payment method to customer (only if not already attached)"""
        try:
            if not self._check_stripe_config():
                return False
                
            # First, check if payment method is already attached to this customer
            try:
                pm = stripe.PaymentMethod.retrieve(payment_method_id)
                if pm.customer == customer_id:
                    logger.info(f"Payment method {payment_method_id} already attached to customer {customer_id}")
                    return True
            except stripe.error.StripeError as e:
                logger.warning(f"Could not retrieve payment method {payment_method_id}: {str(e)}")
                # Continue with attachment attempt
            
            # Try to attach the payment method
            stripe.PaymentMethod.attach(
                payment_method_id,
                customer=customer_id
            )
            logger.info(f"Successfully attached payment method {payment_method_id} to customer {customer_id}")
            return True
        except stripe.error.InvalidRequestError as e:
            # Handle specific cases
            if "already attached" in str(e).lower():
                logger.info(f"Payment method {payment_method_id} already attached to customer {customer_id}")
                return True
            elif "previously used" in str(e) or "may not be used again" in str(e):
                logger.warning(f"Payment method {payment_method_id} cannot be reused: {str(e)}")
                return False
            else:
                logger.error(f"Stripe invalid request error attaching payment method: {str(e)}")
                return False
        except stripe.error.StripeError as e:
            logger.error(f"Stripe error attaching payment method: {str(e)}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error attaching payment method: {str(e)}")
            return False
    
    def detach_payment_method(self, payment_method_id: str) -> bool:
        """Detach payment method from customer"""
        try:
            if not self._check_stripe_config():
                return False
                
            stripe.PaymentMethod.detach(payment_method_id)
            return True
        except stripe.error.StripeError as e:
            logger.error(f"Stripe error detaching payment method: {str(e)}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error detaching payment method: {str(e)}")
            return False
    
    def get_payment_method_details(self, payment_method_id: str) -> Optional[Dict[str, Any]]:
        """Get payment method details from Stripe"""
        try:
            if not self._check_stripe_config():
                return None
                
            pm = stripe.PaymentMethod.retrieve(payment_method_id)
            if pm.type == 'card':
                return {
                    "last4": pm.card.last4,
                    "brand": pm.card.brand.title(),
                    "exp_month": pm.card.exp_month,
                    "exp_year": pm.card.exp_year
                }
        except stripe.error.StripeError as e:
            logger.error(f"Stripe error retrieving payment method: {str(e)}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error retrieving payment method: {str(e)}")
            return None
    
    def create_payment_intent(
        self, 
        amount: int, 
        currency: str, 
        customer_id: str,
        payment_method_id: str,
        description: Optional[str] = None,
        metadata: Optional[Dict[str, str]] = None,
        application_fee_amount: Optional[int] = None,
        stripe_account: Optional[str] = None
    ) -> Optional[Dict[str, Any]]:
        """Create a payment intent with optional Connect marketplace support"""
        try:
            # Base payment intent parameters
            intent_params = {
                "amount": amount,
                "currency": currency.lower(),
                "customer": customer_id,
                "payment_method": payment_method_id,
                "description": description,
                "metadata": metadata or {},
                "confirmation_method": 'automatic',
                "confirm": True,
                "off_session": True,  # For saved payment methods
            }
            
            # Handle Connect marketplace payments with destination charges
            if stripe_account and application_fee_amount:
                # Use destination charges: charge on platform account, transfer to Connect account
                logger.info(f"Creating destination charge to Connect account: {stripe_account}")
                intent_params.update({
                    "application_fee_amount": application_fee_amount,
                    "transfer_data": {
                        "destination": stripe_account,
                    }
                })
                # Create on platform account (no stripe_account parameter)
                intent = stripe.PaymentIntent.create(**intent_params)
                logger.info(f"Destination charge created: {intent.id}")
            elif stripe_account:
                # Simple transfer without application fee
                logger.info(f"Creating simple transfer to Connect account: {stripe_account}")
                intent_params["transfer_data"] = {"destination": stripe_account}
                intent = stripe.PaymentIntent.create(**intent_params)
            else:
                # Direct payment (standard model)
                intent = stripe.PaymentIntent.create(**intent_params)
            
            return {
                "id": intent.id,
                "status": intent.status,
                "client_secret": intent.client_secret,
                "amount": intent.amount,
                "currency": intent.currency
            }
        except stripe.error.CardError as e:
            # Handle specific card errors
            logger.error(f"Card error creating payment intent: {e.user_message}")
            return {
                "error": {
                    "type": "card_error",
                    "code": e.code,
                    "message": e.user_message
                }
            }
        except stripe.error.StripeError as e:
            logger.error(f"Stripe error creating payment intent: {str(e)}")
            return {
                "error": {
                    "type": "stripe_error",
                    "message": str(e)
                }
            }
        except Exception as e:
            logger.error(f"Unexpected error creating payment intent: {str(e)}")
            return None
    
    def confirm_payment_intent(self, payment_intent_id: str) -> Optional[Dict[str, Any]]:
        """Confirm a payment intent"""
        try:
            intent = stripe.PaymentIntent.confirm(payment_intent_id)
            return {
                "id": intent.id,
                "status": intent.status,
                "amount": intent.amount,
                "currency": intent.currency
            }
        except stripe.error.StripeError as e:
            logger.error(f"Error confirming payment intent: {str(e)}")
            return None
    
    def get_payment_intent(self, payment_intent_id: str) -> Optional[Dict[str, Any]]:
        """Get payment intent details"""
        try:
            intent = stripe.PaymentIntent.retrieve(payment_intent_id)
            return {
                "id": intent.id,
                "status": intent.status,
                "amount": intent.amount,
                "currency": intent.currency,
                "metadata": intent.metadata
            }
        except stripe.error.StripeError as e:
            logger.error(f"Error retrieving payment intent: {str(e)}")
            return None
    
    def process_auto_payment(
        self,
        user: User,
        payment_request: IncomingPaymentRequest,
        db: Session
    ) -> Dict[str, Any]:
        """Process an automatic payment with direct Stripe Connect account"""
        try:
            # Get or create customer
            customer_id = self.get_or_create_customer(user, db)
            if not customer_id:
                return {"success": False, "error": "Failed to create customer"}
            
            # Get default payment method
            default_pm = db.query(PaymentMethod).filter(
                PaymentMethod.user_id == user.id,
                PaymentMethod.is_default == True
            ).first()
            
            if not default_pm:
                return {"success": False, "error": "No default payment method"}

            # Attach payment method to customer if not already attached (Stripe best practice for reuse)
            if not self.attach_payment_method(default_pm.stripe_payment_method_id, customer_id):
                logger.error(f"Failed to attach payment method {default_pm.stripe_payment_method_id} to customer {customer_id}")
                # The payment method is corrupted/unusable, mark it as inactive and request new payment method
                logger.warning(f"Marking payment method {default_pm.id} as inactive due to Stripe attachment failure")
                default_pm.is_default = False  # Remove default status
                db.commit()
                return {
                    "success": False, 
                    "error": "Payment method needs to be updated", 
                    "error_code": "PAYMENT_METHOD_INVALID",
                    "action_required": "Please add a new payment method"
                }
            
            # Validate that merchant_id is a Stripe Connect account ID
            stripe_connect_account_id = payment_request.merchant_id
            if not stripe_connect_account_id.startswith("acct_"):
                return {"success": False, "error": "Invalid merchant Stripe Connect account ID"}
            
            # Create payment intent with Connect marketplace fees
            metadata = {
                "user_id": str(user.id),
                "merchant_connect_account": stripe_connect_account_id,
                "request_id": str(payment_request.id),
                "payment_type": "auto_payment"
            }
            
            # Calculate application fee for marketplace
            application_fee = self._calculate_application_fee(payment_request.amount)
            
            intent_result = self.create_payment_intent(
                amount=payment_request.amount,
                currency=payment_request.currency,
                customer_id=customer_id,
                payment_method_id=default_pm.stripe_payment_method_id,
                description=payment_request.description,
                metadata=metadata,
                application_fee_amount=application_fee,
                stripe_account=stripe_connect_account_id  # Use merchant's Connect account directly
            )
            
            if not intent_result:
                return {"success": False, "error": "Failed to create payment intent"}
            
            # Handle payment errors
            if "error" in intent_result:
                error = intent_result["error"]
                error_code = error.get("code", "unknown_error")
                error_type = error.get("type", "api_error")
                error_message = error.get("message", "Payment processing failed")
                
                # Map Stripe error codes to user-friendly codes
                if error_type == "card_error":
                    # Common card errors: card_declined, insufficient_funds, expired_card, etc.
                    return {
                        "success": False, 
                        "error": f"Card error: {error_message}",
                        "error_code": error_code,
                        "error_type": "card_error"
                    }
                else:
                    return {
                        "success": False, 
                        "error": f"Payment error: {error_message}",
                        "error_code": error_code,
                        "error_type": error_type
                    }
            
            # Update payment request
            payment_request.stripe_payment_intent_id = intent_result["id"]
            payment_request.status = "COMPLETED" if intent_result["status"] == "succeeded" else "PENDING"
            db.commit()
            
            # Create transaction record if payment succeeded
            if intent_result["status"] == "succeeded":
                # Use business name from payment request, fallback to parsing description
                merchant_name = payment_request.business_name or "Unknown Merchant"
                if not merchant_name or merchant_name.strip() == "":
                    merchant_name = "Unknown Merchant"
                    if payment_request.description:
                        # Try to extract business name from description as fallback
                        if "Payment request from " in payment_request.description:
                            merchant_name = payment_request.description.replace("Payment request from ", "")
                        else:
                            merchant_name = payment_request.description
                
                transaction = Transaction(
                    user_id=user.id,
                    merchant_id=payment_request.merchant_id,
                    merchant_name=merchant_name,
                    amount=payment_request.amount,
                    currency=payment_request.currency,
                    status="SUCCEEDED",
                    payment_method_id=default_pm.id,
                    stripe_transaction_id=intent_result["id"],
                    description=payment_request.description,
                    is_auto_paid=True
                )
                db.add(transaction)
                db.commit()
            
            return {
                "success": True,
                "payment_intent_id": intent_result["id"],
                "status": intent_result["status"]
            }
            
        except Exception as e:
            logger.error(f"Error processing auto payment: {str(e)}")
            return {
                "success": False, 
                "error": str(e),
                "error_code": "processing_error",
                "error_type": "exception"
            }
    
    def process_manual_payment(
        self,
        user: User,
        payment_request: IncomingPaymentRequest,
        db: Session
    ) -> Dict[str, Any]:
        """Process a manual payment approval with direct Stripe Connect account"""
        try:
            # Get or create customer
            customer_id = self.get_or_create_customer(user, db)
            if not customer_id:
                return {"success": False, "error": "Failed to create customer"}
            
            # Get default payment method
            default_pm = db.query(PaymentMethod).filter(
                PaymentMethod.user_id == user.id,
                PaymentMethod.is_default == True
            ).first()
            
            if not default_pm:
                return {"success": False, "error": "No default payment method"}

            # Attach payment method to customer if not already attached (Stripe best practice for reuse)
            if not self.attach_payment_method(default_pm.stripe_payment_method_id, customer_id):
                logger.error(f"Failed to attach payment method {default_pm.stripe_payment_method_id} to customer {customer_id}")
                # The payment method is corrupted/unusable, mark it as inactive and request new payment method
                logger.warning(f"Marking payment method {default_pm.id} as inactive due to Stripe attachment failure")
                default_pm.is_default = False  # Remove default status
                db.commit()
                return {
                    "success": False, 
                    "error": "Payment method needs to be updated", 
                    "error_code": "PAYMENT_METHOD_INVALID",
                    "action_required": "Please add a new payment method"
                }
            
            # Validate that merchant_id is a Stripe Connect account ID
            stripe_connect_account_id = payment_request.merchant_id
            if not stripe_connect_account_id.startswith("acct_"):
                return {"success": False, "error": "Invalid merchant Stripe Connect account ID"}
            
            # Create payment intent with Connect marketplace fees
            metadata = {
                "user_id": str(user.id),
                "merchant_connect_account": stripe_connect_account_id,
                "request_id": str(payment_request.id),
                "payment_type": "manual_payment"
            }
            
            # Calculate application fee for marketplace
            application_fee = self._calculate_application_fee(payment_request.amount)
            
            intent_result = self.create_payment_intent(
                amount=payment_request.amount,
                currency=payment_request.currency,
                customer_id=customer_id,
                payment_method_id=default_pm.stripe_payment_method_id,
                description=payment_request.description,
                metadata=metadata,
                application_fee_amount=application_fee,
                stripe_account=stripe_connect_account_id  # Use merchant's Connect account directly
            )
            
            if not intent_result:
                return {"success": False, "error": "Failed to create payment intent"}
            
            # Handle payment errors
            if "error" in intent_result:
                error = intent_result["error"]
                error_code = error.get("code", "unknown_error")
                error_type = error.get("type", "api_error")
                error_message = error.get("message", "Payment processing failed")
                
                # Map Stripe error codes to user-friendly codes
                if error_type == "card_error":
                    # Common card errors: card_declined, insufficient_funds, expired_card, etc.
                    return {
                        "success": False, 
                        "error": f"Card error: {error_message}",
                        "error_code": error_code,
                        "error_type": "card_error"
                    }
                else:
                    return {
                        "success": False, 
                        "error": f"Payment error: {error_message}",
                        "error_code": error_code,
                        "error_type": error_type
                    }
            
            # Update payment request
            payment_request.stripe_payment_intent_id = intent_result["id"]
            payment_request.status = "COMPLETED"
            db.commit()
            
            # Create transaction record
            # Use business name from payment request, fallback to parsing description
            merchant_name = payment_request.business_name or "Unknown Merchant"
            if not merchant_name or merchant_name.strip() == "":
                merchant_name = "Unknown Merchant"
                if payment_request.description:
                    # Try to extract business name from description as fallback
                    if "Payment request from " in payment_request.description:
                        merchant_name = payment_request.description.replace("Payment request from ", "")
                    else:
                        merchant_name = payment_request.description
            
            transaction = Transaction(
                user_id=user.id,
                merchant_id=payment_request.merchant_id,
                merchant_name=merchant_name,
                amount=payment_request.amount,
                currency=payment_request.currency,
                status="SUCCEEDED" if intent_result["status"] == "succeeded" else "FAILED",
                payment_method_id=default_pm.id,
                stripe_transaction_id=intent_result["id"],
                description=payment_request.description,
                is_auto_paid=False
            )
            db.add(transaction)
            db.commit()
            
            return {
                "success": True,
                "payment_intent_id": intent_result["id"],
                "status": intent_result["status"]
            }
            
        except Exception as e:
            logger.error(f"Error processing manual payment: {str(e)}")
            return {
                "success": False, 
                "error": str(e),
                "error_code": "processing_error",
                "error_type": "exception"
            }
    
    def handle_webhook_event(self, event_type: str, event_data: Dict[str, Any], db: Session):
        """Handle Stripe webhook events"""
        try:
            if event_type == "payment_intent.succeeded":
                self._handle_payment_success(event_data, db)
            elif event_type == "payment_intent.payment_failed":
                self._handle_payment_failure(event_data, db)
        except Exception as e:
            logger.error(f"Error handling webhook event: {str(e)}")
    
    def _handle_payment_success(self, event_data: Dict[str, Any], db: Session):
        """Handle successful payment webhook"""
        payment_intent_id = event_data["object"]["id"]
        
        # Find the payment request
        payment_request = db.query(IncomingPaymentRequest).filter(
            IncomingPaymentRequest.stripe_payment_intent_id == payment_intent_id
        ).first()
        
        if payment_request:
            # Update payment request status
            payment_request.status = "COMPLETED"
            
            # Create or update transaction
            existing_transaction = db.query(Transaction).filter(
                Transaction.stripe_transaction_id == payment_intent_id
            ).first()
            
            if not existing_transaction:
                # Get default payment method
                default_pm = db.query(PaymentMethod).filter(
                    PaymentMethod.user_id == payment_request.user_id,
                    PaymentMethod.is_default == True
                ).first()
                
                # Use business name from payment request, fallback to parsing description
                merchant_name = payment_request.business_name or "Unknown Merchant"
                if not merchant_name or merchant_name.strip() == "":
                    merchant_name = "Unknown Merchant"
                    if payment_request.description:
                        # Try to extract business name from description as fallback
                        if "Payment request from " in payment_request.description:
                            merchant_name = payment_request.description.replace("Payment request from ", "")
                        else:
                            merchant_name = payment_request.description
                
                transaction = Transaction(
                    user_id=payment_request.user_id,
                    merchant_id=payment_request.merchant_id,
                    merchant_name=merchant_name,
                    amount=payment_request.amount,
                    currency=payment_request.currency,
                    status="SUCCEEDED",
                    payment_method_id=default_pm.id if default_pm else None,
                    stripe_transaction_id=payment_intent_id,
                    description=payment_request.description,
                    is_auto_paid=payment_request.is_auto_paid
                )
                db.add(transaction)
            else:
                existing_transaction.status = "SUCCEEDED"
            
            db.commit()
    
    def _handle_payment_failure(self, event_data: Dict[str, Any], db: Session):
        """Handle failed payment webhook"""
        payment_intent_id = event_data["object"]["id"]
        
        # Find the payment request
        payment_request = db.query(IncomingPaymentRequest).filter(
            IncomingPaymentRequest.stripe_payment_intent_id == payment_intent_id
        ).first()
        
        if payment_request:
            # Update payment request status
            payment_request.status = "FAILED"
            
            # Create or update transaction
            existing_transaction = db.query(Transaction).filter(
                Transaction.stripe_transaction_id == payment_intent_id
            ).first()
            
            if not existing_transaction:
                # Get default payment method
                default_pm = db.query(PaymentMethod).filter(
                    PaymentMethod.user_id == payment_request.user_id,
                    PaymentMethod.is_default == True
                ).first()
                
                # Use business name from payment request, fallback to parsing description
                merchant_name = payment_request.business_name or "Unknown Merchant"
                if not merchant_name or merchant_name.strip() == "":
                    merchant_name = "Unknown Merchant"
                    if payment_request.description:
                        # Try to extract business name from description as fallback
                        if "Payment request from " in payment_request.description:
                            merchant_name = payment_request.description.replace("Payment request from ", "")
                        else:
                            merchant_name = payment_request.description
                
                transaction = Transaction(
                    user_id=payment_request.user_id,
                    merchant_id=payment_request.merchant_id,
                    merchant_name=merchant_name,
                    amount=payment_request.amount,
                    currency=payment_request.currency,
                    status="FAILED",
                    payment_method_id=default_pm.id if default_pm else None,
                    stripe_transaction_id=payment_intent_id,
                    description=payment_request.description,
                    is_auto_paid=payment_request.is_auto_paid
                )
                db.add(transaction)
            else:
                existing_transaction.status = "FAILED"
            
            db.commit()


# Global instance
stripe_service = StripeService() 