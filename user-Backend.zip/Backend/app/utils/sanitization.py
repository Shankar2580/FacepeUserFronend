"""
Input sanitization utilities to prevent XSS, injection attacks, and data corruption.
"""
import html
import re
from typing import Optional


def sanitize_string(value: Optional[str], max_length: int = 255) -> Optional[str]:
    """
    Sanitize a string by removing dangerous characters and escaping HTML.
    
    Args:
        value: The string to sanitize
        max_length: Maximum allowed length
        
    Returns:
        Sanitized string or None if input is None
    """
    if not value:
        return value
    
    # Remove null bytes (can break databases)
    value = value.replace('\x00', '')
    
    # Escape HTML special characters
    # < becomes &lt;
    # > becomes &gt;
    # & becomes &amp;
    # " becomes &quot;
    # ' becomes &#x27;
    value = html.escape(value)
    
    # Trim to max length
    if len(value) > max_length:
        value = value[:max_length]
    
    return value.strip()


def sanitize_name(name: str, max_length: int = 100) -> str:
    """
    Sanitize a person's name.
    Allows: letters, spaces, hyphens, apostrophes, periods
    
    Args:
        name: The name to sanitize
        max_length: Maximum allowed length
        
    Returns:
        Sanitized name
    """
    if not name:
        return ""
    
    # Remove everything except letters, spaces, and common name characters
    # Allows: a-z, A-Z, spaces, hyphens, apostrophes, periods
    name = re.sub(r"[^\w\s\-'.]", '', name)
    
    # Remove multiple spaces
    name = re.sub(r'\s+', ' ', name)
    
    return sanitize_string(name, max_length=max_length)


def sanitize_email(email: str) -> str:
    """
    Sanitize an email address.
    
    Args:
        email: The email to sanitize
        
    Returns:
        Sanitized email in lowercase
    """
    if not email:
        return ""
    
    # Convert to lowercase and strip whitespace
    email = email.lower().strip()
    
    # Remove null bytes
    email = email.replace('\x00', '')
    
    # Basic email validation (more thorough validation should use email-validator)
    # Remove any characters that aren't valid in emails
    email = re.sub(r'[^\w\.\-\+@]', '', email)
    
    return email


def sanitize_phone(phone: str) -> str:
    """
    Sanitize a phone number.
    Keeps only digits and the + sign.
    
    Args:
        phone: The phone number to sanitize
        
    Returns:
        Sanitized phone number
    """
    if not phone:
        return ""
    
    # Keep only digits and + sign
    phone = re.sub(r'[^\d+]', '', phone)
    
    return phone.strip()


def sanitize_description(description: str, max_length: int = 500) -> str:
    """
    Sanitize a description or text field.
    
    Args:
        description: The description to sanitize
        max_length: Maximum allowed length
        
    Returns:
        Sanitized description
    """
    if not description:
        return ""
    
    return sanitize_string(description, max_length=max_length)


def sanitize_business_name(name: str, max_length: int = 100) -> str:
    """
    Sanitize a business name.
    Allows: letters, numbers, spaces, and common business punctuation
    
    Args:
        name: The business name to sanitize
        max_length: Maximum allowed length
        
    Returns:
        Sanitized business name
    """
    if not name:
        return ""
    
    # Remove everything except alphanumeric, spaces, and common business punctuation
    # Allows: a-z, A-Z, 0-9, spaces, hyphens, periods, commas, ampersands, parentheses
    name = re.sub(r'[^\w\s\-.,&()]', '', name)
    
    # Remove multiple spaces
    name = re.sub(r'\s+', ' ', name)
    
    return sanitize_string(name, max_length=max_length)


def sanitize_url(url: str, max_length: int = 500) -> str:
    """
    Sanitize a URL.
    
    Args:
        url: The URL to sanitize
        max_length: Maximum allowed length
        
    Returns:
        Sanitized URL
    """
    if not url:
        return ""
    
    # Remove null bytes and whitespace
    url = url.replace('\x00', '').strip()
    
    # Basic URL character validation
    # Allows: alphanumeric, common URL characters
    url = re.sub(r'[^\w\-._~:/?#\[\]@!$&\'()*+,;=%]', '', url)
    
    # Trim to max length
    if len(url) > max_length:
        url = url[:max_length]
    
    return url


def sanitize_currency(currency: str) -> str:
    """
    Sanitize a currency code (e.g., USD, EUR).
    
    Args:
        currency: The currency code to sanitize
        
    Returns:
        Sanitized currency code in uppercase
    """
    if not currency:
        return "USD"  # Default to USD
    
    # Keep only letters, convert to uppercase
    currency = re.sub(r'[^A-Za-z]', '', currency).upper()
    
    # Limit to 3 characters (standard currency code length)
    return currency[:3] if currency else "USD"
