from pydantic import BaseModel
from typing import Optional, Dict, Any
from enum import Enum
from datetime import datetime

class NotificationType(str, Enum):
    PAYMENT_REQUEST = "PAYMENT_REQUEST"
    PAYMENT_APPROVED = "PAYMENT_APPROVED"
    PAYMENT_DECLINED = "PAYMENT_DECLINED"
    AUTO_PAYMENT = "AUTO_PAYMENT"
    SYSTEM = "SYSTEM"
    MARKETING = "MARKETING"

class NotificationCreate(BaseModel):
    user_id: str
    title: str
    body: str
    notification_type: NotificationType
    data: Optional[Dict[str, Any]] = None
