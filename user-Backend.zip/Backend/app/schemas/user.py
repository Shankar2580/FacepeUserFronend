from pydantic import BaseModel, EmailStr, Field, validator
from typing import Optional, Dict, Any
from datetime import datetime
import re
from app.schemas.common import BaseResponse

def validate_phone_number_format(phone_number: str) -> str:
    """Validate phone number format for supported countries"""
    if not phone_number.startswith('+'):
        raise ValueError('Phone number must be in E.164 format (start with +)')
    
    # Validate specific country formats
    if phone_number.startswith('+1'):
        # US/Canada: +1 followed by 10 digits
        if len(phone_number) != 12 or not phone_number[2:].isdigit():
            raise ValueError('US phone number must be +1 followed by 10 digits (e.g., +15551234567)')
    elif phone_number.startswith('+91'):
        # India: +91 followed by 10 digits
        if len(phone_number) != 13 or not phone_number[3:].isdigit():
            raise ValueError('India phone number must be +91 followed by 10 digits (e.g., +919876543210)')
    else:
        # For other countries, just check basic E.164 format
        if len(phone_number) < 10 or len(phone_number) > 16:
            raise ValueError('Phone number must be between 10-16 characters in E.164 format')
    
    return phone_number

class UserRegistration(BaseModel):
    phone_number: str = Field(..., min_length=10, max_length=16, description="E.164 format phone number (e.g., +1234567890)")
    email: Optional[EmailStr] = None
    password: str = Field(..., min_length=8)
    profile_info: Optional[Dict[str, Any]] = None

    @validator('phone_number')
    def validate_phone_number(cls, v):
        if not v.startswith('+'):
            raise ValueError('Phone number must be in E.164 format (start with +)')
        return v

class UserLogin(BaseModel):
    username: str  # phone number or email
    password: str

class UserResponse(BaseResponse):
    id: str
    phone_number: str
    email: Optional[str]
    profile_info: Optional[Dict[str, Any]]
    face_active: bool
    face_id: Optional[str]
    created_at: datetime
    updated_at: datetime

class UserUpdate(BaseModel):
    email: Optional[EmailStr] = None
    profile_info: Optional[Dict[str, Any]] = None

class FrontendUserRegistration(BaseModel):
    phone_number: str = Field(..., min_length=10, max_length=16, description="E.164 format phone number (e.g., +1234567890)")
    email: EmailStr = Field(..., description="User's email address")
    first_name: str = Field(..., min_length=1, max_length=50, description="User's first name")
    last_name: str = Field(..., min_length=1, max_length=50, description="User's last name")
    password: str = Field(..., min_length=8, description="Password (min 8 chars)")
    pin: str = Field(..., min_length=4, max_length=4, description="4-digit PIN for additional authentication")
    verification_code: str = Field(..., min_length=4, max_length=10, description="SMS verification code")
    
    @validator('phone_number')
    def validate_phone_number(cls, v):
        return validate_phone_number_format(v)
    
    @validator('password')
    def validate_password(cls, v):
        if len(v) < 8:
            raise ValueError('Password must be at least 8 characters long')
        if not re.search(r'\d', v):
            raise ValueError('Password must contain at least one number')
        if not re.search(r'[a-zA-Z]', v):
            raise ValueError('Password must contain at least one letter')
        if not re.search(r'[!@#$%^&*(),.?":{}|<>]', v):
            raise ValueError('Password must contain at least one special character (!@#$%^&*(),.?":{}|<>)')
        return v
    
    @validator('pin')
    def validate_pin(cls, v):
        if not v.isdigit():
            raise ValueError('PIN must contain only digits')
        if len(v) != 4:
            raise ValueError('PIN must be exactly 4 digits')
        if v in ['0000', '1111', '2222', '3333', '4444', '5555', '6666', '7777', '8888', '9999', '1234', '4321']:
            raise ValueError('PIN cannot be a common sequence like 0000, 1234, etc.')
        return v

class PhoneVerifiedUserRegistration(BaseModel):
    full_name: str = Field(..., min_length=2, max_length=100, description="User's full name")
    email: EmailStr = Field(..., description="User's email address")
    phone_number: str = Field(..., min_length=10, max_length=16, description="E.164 format phone number (e.g., +1234567890)")
    password: str = Field(..., min_length=8, description="Password (min 8 chars, 1 number, 1 letter, 1 special char)")
    pin: str = Field(..., min_length=4, max_length=4, description="4-digit PIN for additional authentication")
    
    @validator('phone_number')
    def validate_phone_number(cls, v):
        return validate_phone_number_format(v)
    
    @validator('password')
    def validate_password(cls, v):
        if len(v) < 8:
            raise ValueError('Password must be at least 8 characters long')
        if not re.search(r'\d', v):
            raise ValueError('Password must contain at least one number')
        if not re.search(r'[a-zA-Z]', v):
            raise ValueError('Password must contain at least one letter')
        if not re.search(r'[!@#$%^&*(),.?":{}|<>]', v):
            raise ValueError('Password must contain at least one special character (!@#$%^&*(),.?":{}|<>)')
        return v
    
    @validator('pin')
    def validate_pin(cls, v):
        if not v.isdigit():
            raise ValueError('PIN must contain only digits')
        if len(v) != 4:
            raise ValueError('PIN must be exactly 4 digits')
        if v in ['0000', '1111', '2222', '3333', '4444', '5555', '6666', '7777', '8888', '9999', '1234', '4321']:
            raise ValueError('PIN cannot be a common sequence like 0000, 1234, etc.')
        return v

    @validator('full_name')
    def validate_full_name(cls, v):
        v = ' '.join(v.split())
        if len(v.split()) < 2:
            raise ValueError('Please provide both first and last name')
        return v

class PasswordReset(BaseModel):
    new_password: str = Field(..., min_length=8, description="New password (min 8 chars, 1 number, 1 letter, 1 special char)")

    @validator('new_password')
    def validate_new_password(cls, v):
        if len(v) < 8:
            raise ValueError('Password must be at least 8 characters long')
        if not re.search(r'\d', v):
            raise ValueError('Password must contain at least one number')
        if not re.search(r'[a-zA-Z]', v):
            raise ValueError('Password must contain at least one letter')
        if not re.search(r'[!@#$%^&*(),.?":{}|<>]', v):
            raise ValueError('Password must contain at least one special character (!@#$%^&*(),.?":{}|<>)')
        return v

class UserProfileUpdate(BaseModel):
    full_name: str = Field(..., min_length=1, max_length=100, description="User's full name")
