from pydantic import BaseModel, Field
from typing import Optional, List
from enum import Enum

class BaseResponse(BaseModel):
    class Config:
        from_attributes = True

class PaymentStatus(str, Enum):
    PENDING = "PENDING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"

class TransactionStatus(str, Enum):
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"
    PENDING = "PENDING"
    CANCELLED = "CANCELLED"

class ErrorResponse(BaseModel):
    error: str
    message: str
    action: Optional[str] = None

class ValidationError(BaseModel):
    field: str
    message: str

class DetailedErrorResponse(BaseModel):
    error: str
    message: str
    details: Optional[List[ValidationError]] = None
