from pydantic import BaseModel, Field, validator
from typing import Optional
from datetime import datetime
from app.schemas.common import BaseResponse, PaymentStatus

class PaymentMethodCreate(BaseModel):
    stripe_payment_method_id: str
    last4: str = Field(..., min_length=4, max_length=4)
    brand: str
    exp_month: int = Field(..., ge=1, le=12)
    exp_year: int = Field(..., ge=2024, le=2050)
    is_default: bool = False

class PaymentMethodCreateSecure(BaseModel):
    """Secure payment method creation - only requires Stripe payment method ID"""
    stripe_payment_method_id: str = Field(..., min_length=3, description="Stripe payment method ID (pm_...)")
    is_default: Optional[bool] = False

    @validator('stripe_payment_method_id')
    def validate_stripe_pm_id(cls, v):
        if not v.startswith('pm_'):
            raise ValueError('Invalid Stripe payment method ID format')
        return v

class PaymentMethodUpdate(BaseModel):
    is_default: bool

class PaymentMethodResponse(BaseResponse):
    id: str
    card_last_four: str
    card_brand: str
    card_exp_month: int
    card_exp_year: int
    is_default: bool
    created_at: datetime

class IncomingPaymentRequestCreate(BaseModel):
    merchant_id: str
    amount: int = Field(..., gt=0, description="Amount in cents")
    currency: str = Field(default="USD", max_length=3)
    description: Optional[str] = None
    face_scan_id: str

class IncomingPaymentRequestResponse(BaseResponse):
    request_id: str = Field(alias="id")
    merchant_id: str
    amount: int
    currency: str
    description: Optional[str]
    face_scan_id: str
    is_auto_paid: bool
    status: PaymentStatus
    stripe_payment_intent_id: Optional[str]
    created_at: datetime
    updated_at: datetime

    class Config:
        populate_by_name = True

class PaymentApprovalResponse(BaseModel):
    status: str
    transaction_id: Optional[str] = None

class PaymentDeclineResponse(BaseModel):
    status: str = "DECLINED"

class FaceVerifyRequest(BaseModel):
    image_base64: str


class FaceVerifyResponse(BaseModel):
    user_id: str
    face_id: str
    confidence: float


class FaceStatusResponse(BaseModel):
    enrolled: bool
    face_id: Optional[str]
    face_created_at: Optional[datetime]
