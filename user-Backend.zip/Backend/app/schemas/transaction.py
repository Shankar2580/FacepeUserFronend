from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime
from app.schemas.common import BaseResponse
from app.schemas.payment import PaymentMethodResponse

class TransactionResponse(BaseResponse):
    id: str
    user_id: str
    merchant_id: str
    merchant_name: str
    amount: int
    currency: str
    status: str
    payment_method_id: Optional[str]
    stripe_payment_intent_id: Optional[str]
    description: Optional[str]
    created_at: datetime
    updated_at: datetime

class TransactionFees(BaseModel):
    stripe_fee: int
    platform_fee: int
    total_fees: int

class TransactionDetailResponse(BaseResponse):
    id: str
    merchant_id: str
    merchant_name: str
    amount: int
    currency: str
    created_at: datetime
    timestamp: datetime
    status: str
    payment_method_id: Optional[str]
    stripe_payment_intent_id: Optional[str] = Field(alias="stripe_transaction_id")
    description: Optional[str]
    is_auto_paid: bool
    payment_method: Optional[PaymentMethodResponse]
    receipt_url: Optional[str]

    class Config:
        from_attributes = True
        populate_by_name = True


class TransactionListResponse(BaseResponse):
    transactions: List[TransactionResponse]
    next_cursor: Optional[str]
    has_more: bool
