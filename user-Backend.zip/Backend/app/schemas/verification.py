from pydantic import BaseModel, EmailStr, Field, validator
from typing import Optional, List
from app.schemas.user import validate_phone_number_format

class PhoneVerificationRequest(BaseModel):
    phone_number: str = Field(..., min_length=10, max_length=16, description="E.164 format phone number (e.g., +1234567890, +919876543210)")
    
    @validator('phone_number')
    def validate_phone_number(cls, v):
        return validate_phone_number_format(v)

class EmailVerificationRequest(BaseModel):
    email: EmailStr

class VerificationCodeRequest(BaseModel):
    phone_number: str = Field(..., min_length=10, max_length=16, description="E.164 format phone number (e.g., +1234567890, +919876543210)")
    code: str = Field(..., min_length=4, max_length=10, description="Verification code received via SMS")
    
    @validator('phone_number')
    def validate_phone_number(cls, v):
        return validate_phone_number_format(v)

class EmailVerificationCodeRequest(BaseModel):
    email: EmailStr
    code: str = Field(..., min_length=4, max_length=10, description="Verification code")

class VerificationResponse(BaseModel):
    success: bool
    message: str

class PinVerificationRequest(BaseModel):
    pin: str = Field(..., min_length=4, max_length=4, description="4-digit PIN for user verification")
    face_scan_id: str = Field(..., description="Face scan ID from the face recognition service")
    potential_user_ids: List[str] = Field(..., description="List of potential user IDs with similar faces")
    
    @validator('pin')
    def validate_pin(cls, v):
        if not v.isdigit():
            raise ValueError('PIN must contain only digits')
        if len(v) != 4:
            raise ValueError('PIN must be exactly 4 digits')
        return v

class PinVerificationResponse(BaseModel):
    success: bool
    message: str
    verified_user_id: Optional[str] = None

class PinResetRequest(BaseModel):
    phone_number: str = Field(..., min_length=10, max_length=16, description="E.164 format phone number (e.g., +1234567890)")
    verification_code: str = Field(..., min_length=4, max_length=10, description="SMS verification code")
    current_pin: str = Field(..., min_length=4, max_length=4, description="Current 4-digit PIN")
    new_pin: str = Field(..., min_length=4, max_length=4, description="New 4-digit PIN")
    
    @validator('phone_number')
    def validate_phone_number(cls, v):
        return validate_phone_number_format(v)
    
    @validator('current_pin')
    def validate_current_pin(cls, v):
        if not v.isdigit():
            raise ValueError('Current PIN must contain only digits')
        if len(v) != 4:
            raise ValueError('Current PIN must be exactly 4 digits')
        return v
    
    @validator('new_pin')
    def validate_new_pin(cls, v):
        if not v.isdigit():
            raise ValueError('New PIN must contain only digits')
        if len(v) != 4:
            raise ValueError('New PIN must be exactly 4 digits')
        if v in ['0000', '1111', '2222', '3333', '4444', '5555', '6666', '7777', '8888', '9999', '1234', '4321']:
            raise ValueError('New PIN cannot be a common sequence like 0000, 1234, etc.')
        return v

class PinResetResponse(BaseModel):
    success: bool
    message: str
