from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime
from app.schemas.common import BaseResponse

class AutoPayApprovalCreate(BaseModel):
    merchant_id: str
    limit_amount: int = Field(..., gt=0, description="Amount in cents")

class AutoPayApprovalResponse(BaseResponse):
    merchant_id: str
    limit_amount: int
    created_at: datetime
    updated_at: Optional[datetime] = None

class AutoPayCreate(BaseModel):
    merchant_id: str
    merchant_name: str
    payment_method_id: str
    max_amount: Optional[int] = None  # in cents
    is_enabled: bool = True

class AutoPayUpdate(BaseModel):
    is_enabled: Optional[bool] = None
    max_amount: Optional[int] = None

class AutoPayResponse(BaseResponse):
    id: str
    merchant_id: str
    merchant_name: str
    is_enabled: bool
    max_amount: Optional[int]
    payment_method_id: str
    created_at: datetime
    updated_at: datetime
