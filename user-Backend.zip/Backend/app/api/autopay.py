from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from app.db.database import get_db
from app.db.models import User, AutoPay, PaymentMethod
from app.schemas.autopay import AutoPayCreate, AutoPayUpdate, AutoPayResponse
from app.dependencies import get_current_user
from uuid import UUID
from fastapi import Response
import logging

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Autopay"])


@router.get("/users/me/autopay", response_model=List[AutoPayResponse])
def get_autopay_settings(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get all auto-pay settings for the current user"""
    auto_pays = db.query(AutoPay).filter(
        AutoPay.user_id == current_user.id
    ).order_by(AutoPay.created_at.desc()).all()
    
    return auto_pays


@router.post("/users/me/autopay", response_model=AutoPayResponse)
def create_or_update_autopay_setting(
    autopay_data: AutoPayCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Create a new auto-pay setting or update an existing one for a merchant"""
    try:
        # Check if auto-pay already exists for this merchant
        existing_auto_pay = db.query(AutoPay).filter(
            AutoPay.user_id == current_user.id,
            AutoPay.merchant_id == autopay_data.merchant_id
        ).first()
        
        if existing_auto_pay:
            # Update existing auto-pay instead of throwing error
            existing_auto_pay.merchant_name = autopay_data.merchant_name
            existing_auto_pay.payment_method_id = autopay_data.payment_method_id
            existing_auto_pay.max_amount = autopay_data.max_amount
            existing_auto_pay.is_enabled = autopay_data.is_enabled
            
            # Update timestamp
            from sqlalchemy.sql import func
            existing_auto_pay.updated_at = func.now()
            
            db.commit()
            db.refresh(existing_auto_pay)
            
            return existing_auto_pay
        
        # Verify payment method exists and belongs to user
        payment_method = db.query(PaymentMethod).filter(
            PaymentMethod.id == autopay_data.payment_method_id,
            PaymentMethod.user_id == current_user.id
        ).first()
        
        if not payment_method:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Payment method not found"
            )
        
        # Create new auto-pay
        db_auto_pay = AutoPay(
            user_id=current_user.id,
            merchant_id=autopay_data.merchant_id,
            merchant_name=autopay_data.merchant_name,
            payment_method_id=autopay_data.payment_method_id,
            max_amount=autopay_data.max_amount,
            is_enabled=autopay_data.is_enabled
        )
        
        db.add(db_auto_pay)
        db.commit()
        db.refresh(db_auto_pay)
        
        return db_auto_pay
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create auto-pay setting"
        )


@router.put("/users/me/autopay/{merchant_id}", response_model=AutoPayResponse)
def update_auto_pay(
    merchant_id: str,
    auto_pay_data: AutoPayUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Update an auto-pay setting"""
    logger.info(f"PUT autopay request for merchant_id: {merchant_id}, user_id: {current_user.id}")
    logger.info(f"Update data: {auto_pay_data}")
    
    # Check all autopay records for this user
    all_autopays = db.query(AutoPay).filter(
        AutoPay.user_id == current_user.id
    ).all()
    logger.info(f"User has {len(all_autopays)} autopay records: {[ap.merchant_id for ap in all_autopays]}")
    
    # Find the auto-pay setting by merchant_id
    auto_pay = db.query(AutoPay).filter(
        AutoPay.merchant_id == merchant_id,
        AutoPay.user_id == current_user.id
    ).first()
    
    if not auto_pay:
        logger.warning(f"Autopay not found for merchant_id: {merchant_id}, user_id: {current_user.id}")
        
        # Check if merchant_id is a UUID (merchant's internal ID) instead of Stripe account ID
        if not merchant_id.startswith('acct_'):
            logger.error(f"Frontend sent merchant UUID instead of Stripe Connect Account ID: {merchant_id}")
            logger.error(f"Available merchant IDs for this user: {[ap.merchant_id for ap in all_autopays]}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid merchant_id format. Expected Stripe Connect Account ID (starts with 'acct_'), got merchant UUID instead."
            )
        
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Auto-pay setting not found"
        )
    
    try:
        # Update fields
        if auto_pay_data.is_enabled is not None:
            auto_pay.is_enabled = auto_pay_data.is_enabled
        
        if auto_pay_data.max_amount is not None:
            auto_pay.max_amount = auto_pay_data.max_amount
        
        # Update timestamp
        from sqlalchemy.sql import func
        auto_pay.updated_at = func.now()
        
        db.commit()
        db.refresh(auto_pay)
        
        return auto_pay
        
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update auto-pay setting"
        )


@router.delete("/users/me/autopay/{merchant_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_auto_pay(
    merchant_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Delete an auto-pay setting by merchant ID"""
    logger.info(f"DELETE autopay request for merchant_id: {merchant_id}, user_id: {current_user.id}")
    
    # Check all autopay records for this user
    all_autopays = db.query(AutoPay).filter(
        AutoPay.user_id == current_user.id
    ).all()
    logger.info(f"User has {len(all_autopays)} autopay records: {[ap.merchant_id for ap in all_autopays]}")
    
    # Find the auto-pay setting
    auto_pay = db.query(AutoPay).filter(
        AutoPay.merchant_id == merchant_id,
        AutoPay.user_id == current_user.id
    ).first()
    
    if not auto_pay:
        logger.warning(f"Autopay not found for merchant_id: {merchant_id}, user_id: {current_user.id}")
        
        # Check if merchant_id is a UUID (merchant's internal ID) instead of Stripe account ID
        if not merchant_id.startswith('acct_'):
            logger.error(f"Frontend sent merchant UUID instead of Stripe Connect Account ID: {merchant_id}")
            logger.error(f"Available merchant IDs for this user: {[ap.merchant_id for ap in all_autopays]}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid merchant_id format. Expected Stripe Connect Account ID (starts with 'acct_'), got merchant UUID instead."
            )
        
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Auto-pay setting not found"
        )
    
    try:
        db.delete(auto_pay)
        db.commit()
        
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete auto-pay setting"
        ) 