from fastapi import APIRouter, Depends, HTTPException, status, Header, Request
from sqlalchemy.orm import Session
from typing import Dict, Any, Optional
from pydantic import BaseModel, Field
from app.db.database import get_db
from app.db.models import IncomingPaymentRequest
from app.dependencies import get_stripe_service, get_webhook_service
from app.services.stripe_service import StripeService
import stripe
import hmac
import hashlib
import logging
import time

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/webhooks", tags=["Webhooks"])


class MerchantCancellationWebhook(BaseModel):
    """Webhook payload from merchant when they cancel a payment"""
    payment_request_id: str = Field(..., description="The payment request ID (merchant's or customer's)")
    merchant_payment_request_id: Optional[str] = Field(None, description="Merchant's internal request ID")
    user_id: str = Field(..., description="User ID")
    merchant_id: str = Field(..., description="Merchant ID or Stripe Connect account")
    status: str = Field(..., description="New status: CANCELLED or FAILED")
    cancellation_reason: Optional[str] = Field(None, description="Reason for cancellation")
    stripe_payment_intent_id: Optional[str] = Field(None, description="Stripe payment intent ID")
    amount: Optional[int] = Field(None, description="Amount in cents")
    currency: Optional[str] = Field(None, description="Currency code")
    cancelled_at: Optional[str] = Field(None, description="Cancellation timestamp")


def verify_merchant_webhook_signature(payload: str, signature: str, timestamp: str, secret: str) -> bool:
    """
    Verify webhook signature from merchant backend
    
    Args:
        payload: Raw JSON payload as string
        signature: Signature header in format "t=timestamp,v1=signature"
        timestamp: Timestamp header
        secret: Webhook secret shared with merchant
        
    Returns:
        True if signature is valid, False otherwise
    """
    try:
        # Parse signature header
        sig_parts = {}
        for part in signature.split(','):
            key, value = part.split('=')
            sig_parts[key] = value
        
        # Verify timestamp is recent (within 5 minutes)
        current_time = int(time.time())
        webhook_time = int(sig_parts.get('t', timestamp))
        if abs(current_time - webhook_time) > 300:  # 5 minutes
            logger.warning(f"Webhook timestamp too old: {current_time - webhook_time}s difference")
            return False
        
        # Reconstruct the signed payload
        message = f"{webhook_time}.{payload}"
        
        # Compute expected signature
        expected_signature = hmac.new(
            secret.encode(),
            message.encode(),
            hashlib.sha256
        ).hexdigest()
        
        # Compare signatures
        received_signature = sig_parts.get('v1')
        is_valid = hmac.compare_digest(expected_signature, received_signature)
        
        if not is_valid:
            logger.warning(f"Signature mismatch. Expected: {expected_signature[:20]}..., Got: {received_signature[:20]}...")
        
        return is_valid
        
    except Exception as e:
        logger.error(f"Error verifying webhook signature: {e}")
        return False


@router.post("/merchant-cancellation")
async def handle_merchant_cancellation(
    request: Request,
    webhook_data: MerchantCancellationWebhook,
    x_webhook_signature: str = Header(None),
    x_webhook_timestamp: str = Header(None),
    db: Session = Depends(get_db)
):
    """
    Handle payment cancellation notifications from merchant backend
    
    This endpoint receives webhooks when:
    - Merchant times out a pending payment (15 min timeout)
    - Merchant manually cancels a payment request
    - Payment fails on merchant side
    """
    try:
        # Verify webhook signature for security
        from app.core.config import settings
        
        if not x_webhook_signature or not x_webhook_timestamp:
            logger.warning("Missing webhook signature headers from merchant")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Missing webhook signature headers"
            )
        
        # Get raw payload for signature verification
        payload = await request.body()
        
        # Verify signature using merchant's webhook secret
        # Note: This is the SAME secret used when customer sends to merchant
        if not verify_merchant_webhook_signature(
            payload.decode(), 
            x_webhook_signature, 
            x_webhook_timestamp,
            settings.merchant_webhook_secret
        ):
            logger.warning("Invalid webhook signature from merchant - possible security threat")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid webhook signature"
            )
        
        logger.info(f"✅ Merchant webhook signature verified - processing cancellation: {webhook_data}")
        
        # Find the payment request by merchant_payment_request_id or our internal ID
        payment_request = None
        
        if webhook_data.merchant_payment_request_id:
            # Try to find by merchant's original request ID
            payment_request = db.query(IncomingPaymentRequest).filter(
                IncomingPaymentRequest.merchant_payment_request_id == webhook_data.merchant_payment_request_id
            ).first()
        
        if not payment_request and webhook_data.payment_request_id:
            # Try to find by our internal ID
            payment_request = db.query(IncomingPaymentRequest).filter(
                IncomingPaymentRequest.id == webhook_data.payment_request_id
            ).first()
        
        if not payment_request:
            logger.error(f"Payment request not found: merchant_id={webhook_data.merchant_payment_request_id}, id={webhook_data.payment_request_id}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Payment request not found"
            )
        
        # Store old status for logging
        old_status = payment_request.status
        
        # Only update if payment is still pending
        if old_status not in ["PENDING"]:
            logger.warning(f"Payment request {payment_request.id} is already in {old_status} status, ignoring cancellation")
            return {
                "message": "Payment request already processed",
                "payment_request_id": payment_request.id,
                "current_status": old_status,
                "ignored": True
            }
        
        # Update status based on merchant's status
        new_status = webhook_data.status.upper()
        if new_status in ["CANCELLED", "CANCELED"]:
            payment_request.status = "FAILED"  # We use FAILED internally for cancelled
        elif new_status in ["FAILED", "TIMEOUT"]:
            payment_request.status = "FAILED"
        else:
            payment_request.status = new_status
        
        # Update timestamp
        from datetime import datetime, timezone
        payment_request.updated_at = datetime.now(timezone.utc)
        
        db.commit()
        
        logger.info(f"✅ Payment request {payment_request.id} cancelled by merchant: {old_status} -> {payment_request.status}")
        logger.info(f"   Reason: {webhook_data.cancellation_reason or 'Not specified'}")
        
        # TODO: Send push notification to customer app about cancellation
        # from app.services.notification_service import send_push_notification
        # await send_push_notification(
        #     user_id=payment_request.user_id,
        #     title="Payment Request Cancelled",
        #     body=f"Your payment request for ${payment_request.amount/100:.2f} was cancelled by the merchant"
        # )
        
        return {
            "message": "Payment cancellation processed successfully",
            "payment_request_id": payment_request.id,
            "old_status": old_status,
            "new_status": payment_request.status,
            "cancellation_reason": webhook_data.cancellation_reason
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error processing merchant cancellation webhook: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error processing cancellation"
        )




@router.post("/stripe")
async def handle_stripe_webhook(
    request: Request,
    stripe_signature: str = Header(None, alias="Stripe-Signature"),
    db: Session = Depends(get_db),
    stripe_service: StripeService = Depends(get_stripe_service)
):
    """
    Handle incoming webhooks from Stripe.
    This endpoint verifies the signature and processes the event.
    """
    from app.core.config import settings
    from fastapi.responses import JSONResponse

    if not stripe_signature:
        logger.warning("Missing Stripe-Signature header")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, 
            detail="Missing Stripe-Signature header"
        )

    payload = await request.body()

    try:
        event = stripe.Webhook.construct_event(
            payload=payload, 
            sig_header=stripe_signature, 
            secret=settings.stripe_webhook_secret
        )
        logger.info(f"✅ Stripe webhook signature verified. Event type: {event['type']}")
    except ValueError as e:
        # Invalid payload
        logger.error(f"Error verifying Stripe webhook: Invalid payload - {e}")
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid payload")
    except stripe.error.SignatureVerificationError as e:
        # Invalid signature
        logger.error(f"Error verifying Stripe webhook: Invalid signature - {e}")
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid signature")
    except Exception as e:
        logger.error(f"Unexpected error during webhook construction: {e}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Internal server error")

    # Handle the event
    try:
        event_type = event['type']
        event_data = event['data']
        
        stripe_service.handle_webhook_event(event_type, event_data, db)
        
        return {"status": "success", "event_received": event_type}
        
    except Exception as e:
        logger.error(f"Error processing Stripe webhook event {event['id']}: {e}", exc_info=True)
        # Return a 200 to Stripe to prevent retries for processing errors,
        # but log it as a server error.
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"status": "error", "message": "Error processing event"}
        )


@router.get("/health")
async def webhook_health():
    """Health check endpoint for webhook service"""
    return {
        "status": "healthy",
        "service": "webhooks",
        "endpoints": {
            "merchant_cancellation": "/webhooks/merchant-cancellation"
        }
    }
