from datetime import datetime, timedelta
import json
from math import ceil

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy.sql import func

from app.db.database import get_db
from app.db.models import User
from app.schemas.user import UserResponse, UserUpdate, UserProfileUpdate
from app.schemas.payment import FaceStatusResponse
from app.dependencies import get_current_user

router = APIRouter(tags=["Users"])

DELETION_GRACE_PERIOD_DAYS = 14


@router.put("/users/me/profile")
def update_user_profile(
    profile_data: UserProfileUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Update user's full name with a 90-day cooldown."""
    now = datetime.utcnow()
    cooldown_period = timedelta(days=90)

    if current_user.name_last_updated_at:
        time_since_change = now - current_user.name_last_updated_at
        if time_since_change < cooldown_period:
            remaining = cooldown_period - time_since_change
            days_remaining = max(1, ceil(remaining.total_seconds() / 86400))
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail=f"You can change your name again in {days_remaining} day(s)."
            )

    current_user.full_name = profile_data.full_name
    current_user.name_last_updated_at = now
    current_user.updated_at = func.now()
    db.commit()

    return {"success": True, "message": "Your name has been updated."}


@router.get("/users/me")
def get_current_user_profile(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get current user profile"""
    # Split full_name back to first_name and last_name for frontend compatibility
    name_parts = current_user.full_name.split(' ', 1) if current_user.full_name else ['', '']
    first_name = name_parts[0] if len(name_parts) > 0 else ''
    last_name = name_parts[1] if len(name_parts) > 1 else ''
    
    # Handle JSON deserialization for profile_info
    profile_info = None
    if current_user.profile_info:
        try:
            profile_info = json.loads(current_user.profile_info)
        except:
            profile_info = None
    
    now = datetime.utcnow()
    pending_deletion = (
        current_user.deletion_effective_at is not None
        and current_user.deleted_at is None
        and current_user.deletion_effective_at > now
    )

    return {
        "id": str(current_user.id),
        "phone_number": current_user.phone_number,
        "first_name": first_name,
        "last_name": last_name,
        "email": current_user.email,
        "profile_info": profile_info,
        "is_verified": True,
        "has_face_registered": current_user.face_active,
        "is_active": True,
        "face_active": current_user.face_active,
        "face_id": current_user.face_id,
        "created_at": current_user.created_at.isoformat(),
        "updated_at": current_user.updated_at.isoformat(),
        "pending_deletion": pending_deletion,
        "deletion_requested_at": current_user.deletion_requested_at.isoformat() if current_user.deletion_requested_at else None,
        "scheduled_deletion_at": current_user.deletion_effective_at.isoformat() if current_user.deletion_effective_at else None
    }


@router.post("/users/me/deletion-request")
def request_account_deletion(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Schedule account deletion after the grace period."""
    now = datetime.utcnow()

    if current_user.deleted_at is not None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Account already deleted"
        )

    if (
        current_user.deletion_effective_at is not None
        and current_user.deletion_effective_at > now
        and current_user.deleted_at is None
    ):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Deletion already scheduled"
        )

    deletion_requested_at = now
    deletion_effective_at = now + timedelta(days=DELETION_GRACE_PERIOD_DAYS)

    current_user.deletion_requested_at = deletion_requested_at
    current_user.deletion_effective_at = deletion_effective_at
    current_user.deleted_at = None
    current_user.updated_at = func.now()

    db.commit()

    return {
        "success": True,
        "message": "Account deletion scheduled",
        "scheduled_deletion_at": deletion_effective_at.isoformat()
    }


@router.post("/users/me/deletion-cancel")
def cancel_account_deletion(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Cancel a previously scheduled account deletion."""
    now = datetime.utcnow()

    if current_user.deletion_effective_at is None or current_user.deleted_at is not None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No pending deletion to cancel"
        )

    if current_user.deletion_effective_at <= now:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Deletion can no longer be cancelled"
        )

    current_user.deletion_requested_at = None
    current_user.deletion_effective_at = None
    current_user.deleted_at = None
    current_user.updated_at = func.now()

    db.commit()

    return {
        "success": True,
        "message": "Account deletion cancelled"
    }


@router.post("/users/me/push-token")
def update_push_token(
    push_token: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Update user's push notification token"""
    try:
        # Update push token logic here
        # For now, just return success
        return {"success": True, "message": "Push token updated successfully"}
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update push token"
        )


@router.get("/users/me/face-status", response_model=FaceStatusResponse)
def get_user_face_status(
    current_user: User = Depends(get_current_user)
):
    """Get user's face enrollment status"""
    return FaceStatusResponse(
        enrolled=current_user.face_active,
        face_id=current_user.face_id,
        face_created_at=current_user.face_created_at
    )


@router.put("/users/me/face-status")
def update_face_status(
    face_status: dict,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Update user's face registration status"""
    try:
        # Update face status in database
        current_user.face_active = face_status.get("has_face_registered", False)
        if face_status.get("face_id"):
            current_user.face_id = face_status["face_id"]
        if face_status.get("has_face_registered"):
            current_user.face_created_at = func.now()
        
        current_user.updated_at = func.now()
        db.commit()
        
        return {"success": True, "message": "Face status updated successfully"}
        
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update face status"
        )


@router.delete("/users/me/face-enrollment", status_code=status.HTTP_204_NO_CONTENT)
def delete_face_enrollment(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Delete user's face enrollment"""
    if not current_user.face_active:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No face enrollment found"
        )
    
    # Reset face enrollment fields - integrate with your face API here
    current_user.face_id = None
    current_user.face_active = False
    current_user.face_created_at = None
    
    db.commit()
    
    return {"message": "Face enrollment deleted"} 