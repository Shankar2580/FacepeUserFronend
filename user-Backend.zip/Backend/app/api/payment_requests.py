from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Dict, Any
import uuid
from datetime import timedelta
from app.db.database import get_db
from app.db.models import User, IncomingPaymentRequest
from app.dependencies import get_current_user

router = APIRouter(prefix="/users/me/payment-requests", tags=["Payment Requests"])


@router.get("/", response_model=List[Dict[str, Any]])
def get_payment_requests(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get all payment requests for the current user"""
    payment_requests = db.query(IncomingPaymentRequest).filter(
        IncomingPaymentRequest.user_id == current_user.id
    ).order_by(IncomingPaymentRequest.created_at.desc()).all()
    
    # Helper function to get merchant name from ID (now handles Stripe Connect account IDs)
    def get_merchant_name(merchant_id: str) -> str:
        """Convert merchant_id to a friendly name"""
        # Handle Stripe Connect account IDs
        if merchant_id.startswith("acct_"):
            # For now, return the Connect account ID
            # In production, you'd have a merchant lookup service
            return f"Merchant ({merchant_id[:12]}...)"
        
        # Legacy merchant UUID mapping (keep for backward compatibility)
        merchant_map = {
            "merchant_starbucks_001": "Starbucks",
            "merchant_amazon_001": "Amazon",
            "merchant_uber_001": "Uber",
            "merchant_netflix_001": "Netflix",
            "merchant_target_001": "Target",
            "merchant_walmart_001": "Walmart",
            "merchant_mcdonalds_001": "McDonald's",
        }
        return merchant_map.get(merchant_id, merchant_id.replace("merchant_", "").replace("_001", "").title())
    
    # Transform the data to match frontend expectations
    result = []
    for request in payment_requests:
        # Calculate expiry (24 hours from creation for now)
        expires_at = request.created_at + timedelta(hours=24)
        
        # Convert database model to response format that matches PaymentRequest interface
        result.append({
            "id": request.id,
            "user_id": request.user_id,
            "merchant_name": get_merchant_name(request.merchant_id),
            "merchant_id": request.merchant_id,
            "amount": float(request.amount / 100),  # Convert cents to dollars for frontend
            "currency": request.currency.lower(),
            "description": request.description or "",
            "status": request.status.lower(),  # Convert to lowercase for frontend (but keep uppercase in DB)
            "expires_at": expires_at.isoformat(),  # ISO format without Z
            "created_at": request.created_at.isoformat(),
            "updated_at": request.updated_at.isoformat()
        })
    
    return result 