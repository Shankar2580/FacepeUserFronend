from typing import List, Union
import uuid

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.db.models import User, IncomingPaymentRequest, AutoPayApproval, PaymentMethod
from app.schemas.payment import (
    IncomingPaymentRequestCreate, IncomingPaymentRequestResponse,
    PaymentApprovalResponse, PaymentDeclineResponse
)
from app.schemas.common import ErrorResponse
from app.dependencies import get_current_user, get_current_merchant, get_stripe_service, get_webhook_service
from app.services.stripe_service import StripeService
from app.services.webhook_service import WebhookService
from app.core.security import TokenData

router = APIRouter(tags=["Payments"])


@router.post("/users/me/payment-methods/fix-default")
def fix_default_payment_method(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Fix default payment method if none is set"""
    import logging
    logger = logging.getLogger(__name__)
    
    logger.info(f"Fixing default payment method for user {current_user.id}")
    
    # Get all payment methods for user
    payment_methods = db.query(PaymentMethod).filter(
        PaymentMethod.user_id == current_user.id
    ).all()
    
    if not payment_methods:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No payment methods found. Please add a payment method first."
        )
    
    # Check if any is default
    default_pm = None
    for pm in payment_methods:
        if pm.is_default:
            default_pm = pm
            break
    
    if not default_pm:
        # Set the first payment method as default
        payment_methods[0].is_default = True
        db.commit()
        logger.info(f"Set payment method {payment_methods[0].id} as default for user {current_user.id}")
        return {
            "success": True,
            "message": f"Set payment method ending in {payment_methods[0].last4} as default",
            "default_payment_method_id": payment_methods[0].id
        }
    else:
        return {
            "success": True,
            "message": f"Default payment method already set (ending in {default_pm.last4})",
            "default_payment_method_id": default_pm.id
        }


@router.post("/users/me/payments/{request_id}/approve", response_model=PaymentApprovalResponse)
async def approve_payment_request(
    request_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
    stripe_service: StripeService = Depends(get_stripe_service),
    webhook_service: WebhookService = Depends(get_webhook_service),
):
    """Approve a pending payment request"""
    import logging
    logger = logging.getLogger(__name__)
    
    logger.info(f"Payment approval attempt for request {request_id} by user {current_user.id}")
    
    # Find the payment request
    payment_request = db.query(IncomingPaymentRequest).filter(
        IncomingPaymentRequest.id == request_id,
        IncomingPaymentRequest.user_id == current_user.id,
        IncomingPaymentRequest.status == "PENDING"
    ).first()
    
    if not payment_request:
        logger.error(f"Payment request {request_id} not found or not pending for user {current_user.id}")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Payment request not found or not pending"
        )
    
    # Check if user has a default payment method
    default_pm = db.query(PaymentMethod).filter(
        PaymentMethod.user_id == current_user.id,
        PaymentMethod.is_default == True
    ).first()
    
    # Log payment method status
    all_payment_methods = db.query(PaymentMethod).filter(
        PaymentMethod.user_id == current_user.id
    ).all()
    
    logger.info(f"User {current_user.id} has {len(all_payment_methods)} payment methods")
    for pm in all_payment_methods:
        logger.info(f"  PM {pm.id}: {pm.stripe_payment_method_id}, default={pm.is_default}")
    
    if not default_pm:
        logger.error(f"No default payment method found for user {current_user.id}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No default payment method found. Please add a payment method and set it as default."
        )
    
    try:
        # Process manual payment
        payment_result = stripe_service.process_manual_payment(
            current_user,
            payment_request,
            db
        )
        
        if payment_result["success"]:
            # 🚀 NOTIFY MERCHANT BACKEND - Payment Completed
            webhook_success = await webhook_service.notify_payment_completed(
                payment_request, 
                payment_result["payment_intent_id"]
            )
            
            if webhook_success:
                logger.info("Merchant notified of payment completion")
            else:
                logger.warning("Failed to notify merchant, but payment was successful")
            
            return PaymentApprovalResponse(
                status="COMPLETED",
                transaction_id=payment_result["payment_intent_id"]
            )
        else:
            # Payment failed
            payment_request.status = "FAILED"
            db.commit()
            
            # Extract failure details from payment result
            error_message = payment_result.get('error', 'Payment processing failed')
            error_code = payment_result.get('error_code', 'payment_error')
            
            # 🚀 NOTIFY MERCHANT BACKEND - Payment Failed (with failure reason)
            webhook_success = await webhook_service.notify_payment_failed(
                payment_request,
                failure_reason=error_code,
                failure_message=error_message
            )
            
            if webhook_success:
                logger.info(f"Merchant notified of payment failure: {error_code}")
            else:
                logger.warning("Failed to notify merchant of payment failure")
            
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Payment failed: {error_message}"
            )
            
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to process payment"
        )


@router.post("/users/me/payments/{request_id}/decline", response_model=PaymentDeclineResponse)
async def decline_payment_request(
    request_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
    webhook_service: WebhookService = Depends(get_webhook_service),
):
    """Decline a pending payment request"""
    import logging
    logger = logging.getLogger(__name__)
    # Find the payment request
    payment_request = db.query(IncomingPaymentRequest).filter(
        IncomingPaymentRequest.id == request_id,
        IncomingPaymentRequest.user_id == current_user.id,
        IncomingPaymentRequest.status == "PENDING"
    ).first()
    
    if not payment_request:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Payment request not found or not pending"
        )
    
    try:
        # Update status to declined/failed
        payment_request.status = "FAILED"
        
        # Update timestamp
        from sqlalchemy.sql import func
        payment_request.updated_at = func.now()
        
        db.commit()
        
        # 🚀 NOTIFY MERCHANT BACKEND - Payment Declined
        webhook_success = await webhook_service.notify_payment_declined(payment_request)
        
        if webhook_success:
            logger.info("Merchant notified of payment decline")
        else:
            logger.warning("Failed to notify merchant of payment decline")
        
        return PaymentDeclineResponse(status="DECLINED")
        
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to decline payment request"
        ) 