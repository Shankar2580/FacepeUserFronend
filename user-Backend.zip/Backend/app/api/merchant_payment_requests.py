from fastapi import APIRouter, Depends, HTTPException, status, Query, BackgroundTasks
from sqlalchemy.orm import Session
from typing import Dict, Any, Optional, List
from pydantic import BaseModel, Field
from app.db.database import get_db
from app.db.models import User, IncomingPaymentRequest, AutoPay
from app.services.stripe_service import stripe_service
from app.services.webhook_service import webhook_service
import uuid
from app.dependencies import get_current_user

router = APIRouter(prefix="/payment-requests", tags=["Merchant Payment Requests"])


class MerchantPaymentRequestCreate(BaseModel):
    user_id: str = Field(..., description="Target user ID")
    stripe_connect_account_id: str = Field(..., description="Merchant's Stripe Connect account ID")
    business_name: str = Field(..., description="Merchant business name for display (REQUIRED)")
    business_address: Optional[str] = Field(None, description="Business address for customer context")
    business_category: Optional[str] = Field(None, description="Business category (e.g., 'Restaurant', 'Retail', 'Gas Station')")
    business_phone: Optional[str] = Field(None, description="Business contact phone number")
    business_website: Optional[str] = Field(None, description="Business website URL")
    amount: float = Field(..., gt=0, description="Amount in dollars (e.g., 1.50 for $1.50)")
    currency: str = Field(default="USD", description="Currency code")
    description: Optional[str] = Field(None, description="Payment description/invoice details")
    order_number: Optional[str] = Field(None, description="Merchant's order/invoice number for reference")
    items: Optional[List[Dict[str, Any]]] = Field(None, description="List of items being purchased (optional)")
    face_scan_id: str = Field(..., description="Face scan ID from merchant terminal")
    stripe_payment_intent_id: Optional[str] = Field(None, description="Stripe payment intent ID")
    merchant_payment_request_id: str = Field(..., description="Merchant's internal request ID")
    merchant_id: Optional[str] = Field(None, description="Internal merchant ID for reference")
    amount_format: Optional[str] = Field(default="dollars", description="Specify 'dollars' or 'cents' to avoid confusion")
    expires_at: Optional[str] = Field(None, description="Payment request expiration time (ISO format)")
    
    # Additional fields for better customer experience
    receipt_email: Optional[str] = Field(None, description="Email to send receipt to customer")
    tip_enabled: Optional[bool] = Field(False, description="Whether tipping is enabled for this transaction")
    tip_suggestions: Optional[List[float]] = Field(None, description="Suggested tip percentages [15, 18, 20]")
    loyalty_points_earned: Optional[int] = Field(None, description="Loyalty points customer will earn")
    discount_applied: Optional[float] = Field(None, description="Discount amount applied")


@router.post("/", response_model=Dict[str, Any])
async def create_payment_request(
    payment_data: MerchantPaymentRequestCreate,
    db: Session = Depends(get_db)
):
    """
    Create a payment request from merchant to user
    This endpoint is called by merchant services
    
    NEW: Merchants now send their Stripe Connect account ID directly
    This eliminates merchant UUID mapping and makes transactions seamless
    """
    import logging
    logger = logging.getLogger(__name__)
    try:
        # Validate Stripe Connect account ID format
        if not payment_data.stripe_connect_account_id.startswith("acct_"):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid Stripe Connect account ID format. Must start with 'acct_'"
            )
        
        # Find the target user
        target_user = db.query(User).filter(
            User.id == payment_data.user_id
        ).first()
        
        if not target_user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )
        
        # Check if user has face recognition enabled (optional check)
        if not target_user.face_active:
            return {
                "success": False,
                "action": "please_register_face"
            }
        
        # Smart amount conversion to handle different merchant integrations
        # Handle explicit format specification or auto-detect format
        if payment_data.amount_format == "cents":
            # Merchant explicitly said they're sending cents
            amount_in_cents = int(payment_data.amount)
            logger.info(f"Merchant specified cents format: {payment_data.amount} cents = ${payment_data.amount/100:.2f}")
        elif payment_data.amount_format == "dollars":
            # Merchant explicitly said they're sending dollars
            amount_in_cents = int(payment_data.amount * 100)
            logger.info(f"Merchant specified dollars format: ${payment_data.amount} = {amount_in_cents} cents")
        else:
            # Auto-detect format (fallback for legacy integrations)
            # If amount is a whole number >= 100, likely sent cents instead of dollars
            if payment_data.amount >= 100 and payment_data.amount == int(payment_data.amount):
                logger.warning(f"Auto-detected: ${payment_data.amount} looks like cents (whole number >= 100)")
                amount_in_cents = int(payment_data.amount)  # Use as-is (already in cents)
            else:
                logger.info(f"Auto-detected: ${payment_data.amount} looks like dollars")
                amount_in_cents = int(payment_data.amount * 100)  # Convert dollars to cents
        
        # Create payment request in database
        # Store Stripe Connect account ID in merchant_id field for now
        # TODO: Add dedicated stripe_connect_account_id column to database

        # Check for auto-pay settings
        auto_pay_enabled = False
        auto_pay_setting = db.query(AutoPay).filter(
            AutoPay.user_id == target_user.id,
            AutoPay.merchant_id == payment_data.stripe_connect_account_id,
            AutoPay.is_enabled == True
        ).first()

        if auto_pay_setting:
            if auto_pay_setting.max_amount is None or amount_in_cents <= auto_pay_setting.max_amount:
                auto_pay_enabled = True

        payment_request = IncomingPaymentRequest(
            user_id=target_user.id,
            merchant_id=payment_data.stripe_connect_account_id,  # Store Connect account ID directly
            merchant_payment_request_id=payment_data.merchant_payment_request_id,  # Store merchant's original ID
            business_name=payment_data.business_name,  # Store business name from merchant
            amount=amount_in_cents,  # Amount in cents
            currency=payment_data.currency.upper(),
            description=payment_data.description or f"Payment request from {payment_data.business_name}",
            face_scan_id=payment_data.face_scan_id,
            is_auto_paid=auto_pay_enabled,  # Set based on auto-pay check
            status="PENDING",
            stripe_payment_intent_id=payment_data.stripe_payment_intent_id
        )
        
        db.add(payment_request)
        db.commit()
        db.refresh(payment_request)
        
        # If auto-pay is enabled, process the payment immediately
        if auto_pay_enabled:
            payment_result = stripe_service.process_auto_payment(
                target_user,
                payment_request,
                db
            )

            if payment_result.get("success"):
                await webhook_service.notify_payment_completed(
                    payment_request,
                    payment_result.get("payment_intent_id")
                )
                return {
                    "success": True,
                    "request_id": payment_request.id,
                    "status": "AUTO_PAID",
                    "message": "Auto-payment processed successfully."
                }
            else:
                # Auto-payment failed, leave as pending for manual approval
                # 🔧 FIX: Don't notify merchant on auto-payment failure to prevent state mismatch
                # Both merchant and customer backends will stay in PENDING status
                # If customer manually approves later, merchant gets COMPLETED webhook
                # If customer never approves, timeout checker (15 min) will cancel and notify both sides
                failure_reason = payment_result.get("error", "Unknown error")
                logger.warning(f"Auto-payment failed for request {payment_request.id}: {failure_reason}")
                logger.info(f"Payment stays PENDING for manual approval. Merchant will NOT be notified of auto-payment failure.")
                
                # await webhook_service.notify_payment_failed(payment_request)  # ❌ REMOVED - causes state mismatch
                
                return {
                    "success": False,
                    "request_id": payment_request.id,
                    "status": "PENDING",
                    "auto_payment_attempted": True,
                    "auto_payment_failed": True,
                    "failure_reason": failure_reason,
                    "message": f"Auto-payment failed ({failure_reason}). Request is pending manual approval."
                }

        # TODO: Send push notification to user about new payment request
        
        return {
            "success": True,
            "request_id": payment_request.id,
            "status": "PENDING",
            "message": f"Payment request created for {target_user.email}",
            "business_name": payment_data.business_name,
            "stripe_connect_account": payment_data.stripe_connect_account_id,
            "user_notified": True  # In production, this would be actual notification status
        }
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"Error creating payment request: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create payment request"
        )