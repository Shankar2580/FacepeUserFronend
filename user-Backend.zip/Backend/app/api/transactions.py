import base64
from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy import and_, or_
from sqlalchemy.orm import Session
from typing import List, Optional, Tuple
from app.db.database import get_db
from app.db.models import User, Transaction, PaymentMethod
from app.schemas.transaction import TransactionResponse, TransactionDetailResponse, TransactionListResponse
from app.schemas.payment import PaymentMethodResponse
from app.schemas.common import TransactionStatus
from app.dependencies import get_current_user
from app.core.config import Settings

settings = Settings()

router = APIRouter(tags=["Transactions"])



def _encode_cursor(timestamp: datetime, transaction_id: str) -> str:
    payload = f"{timestamp.isoformat()}|{transaction_id}"
    return base64.urlsafe_b64encode(payload.encode()).decode()


def _decode_cursor(cursor: str) -> Tuple[datetime, str]:
    try:
        decoded = base64.urlsafe_b64decode(cursor.encode()).decode()
        timestamp_str, transaction_id = decoded.split("|", 1)
        return datetime.fromisoformat(timestamp_str), transaction_id
    except Exception:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid cursor")


@router.get("/users/me/transactions", response_model=TransactionListResponse)
def get_transactions(
    status_filter: Optional[str] = Query(None, description="Filter by status: 'completed', 'pending', 'failed', 'cancelled'"),
    time_filter: Optional[str] = Query(
        None,
        description="Filter by time period: 'daily' (today), 'weekly' (current week), 'monthly' (current month)"
    ),
    payment_method_id: Optional[str] = Query(None, description="Filter by a specific payment method ID"),
    cursor: Optional[str] = Query(None, description="Pagination cursor for fetching the next page of results"),
    limit: int = Query(default=50, ge=1, le=100, description="Maximum number of transactions to return"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get transactions for the current user with optional filtering and cursor-based pagination."""
    
    query = db.query(Transaction).filter(Transaction.user_id == current_user.id)

    # Apply time filter if provided
    if payment_method_id:
        query = query.filter(Transaction.payment_method_id == payment_method_id)

    # Apply time filter if provided
    if time_filter:
        now = datetime.utcnow()
        normalized_filter = time_filter.lower()
        start_time: Optional[datetime] = None

        if normalized_filter == 'daily':
            start_time = datetime.combine(now.date(), datetime.min.time())
        elif normalized_filter == 'weekly':
            start_of_week = now.date() - timedelta(days=now.weekday())
            start_time = datetime.combine(start_of_week, datetime.min.time())
        elif normalized_filter == 'monthly':
            start_of_month = now.replace(day=1).date()
            start_time = datetime.combine(start_of_month, datetime.min.time())

        if start_time:
            query = query.filter(Transaction.timestamp >= start_time)

    # Apply cursor filter if provided
    if cursor:
        cursor_timestamp, cursor_transaction_id = _decode_cursor(cursor)
        query = query.filter(
            or_(
                Transaction.timestamp < cursor_timestamp,
                and_(
                    Transaction.timestamp == cursor_timestamp,
                    Transaction.id < cursor_transaction_id
                )
            )
        )

    # Apply status filter if provided
    if status_filter:
        # Map frontend status names to database status values
        status_mapping = {
            'completed': 'SUCCEEDED',
            'pending': 'PENDING',
            'failed': 'FAILED',
            'cancelled': 'CANCELLED'
        }
        
        db_status = status_mapping.get(status_filter.lower())
        if db_status:
            query = query.filter(Transaction.status == db_status)

    ordered_query = query.order_by(Transaction.timestamp.desc(), Transaction.id.desc())
    transaction_rows = ordered_query.limit(limit + 1).all()

    has_more = len(transaction_rows) > limit
    next_cursor = None
    if has_more:
        next_transaction = transaction_rows[limit]
        next_cursor = _encode_cursor(next_transaction.timestamp, next_transaction.id)
        transaction_rows = transaction_rows[:limit]

    # Convert to response format
    response_data: List[TransactionResponse] = []
    for transaction in transaction_rows:
        # Ensure status is a valid TransactionStatus enum value
        db_status = transaction.status
        if db_status not in ['SUCCEEDED', 'FAILED', 'PENDING', 'CANCELLED']:
            db_status = 'FAILED'  # Default fallback
        
        # Map backend status to frontend expected strings
        status_to_frontend = {
            'SUCCEEDED': 'completed',
            'FAILED': 'failed', 
            'PENDING': 'pending',
            'CANCELLED': 'cancelled'
        }
        frontend_status = status_to_frontend.get(db_status, 'failed')
        
        response_data.append(TransactionResponse(
            id=transaction.id,
            user_id=transaction.user_id,
            merchant_id=transaction.merchant_id,
            merchant_name=transaction.merchant_name or "Unknown Merchant",
            amount=transaction.amount,
            currency=transaction.currency,
            status=frontend_status,
            payment_method_id=transaction.payment_method_id,
            stripe_payment_intent_id=transaction.stripe_transaction_id,
            description=transaction.description,
            created_at=transaction.timestamp,
            updated_at=transaction.timestamp  # Use same timestamp for both
        ))
    
    return TransactionListResponse(
        transactions=response_data,
        next_cursor=next_cursor,
        has_more=has_more
    )


@router.get("/users/me/transactions/{transaction_id}", response_model=TransactionDetailResponse)
def get_transaction_detail(
    transaction_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get detailed information about a specific transaction"""
    
    # Find the transaction
    transaction = db.query(Transaction).filter(
        Transaction.id == transaction_id,
        Transaction.user_id == current_user.id
    ).first()
    
    if not transaction:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Transaction not found"
        )
    
    # Get payment method details if available
    payment_method_info = None
    if transaction.payment_method_id:
        payment_method = db.query(PaymentMethod).filter(
            PaymentMethod.id == transaction.payment_method_id
        ).first()
        
        if payment_method:
            payment_method_info = PaymentMethodResponse(
                id=payment_method.id,
                card_brand=payment_method.brand,
                card_last_four=payment_method.last4,
                card_exp_month=payment_method.exp_month,
                card_exp_year=payment_method.exp_year,
                is_default=payment_method.is_default,
                created_at=payment_method.created_at,
            )
    
    # Ensure status is a valid value and map to frontend format
    db_status = transaction.status
    if db_status not in ['SUCCEEDED', 'FAILED', 'PENDING', 'CANCELLED']:
        db_status = 'FAILED'  # Default fallback
    
    # Map backend status to frontend expected strings
    status_to_frontend = {
        'SUCCEEDED': 'completed',
        'FAILED': 'failed',
        'PENDING': 'pending',
        'CANCELLED': 'cancelled'
    }
    frontend_status = status_to_frontend.get(db_status, 'failed')
    
    # Generate receipt URL (in real app would come from Stripe)
    receipt_url = None
    if transaction.stripe_transaction_id:
        receipt_url = settings.stripe_receipt_url.format(transaction.stripe_transaction_id)
    
    return TransactionDetailResponse(
        id=transaction.id,
        created_at=transaction.timestamp,
        updated_at=None,
        user_id=transaction.user_id,
        merchant_id=transaction.merchant_id,
        merchant_name=transaction.merchant_name or "Unknown Merchant",
        amount=transaction.amount,
        currency=transaction.currency,
        status=frontend_status,
        payment_method_id=transaction.payment_method_id,
        stripe_transaction_id=transaction.stripe_transaction_id,
        description=transaction.description,
        is_auto_paid=transaction.is_auto_paid,
        timestamp=transaction.timestamp,
        payment_method=payment_method_info,
        receipt_url=receipt_url
    ) 