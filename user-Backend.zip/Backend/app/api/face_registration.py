from fastapi import APIRouter, Depends, HTTPException, status, File, UploadFile, Form
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session
from sqlalchemy.sql import func
import httpx
import asyncio
import os
from app.dependencies import get_current_user
from app.db.database import get_db
from app.db.models import User
from app.core.config import Settings
from app.core.security import verify_pin
import logging

settings = Settings()

router = APIRouter(tags=["Face Registration"])
logger = logging.getLogger(__name__)

# Face Recognition API Configuration
FACE_API_BASE_URL = settings.face_api_url

@router.post("/face/register")
async def register_face_proxy(
    user_id: str = Form(...),
    name: str = Form(...),
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Proxy endpoint for face registration.
    Forwards the request to the external face recognition API.
    """
    logger.info(f"Received face registration request for user_id: {user_id}, name: {name}, filename: {file.filename}")
    try:
        # Verify user_id matches current user
        if user_id != str(current_user.id):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="User ID mismatch"
            )
        
        # Read file content
        file_content = await file.read()
        
        if not current_user.pin_hash:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="PIN not set. Please set your PIN first before registering your face."
            )

        # Create multipart form data for the external API
        files = {
            'file': (file.filename, file_content, file.content_type)
        }
        data = {
            'user_id': user_id,
            'name': name,
        }
        
        # Make request to external face recognition API
        face_api_url = f"{FACE_API_BASE_URL}/fr/api/v1/face/register"
        logger.info(f"Calling face-rec service register at: {face_api_url}")
        
        async with httpx.AsyncClient(verify=False) as client:  # verify=False for self-signed certs
            response = await client.post(
                face_api_url,
                data=data,
                files=files,
                timeout=30.0
            )
        
        logger.info(f"Face-rec register response: status={response.status_code}")
        
        # Check if the request was successful
        if response.status_code == 200:
            response_data = response.json()
            
            # Update user's face status in database
            current_user.face_active = True
            current_user.face_id = response_data.get('embedding_id')
            current_user.face_created_at = func.now()
            current_user.updated_at = func.now()

            logger.info(f"Face registration successful for user_id: {user_id}")
            db.commit()
            db.refresh(current_user)
            
            return JSONResponse(
                status_code=200,
                content={
                    "success": True,
                    "message": "Face registration successful",
                    "data": response_data
                }
            )
        else:
            # Forward the error from the face recognition API
            return JSONResponse(
                status_code=response.status_code,
                content={
                    "success": False,
                    "message": "Face registration failed",
                    "error": response.text
                }
            )
    
    except httpx.TimeoutException:
        raise HTTPException(
            status_code=status.HTTP_504_GATEWAY_TIMEOUT,
            detail="Face recognition API timeout"
        )
    except httpx.RequestError as e:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"Face recognition API connection error: {str(e)}"
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Face registration failed: {str(e)}"
        )


@router.put("/face/update")
async def update_face_proxy(
    user_id: str = Form(...),
    name: str = Form(...),
    pin: str = Form(...),
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Proxy endpoint for face update.
    Forwards the request to the external face recognition API.
    """
    logger.info(f"Received face update request for user_id: {user_id}, name: {name}, filename: {file.filename}")
    try:
        # Verify user_id matches current user
        if user_id != str(current_user.id):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="User ID mismatch"
            )
        
        # Check if user has existing face registration
        if not current_user.face_active:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No existing face registration found. Please register face first."
            )
        
        # Read file content
        file_content = await file.read()
        
        if not current_user.pin_hash:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="PIN not set. Please set your PIN first before updating your face."
            )

        if not verify_pin(pin, current_user.pin_hash):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid PIN provided."
            )

        # Create multipart form data for the external API
        files = {
            'file': (file.filename, file_content, file.content_type)
        }
        data = {
            'user_id': user_id,
            'name': name,
        }
        
        # Make request to external face recognition API
        face_api_url = f"{FACE_API_BASE_URL}/fr/api/v1/face/update-face"
        logger.info(f"Calling face-rec service update at: {face_api_url}")
        
        async with httpx.AsyncClient(verify=False) as client:  # verify=False for self-signed certs
            response = await client.put(
                face_api_url,
                data=data,
                files=files,
                timeout=30.0
            )
        
        logger.info(f"Face-rec update response: status={response.status_code}")
        
        # Check if the request was successful
        if response.status_code == 200:
            response_data = response.json()
            
            # Update user's face information in database
            current_user.face_id = response_data.get('embedding_id')
            current_user.updated_at = func.now()
            
            db.commit()
            db.refresh(current_user)
            
            return JSONResponse(
                status_code=200,
                content={
                    "success": True,
                    "message": "Face update successful",
                    "data": response_data
                }
            )
        else:
            # Forward the error from the face recognition API
            return JSONResponse(
                status_code=response.status_code,
                content={
                    "success": False,
                    "message": "Face update failed",
                    "error": response.text
                }
            )
    
    except httpx.TimeoutException:
        raise HTTPException(
            status_code=status.HTTP_504_GATEWAY_TIMEOUT,
            detail="Face recognition API timeout"
        )
    except httpx.RequestError as e:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"Face recognition API connection error: {str(e)}"
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Face update failed: {str(e)}"
        )


@router.delete("/face/delete")
async def delete_face_proxy(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Proxy endpoint for face deletion.
    Forwards the request to the external face recognition API.
    """
    logger.info(f"Received face deletion request for user_id: {current_user.id}")
    try:
        # Check if user has existing face registration
        if not current_user.face_active:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No existing face registration found."
            )
        
        # Make request to external face recognition API
        face_api_url = f"{FACE_API_BASE_URL}/fr/api/v1/face/delete-face/{current_user.id}"
        logger.info(f"Calling face-rec service delete at: {face_api_url}")
        
        async with httpx.AsyncClient(verify=False) as client:  # verify=False for self-signed certs
            response = await client.delete(
                face_api_url,
                timeout=30.0
            )
        
        logger.info(f"Face-rec delete response: status={response.status_code}")
        
        # Check if the request was successful
        if response.status_code == 200:
            response_data = response.json()
            
            # Update user's face status in database - reset face enrollment
            current_user.face_active = False
            current_user.face_id = None
            current_user.face_created_at = None
            current_user.updated_at = func.now()
            
            db.commit()
            db.refresh(current_user)
            
            return JSONResponse(
                status_code=200,
                content={
                    "success": True,
                    "message": "Face deletion successful",
                    "data": response_data
                }
            )
        else:
            # Forward the error from the face recognition API
            return JSONResponse(
                status_code=response.status_code,
                content={
                    "success": False,
                    "message": "Face deletion failed",
                    "error": response.text
                }
            )
    
    except httpx.TimeoutException:
        raise HTTPException(
            status_code=status.HTTP_504_GATEWAY_TIMEOUT,
            detail="Face recognition API timeout"
        )
    except httpx.RequestError as e:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"Face recognition API connection error: {str(e)}"
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Face deletion failed: {str(e)}"
        ) 