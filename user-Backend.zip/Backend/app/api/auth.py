from fastapi import APIRouter, Depends, HTTPException, status, Response, Body
from fastapi.security import HTTPBearer
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
import json
from app.db.database import get_db
from app.db.models import User
from app.schemas.user import (
    UserRegistration, UserLogin, FrontendUserRegistration, PhoneVerifiedUserRegistration
)
from app.schemas.verification import (
    PinVerificationResponse, PinVerificationRequest,
    PinResetRequest, PinResetResponse
)
from app.schemas.token import Token, RefreshTokenRequest, AccessTokenResponse
from app.schemas.common import ErrorResponse
from app.core.security import hash_password, hash_pin, verify_pin, verify_password, create_access_token
from app.services.auth_service import auth_service
from app.services.prelude_service import prelude_verification_service
from pydantic import ValidationError
import logging
from app.services.verification_cache import verification_cache
from datetime import timedelta
from app.core.config import settings
from app.schemas.user import PasswordReset
from app.utils.sanitization import sanitize_name, sanitize_email, sanitize_phone

router = APIRouter(tags=["Authentication"])
security = HTTPBearer()


@router.post("/auth/login", response_model=Token)
def login_user(user_credentials: UserLogin, db: Session = Depends(get_db)):
    """Authenticate user and return tokens"""
    user = auth_service.authenticate_user(user_credentials.username, user_credentials.password, db)
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect phone number/email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    tokens = auth_service.create_tokens_for_user(user, db)
    
    name_parts = user.full_name.split(' ', 1) if user.full_name else ['', '']
    first_name = name_parts[0] if len(name_parts) > 0 else ''
    last_name = name_parts[1] if len(name_parts) > 1 else ''
    
    return {
        "access_token": tokens["access_token"],
        "refresh_token": tokens["refresh_token"],
        "token_type": tokens["token_type"],
        "expires_in": tokens["expires_in"],
        "user": {
            "id": str(user.id),
            "phone_number": user.phone_number,
            "first_name": first_name,
            "last_name": last_name,
            "email": user.email,
            "is_verified": True,
            "has_face_registered": user.face_active,
            "is_active": True,
            "created_at": user.created_at.isoformat(),
            "updated_at": user.updated_at.isoformat()
        }
    }


@router.post("/auth/refresh", response_model=AccessTokenResponse)
def refresh_access_token(
    token_request: RefreshTokenRequest, 
    db: Session = Depends(get_db)
):
    """Refresh access token using refresh token"""
    user = auth_service.validate_refresh_token(token_request.refresh_token, db)
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired refresh token",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    access_token_expires = timedelta(minutes=settings.access_token_expire_minutes)
    access_token = create_access_token(
        data={"user_id": str(user.id), "role": "user"}, 
        expires_delta=access_token_expires
    )
    
    return AccessTokenResponse(
        access_token=access_token,
        expires_in=settings.access_token_expire_minutes * 60
    )


@router.post("/auth/logout", status_code=status.HTTP_204_NO_CONTENT)
def logout_user(
    token_request: RefreshTokenRequest,
    db: Session = Depends(get_db)
):
    """Logout user by revoking refresh token"""
    success = auth_service.revoke_refresh_token(token_request.refresh_token, db)
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid refresh token"
        )
    
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post("/auth/pin-reset", response_model=PinResetResponse)
async def reset_pin(
    pin_reset_data: PinResetRequest,
    db: Session = Depends(get_db)
):
    """Reset user PIN with phone verification and current PIN validation
    
    Required steps:
    1. Phone number verification with SMS code
    2. Current PIN verification
    3. New PIN setup
    """
    logger = logging.getLogger(__name__)
    try:
        # Step 1: Verify phone number with SMS code
        logger.info(f"PIN reset attempt for phone: {pin_reset_data.phone_number}")
        
        is_verified = await prelude_verification_service.verify_phone_code(
            pin_reset_data.phone_number, 
            pin_reset_data.verification_code
        )
        
        if not is_verified:
            logger.warning(f"Phone verification failed for PIN reset: {pin_reset_data.phone_number}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid or expired verification code"
            )
        
        # Step 2: Find user by phone number
        user = db.query(User).filter(User.phone_number == pin_reset_data.phone_number).first()
        
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found with this phone number"
            )
        
        # Step 3: Verify current PIN or set default PIN for users without one
        if not user.pin_hash:
            # User doesn't have a PIN set (registered before PIN implementation)
            # Set default PIN as last 4 digits of phone number
            phone_digits = ''.join(filter(str.isdigit, user.phone_number))
            
            if len(phone_digits) >= 4:
                default_pin = phone_digits[-4:]  # Last 4 digits
                user.pin_hash = hash_pin(default_pin)
                db.commit()
                
                logger.info(f"Set default PIN for user {user.id} during PIN reset")
                
                # Now verify against the default PIN
                if not verify_pin(pin_reset_data.current_pin, user.pin_hash):
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail=f"Current PIN is incorrect. For existing users, use the last 4 digits of your phone number ({default_pin}) as your current PIN."
                    )
            else:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Cannot extract default PIN from phone number. Please contact support."
                )
        else:
            # User has existing PIN, verify it normally
            if not verify_pin(pin_reset_data.current_pin, user.pin_hash):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Current PIN is incorrect"
                )
        
        # Step 4: Ensure new PIN is different from current PIN
        if verify_pin(pin_reset_data.new_pin, user.pin_hash):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="New PIN must be different from current PIN"
            )
        
        # Step 5: Update PIN
        user.pin_hash = hash_pin(pin_reset_data.new_pin)
        db.commit()
        
        logger.info(f"PIN reset successful for user: {user.id}")
        
        return PinResetResponse(
            success=True,
            message="PIN reset successfully"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"PIN reset error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="PIN reset failed"
        )


@router.post("/auth/register-frontend", status_code=status.HTTP_201_CREATED)
async def register_user_frontend(user_data: FrontendUserRegistration, db: Session = Depends(get_db)):
    """Register a new user (frontend compatible)
    
    Required fields:
    - first_name: User's first name
    - last_name: User's last name  
    - email: User's email address  
    - phone_number: Phone number in E.164 format (+1234567890)
    - password: Password (min 8 chars)
    - pin: 4-digit PIN for additional authentication
    - verification_code: SMS verification code
    """
    logger = logging.getLogger(__name__)
    logger.info("Frontend registration attempt")
    logger.info(f"Frontend registration attempt for phone: {user_data.phone_number}")
    logger.info(f"Verification code for {user_data.phone_number}: {user_data.verification_code}")   
    
    try:
        logger.info(f"Frontend registration attempt for phone: {user_data.phone_number}")
        logger.info(f"Verification code for {user_data.phone_number}: {user_data.verification_code}")
        # Verify the phone number with the verification code
        logger.info(f"Verifying phone code for {user_data.phone_number}")
        is_verified = await prelude_verification_service.verify_phone_code(
            user_data.phone_number, 
            user_data.verification_code
        )

        if not is_verified:
            logger.warning(f"Phone verification failed for {user_data.phone_number}")
        logger.info(f"Phone verification successful for {user_data.phone_number}")
        
        # Sanitize inputs to prevent XSS and injection attacks
        first_name = sanitize_name(user_data.first_name)
        last_name = sanitize_name(user_data.last_name)
        email = sanitize_email(user_data.email)
        phone_number = sanitize_phone(user_data.phone_number)
        
        # Hash password and PIN
        hashed_password = hash_password(user_data.password)
        hashed_pin = hash_pin(user_data.pin)
        
        # Combine first and last name for full_name
        full_name = f"{first_name} {last_name}"
        
        # Create user
        logger.info(f"Creating user in database: {email}")
        db_user = User(
            full_name=full_name,
            phone_number=phone_number,
            email=email,
            password_hash=hashed_password,
            pin_hash=hashed_pin,
            profile_info=None
        )
        
        db.add(db_user)
        db.commit()
        db.refresh(db_user)
        
        logger.info(f"User created successfully with ID: {db_user.id}")
        
        # Generate tokens for automatic login
        tokens = auth_service.create_tokens_for_user(db_user, db)
        
        logger.info(f"Tokens generated successfully for user: {db_user.id}")
        
        # Clear the specific verification from cache after successful registration
        verification_cache.invalidate(user_data.phone_number, user_data.verification_code)
        
        return {
            "access_token": tokens["access_token"],
            "refresh_token": tokens["refresh_token"],
            "token_type": tokens["token_type"],
            "expires_in": tokens["expires_in"],
            "user": {
                "id": str(db_user.id),
                "phone_number": db_user.phone_number,
                "first_name": first_name,
                "last_name": last_name,
                "email": db_user.email,
                "is_verified": True,
                "has_face_registered": db_user.face_active,
                "is_active": True,
                "created_at": db_user.created_at.isoformat(),
                "updated_at": db_user.updated_at.isoformat()
            }
        }
        
    except HTTPException:
        # Re-raise HTTP exceptions as they are
        raise
    except IntegrityError as e:
        db.rollback()
        logger.error(f"Database integrity error: {str(e)}")
        if "phone_number" in str(e.orig):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Phone number already registered"
            )
        elif "email" in str(e.orig):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Email already registered"
            )
        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Registration failed - user might already exist"
            )
    except ValidationError as e:
        logger.error(f"Validation error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Validation error: {str(e)}"
        )
    except Exception as e:
        db.rollback()
        logger.error(f"Unexpected error during registration: {str(e)}")
        logger.error(f"Error type: {type(e).__name__}")
        import traceback
        logger.error(f"Full traceback: {traceback.format_exc()}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Internal server error: {str(e)}"
        )


@router.post("/auth/forgot-password/request")
async def request_password_reset(
    phone_number: str = Body(..., embed=True),
    db: Session = Depends(get_db)
):
    """Request password reset by sending verification code to phone number"""
    try:
        # Check if user exists
        user = db.query(User).filter(User.phone_number == phone_number).first()
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="No account found with this phone number"
            )
        
        # Send verification code
        await prelude_verification_service.send_phone_verification(phone_number)
        
        return {
            "message": "Verification code sent successfully",
            "phone_number": phone_number
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@router.post("/auth/forgot-password/verify")
async def verify_password_reset(
    phone_number: str = Body(...),
    verification_code: str = Body(...),
    password_reset: PasswordReset = Body(...),
    db: Session = Depends(get_db)
):
    """Reset password after verifying phone number"""
    try:
        # Verify the code
        is_verified = await prelude_verification_service.verify_phone_code(phone_number, verification_code)
        if not is_verified:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid or expired verification code"
            )
        
        # Get user
        user = db.query(User).filter(User.phone_number == phone_number).first()
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )
        
        # Ensure the new password differs from the current one
        if user.password_hash and verify_password(password_reset.new_password, user.password_hash):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="New password must be different from the current password"
            )

        # Update password
        user.password_hash = hash_password(password_reset.new_password)
        db.commit()
        
        return {
            "message": "Password reset successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.post("/auth/verify-pin", response_model=PinVerificationResponse)
async def verify_pin_for_face_auth(
    request: PinVerificationRequest,
    db: Session = Depends(get_db)
):
    """
    Verify PIN for face authentication when multiple similar faces are detected
    
    This endpoint is called by the merchant backend when face verification
    returns multiple potential matches requiring PIN disambiguation.
    """
    logger = logging.getLogger(__name__)
    
    try:
        logger.info(f"PIN verification attempt for face_scan_id: {request.face_scan_id}")
        logger.info(f"Potential user IDs: {request.potential_user_ids}")
        
        # Validate input
        if not request.potential_user_ids:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No potential user IDs provided"
            )
        
        # Try to verify PIN against each potential user
        verified_user_id = None
        
        for user_id in request.potential_user_ids:
            try:
                user = db.query(User).filter(User.id == user_id).first()
                if not user:
                    logger.warning(f"User {user_id} not found in database")
                    continue
                
                # Check if user has a PIN set
                if not user.pin_hash:
                    logger.info(f"User {user_id} has no PIN set - setting default PIN")
                    # Set default PIN as last 4 digits of phone number
                    phone_digits = ''.join(filter(str.isdigit, user.phone_number))
                    if len(phone_digits) >= 4:
                        default_pin = phone_digits[-4:]
                        user.pin_hash = hash_pin(default_pin)
                        db.commit()
                        logger.info(f"Set default PIN for user {user_id}")
                    else:
                        logger.warning(f"Cannot extract default PIN for user {user_id}")
                        continue
                
                # Verify PIN
                if verify_pin(request.pin, user.pin_hash):
                    verified_user_id = user_id
                    logger.info(f"PIN verified successfully for user {user_id}")
                    break
                else:
                    logger.info(f"PIN verification failed for user {user_id}")
                    
            except Exception as e:
                logger.error(f"Error verifying PIN for user {user_id}: {str(e)}")
                continue
        
        if verified_user_id:
            return PinVerificationResponse(
                success=True,
                message="PIN verified successfully",
                verified_user_id=verified_user_id
            )
        else:
            return PinVerificationResponse(
                success=False,
                message="Invalid PIN or user not found",
                verified_user_id=None
            )
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"PIN verification error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="PIN verification failed"
        )

 