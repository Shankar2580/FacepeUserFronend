from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from app.db.database import get_db
from app.db.models import User, PaymentMethod
from app.schemas.payment import (
    PaymentMethodCreate, PaymentMethodUpdate, PaymentMethodResponse, PaymentMethodCreateSecure
)
from app.dependencies import get_current_user
from app.services.stripe_service import stripe_service
import logging
import stripe
from app.core.config import settings

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(tags=["Payment Methods"])


@router.post("/users/me/payment-methods/setup-intent")
def create_setup_intent(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Create a Setup Intent for saving a new payment method"""
    try:
        logger.info(f"Creating Setup Intent for user {current_user.id}")
        
        # Get or create Stripe customer
        customer_id = stripe_service.get_or_create_customer(current_user, db)
        if not customer_id:
            logger.error(f"Failed to create Stripe customer for user {current_user.id}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to create Stripe customer"
            )
        
        logger.info(f"Stripe customer ID: {customer_id}")
        
        # Create Setup Intent
        setup_intent = stripe_service.create_setup_intent(
            customer_id=customer_id,
            metadata={"user_id": str(current_user.id)}
        )
        
        if not setup_intent:
            logger.error(f"Failed to create Setup Intent for customer {customer_id}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to create Setup Intent"
            )
        
        logger.info(f"Setup Intent created successfully: {setup_intent['id']}")
        
        return {
            "client_secret": setup_intent["client_secret"],
            "setup_intent_id": setup_intent["id"]
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error creating Setup Intent: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create Setup Intent: {str(e)}"
        )


@router.post("/users/me/payment-methods/confirm-setup-intent/{setup_intent_id}")
def confirm_setup_intent_and_save_card(
    setup_intent_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Confirm Setup Intent and save the payment method"""
    try:
        logger.info(f"Confirming Setup Intent {setup_intent_id} for user {current_user.id}")
        
        # Confirm Setup Intent
        result = stripe_service.confirm_setup_intent(setup_intent_id)
        
        if not result:
            logger.error(f"Setup Intent {setup_intent_id} not found or failed to retrieve")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Setup Intent {setup_intent_id} not found. This may be due to: 1) Invalid Setup Intent ID, 2) Setup Intent expired, 3) Test/Live mode mismatch, or 4) Wrong Stripe account"
            )
        
        if result["status"] != "succeeded":
            logger.error(f"Setup Intent {setup_intent_id} not succeeded. Status: {result.get('status')}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Setup Intent confirmation failed. Status: {result.get('status')}"
            )
        
        payment_method_id = result["payment_method"]
        logger.info(f"Payment method ID from Setup Intent: {payment_method_id}")
        
        # Get payment method details from Stripe
        pm_details = stripe_service.get_payment_method_details(payment_method_id)
        
        if not pm_details:
            logger.error(f"Failed to retrieve payment method details for {payment_method_id}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve payment method details"
            )
        
        # Check if this is the first payment method (make it default)
        existing_count = db.query(PaymentMethod).filter(
            PaymentMethod.user_id == current_user.id
        ).count()
        
        is_default = existing_count == 0
        logger.info(f"Setting payment method as default: {is_default}")
        
        # If setting as default, unset other default payment methods
        if is_default:
            db.query(PaymentMethod).filter(
                PaymentMethod.user_id == current_user.id,
                PaymentMethod.is_default == True
            ).update({"is_default": False})
        
        # Create payment method record
        db_payment_method = PaymentMethod(
            user_id=current_user.id,
            stripe_payment_method_id=payment_method_id,
            last4=pm_details["last4"],
            brand=pm_details["brand"],
            exp_month=pm_details["exp_month"],
            exp_year=pm_details["exp_year"],
            is_default=is_default
        )
        
        db.add(db_payment_method)
        db.commit()
        db.refresh(db_payment_method)
        
        logger.info(f"Payment method saved successfully with ID: {db_payment_method.id}")
        
        return {
            "success": True,
            "payment_method": db_payment_method
        }
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"Unexpected error confirming Setup Intent: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to save payment method: {str(e)}"
        )


@router.get("/users/me/payment-methods", response_model=List[PaymentMethodResponse])
def get_user_payment_methods(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get all payment methods for the current user"""
    payment_methods = db.query(PaymentMethod).filter(
        PaymentMethod.user_id == current_user.id
    ).order_by(PaymentMethod.is_default.desc(), PaymentMethod.created_at.desc()).all()
    
    # Map database fields to frontend-expected field names
    response_data = []
    for pm in payment_methods:
        response_data.append({
            "id": pm.id,
            "card_last_four": pm.last4,
            "card_brand": pm.brand,
            "card_exp_month": pm.exp_month,
            "card_exp_year": pm.exp_year,
            "is_default": pm.is_default,
            "created_at": pm.created_at
        })
    
    return response_data


@router.post("/users/me/payment-methods/secure", response_model=PaymentMethodResponse, status_code=status.HTTP_201_CREATED)
def add_payment_method_secure(
    payment_method_data: PaymentMethodCreateSecure,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Add a new payment method for the current user (SECURE VERSION)
    Frontend sends only Stripe payment method ID, backend fetches details from Stripe
    """
    try:
        logger.info(f"Adding payment method for user {current_user.id}")
        
        # Check if Stripe is configured
        if not settings.stripe_secret_key or not settings.stripe_secret_key.strip():
            logger.error("Stripe secret key is not configured")
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Payment service is not configured. Please contact administrator."
            )
        
        # Extract and validate the Stripe payment method ID
        stripe_payment_method_id = payment_method_data.stripe_payment_method_id
        is_default = payment_method_data.is_default or False
        
        if not stripe_payment_method_id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="stripe_payment_method_id is required"
            )
        
        # Get or create Stripe customer
        customer_id = stripe_service.get_or_create_customer(current_user, db)
        if not customer_id:
            logger.error(f"Failed to create Stripe customer for user {current_user.id}")
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Payment service is temporarily unavailable. Please try again later."
            )
        
        # Attach payment method to customer
        success = stripe_service.attach_payment_method(
            stripe_payment_method_id,
            customer_id
        )
        
        if not success:
            logger.error(f"Failed to attach payment method {stripe_payment_method_id} to customer {customer_id}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Failed to process payment method. Please try again."
            )
        
        # Get payment method details from Stripe (this is secure - we fetch from Stripe, not trust frontend)
        pm_details = stripe_service.get_payment_method_details(stripe_payment_method_id)
        
        if not pm_details:
            logger.error(f"Failed to retrieve payment method details for {stripe_payment_method_id}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to retrieve payment method details from payment service"
            )
        
        # If no existing payment methods, make this one default
        existing_count = db.query(PaymentMethod).filter(
            PaymentMethod.user_id == current_user.id
        ).count()
        
        if existing_count == 0:
            is_default = True
        
        # If this is set as default, unset other default payment methods
        if is_default:
            db.query(PaymentMethod).filter(
                PaymentMethod.user_id == current_user.id,
                PaymentMethod.is_default == True
            ).update({"is_default": False})
            
            # Also update Stripe customer's default payment method
            try:
                stripe.Customer.modify(
                    customer_id,
                    invoice_settings={"default_payment_method": stripe_payment_method_id}
                )
                logger.info(f"Updated default payment method for Stripe customer {customer_id}")
            except Exception as e:
                logger.warning(f"Failed to update default payment method in Stripe: {str(e)}")
        
        # Create payment method record with data from Stripe (secure)
        db_payment_method = PaymentMethod(
            user_id=current_user.id,
            stripe_payment_method_id=stripe_payment_method_id,
            last4=pm_details["last4"],
            brand=pm_details["brand"],
            exp_month=pm_details["exp_month"],
            exp_year=pm_details["exp_year"],
            is_default=is_default
        )
        
        db.add(db_payment_method)
        db.commit()
        db.refresh(db_payment_method)
        
        logger.info(f"Payment method added successfully with ID: {db_payment_method.id}")
        
        # Return response with frontend-expected field names
        return {
            "id": db_payment_method.id,
            "card_last_four": db_payment_method.last4,
            "card_brand": db_payment_method.brand,
            "card_exp_month": db_payment_method.exp_month,
            "card_exp_year": db_payment_method.exp_year,
            "is_default": db_payment_method.is_default,
            "created_at": db_payment_method.created_at
        }
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"Unexpected error adding payment method: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to add payment method: {str(e)}"
        )


@router.put("/users/me/payment-methods/{payment_method_id}", response_model=PaymentMethodResponse)
def set_default_payment_method(
    payment_method_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Set a payment method as default for the current user"""
    logger.info(f"Setting default payment method {payment_method_id} for user {current_user.id}")
    
    # Find the payment method
    payment_method = db.query(PaymentMethod).filter(
        PaymentMethod.id == payment_method_id,
        PaymentMethod.user_id == current_user.id
    ).first()
    
    if not payment_method:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Payment method not found"
        )
    
    try:
        # Unset other default payment methods
        db.query(PaymentMethod).filter(
            PaymentMethod.user_id == current_user.id,
            PaymentMethod.is_default == True
        ).update({"is_default": False})
        
        # Set this payment method as default
        payment_method.is_default = True
        
        # Update timestamp
        from sqlalchemy.sql import func
        payment_method.updated_at = func.now()
        
        # Also update Stripe customer's default payment method
        try:
            customer_id = stripe_service.get_or_create_customer(current_user, db)
            if customer_id:
                stripe.Customer.modify(
                    customer_id,
                    invoice_settings={"default_payment_method": payment_method.stripe_payment_method_id}
                )
                logger.info(f"Updated default payment method for Stripe customer {customer_id}")
        except Exception as e:
            logger.warning(f"Failed to update default payment method in Stripe: {str(e)}")
        
        db.commit()
        db.refresh(payment_method)
        
        # Return response with frontend-expected field names
        return {
            "id": payment_method.id,
            "card_last_four": payment_method.last4,
            "card_brand": payment_method.brand,
            "card_exp_month": payment_method.exp_month,
            "card_exp_year": payment_method.exp_year,
            "is_default": payment_method.is_default,
            "created_at": payment_method.created_at
        }
        
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to set default payment method"
        )


@router.delete("/users/me/payment-methods", status_code=status.HTTP_204_NO_CONTENT)
def delete_payment_method(
    payment_method_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Delete a payment method for the current user"""
    # Find the payment method
    payment_method = db.query(PaymentMethod).filter(
        PaymentMethod.id == payment_method_id,
        PaymentMethod.user_id == current_user.id
    ).first()
    
    if not payment_method:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Payment method not found"
        )
    
    try:
        # Detach from Stripe
        stripe_service.detach_payment_method(payment_method.stripe_payment_method_id)
        
        # Delete from database
        db.delete(payment_method)
        db.commit()
        
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete payment method"
        ) 