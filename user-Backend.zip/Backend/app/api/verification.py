from fastapi import APIRouter, HTTPException, status
from app.schemas.verification import (
    PhoneVerificationRequest, EmailVerificationRequest, 
    VerificationCodeRequest, EmailVerificationCodeRequest, 
    VerificationResponse
)
from app.services.prelude_service import prelude_verification_service
import logging

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Verification"])


@router.post("/verification/send-phone-code", response_model=VerificationResponse)
async def send_phone_verification_code(request: PhoneVerificationRequest):
    """Send SMS verification code to phone number using Prelude.so"""
    try:
        success = await prelude_verification_service.send_phone_verification(request.phone_number)
        
        if success:
            return VerificationResponse(
                success=True,
                message=f"Verification code sent to {request.phone_number}"
            )
        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Failed to send verification code. Please check the phone number."
            )

    except HTTPException:
        # Preserve the intended HTTP error status codes
        raise
    except Exception as e:
        logger.error(f"Error sending phone verification: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while sending verification code"
        )


@router.post("/verification/verify-phone-code", response_model=VerificationResponse)
async def verify_phone_code(request: VerificationCodeRequest):
    """Verify SMS code for phone number using Prelude.so"""
    try:
        success = await prelude_verification_service.verify_phone_code(
            request.phone_number, 
            request.code
        )
        
        if success:
            return VerificationResponse(
                success=True,
                message="Phone number verified successfully"
            )
        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid or expired verification code"
            )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error verifying phone code: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while verifying code"
        )


@router.post("/verification/send-email-code", response_model=VerificationResponse)
async def send_email_verification_code(request: EmailVerificationRequest):
    """Send email verification code (placeholder - Prelude.so focuses on SMS)"""
    try:
        success = await prelude_verification_service.send_email_verification(request.email)
        
        if success:
            return VerificationResponse(
                success=True,
                message=f"Verification code sent to {request.email}"
            )
        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Failed to send verification code. Please check the email address."
            )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error sending email verification: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while sending verification code"
        )


@router.post("/verification/verify-email-code", response_model=VerificationResponse)
async def verify_email_code(request: EmailVerificationCodeRequest):
    """Verify email code (placeholder implementation)"""
    try:
        success = await prelude_verification_service.verify_email_code(
            request.email, 
            request.code
        )
        
        if success:
            return VerificationResponse(
                success=True,
                message="Email verified successfully"
            )
        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid or expired verification code"
            )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error verifying email code: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while verifying code"
        ) 