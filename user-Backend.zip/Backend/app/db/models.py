import uuid
from sqlalchemy import Column, String, Boolean, Integer, BigInteger, Text, TIMESTAMP, ForeignKey, Index, UniqueConstraint
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from .database import Base


class User(Base):
    __tablename__ = "users"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    full_name = Column(String(100), nullable=False)  # User's full name
    phone_number = Column(String(16), unique=True, nullable=False, index=True)
    email = Column(Text, unique=True, nullable=False)  # Email is now required
    password_hash = Column(Text, nullable=False)
    pin_hash = Column(Text, nullable=True)  # 4-digit PIN hash for additional authentication
    profile_info = Column(Text, nullable=True)  # JSON as text for SQLite (legacy)
    
    # Face-enrollment columns (keeping as requested)
    face_id = Column(String(36), nullable=True)
    face_active = Column(Boolean, nullable=False, default=False)
    face_created_at = Column(TIMESTAMP, nullable=True)
    
    # Stripe customer ID
    stripe_customer_id = Column(Text, nullable=True)

    # Cooldown for name changes
    name_last_updated_at = Column(TIMESTAMP, nullable=True)

    # Soft delete fields
    deletion_requested_at = Column(TIMESTAMP, nullable=True)
    deletion_effective_at = Column(TIMESTAMP, nullable=True)
    deleted_at = Column(TIMESTAMP, nullable=True)
    
    created_at = Column(TIMESTAMP, nullable=False, default=func.now())
    updated_at = Column(TIMESTAMP, nullable=False, default=func.now(), onupdate=func.now())
    
    # Relationships
    payment_methods = relationship("PaymentMethod", back_populates="user", cascade="all, delete-orphan")
    auto_pay_approvals = relationship("AutoPayApproval", back_populates="user", cascade="all, delete-orphan")
    auto_pays = relationship("AutoPay", back_populates="user", cascade="all, delete-orphan")
    incoming_payment_requests = relationship("IncomingPaymentRequest", back_populates="user", cascade="all, delete-orphan")
    transactions = relationship("Transaction", back_populates="user", cascade="all, delete-orphan")

    __table_args__ = (
        Index('idx_users_face_active', 'face_active'),
        Index('idx_users_deletion_due', 'deletion_effective_at', 'deleted_at'),
    )


class PaymentMethod(Base):
    __tablename__ = "paymentmethods"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    stripe_payment_method_id = Column(Text, nullable=False)
    last4 = Column(String(4), nullable=False)
    brand = Column(Text, nullable=False)
    exp_month = Column(Integer, nullable=False)
    exp_year = Column(Integer, nullable=False)
    is_default = Column(Boolean, nullable=False, default=False)
    created_at = Column(TIMESTAMP, nullable=False, default=func.now())
    updated_at = Column(TIMESTAMP, nullable=False, default=func.now(), onupdate=func.now())
    
    # Relationships
    user = relationship("User", back_populates="payment_methods")
    transactions = relationship("Transaction", back_populates="payment_method")

    __table_args__ = (
        Index('idx_paymentmethods_user_default', 'user_id', 'is_default'),
    )


class AutoPayApproval(Base):
    __tablename__ = "autopayapprovals"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    merchant_id = Column(String(36), nullable=False)
    limit_amount = Column(BigInteger, nullable=False)  # in cents
    created_at = Column(TIMESTAMP, nullable=False, default=func.now())
    updated_at = Column(TIMESTAMP, nullable=False, default=func.now(), onupdate=func.now())
    
    # Relationships
    user = relationship("User", back_populates="auto_pay_approvals")

    __table_args__ = (
        UniqueConstraint('user_id', 'merchant_id'),
    )


class AutoPay(Base):
    __tablename__ = "autopay"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    merchant_id = Column(String(36), nullable=False)
    merchant_name = Column(Text, nullable=False)
    is_enabled = Column(Boolean, nullable=False, default=True)
    max_amount = Column(BigInteger, nullable=True)  # in cents, optional limit
    payment_method_id = Column(String(36), ForeignKey("paymentmethods.id"), nullable=False)
    created_at = Column(TIMESTAMP, nullable=False, default=func.now())
    updated_at = Column(TIMESTAMP, nullable=False, default=func.now(), onupdate=func.now())
    
    # Relationships
    user = relationship("User", back_populates="auto_pays")
    payment_method = relationship("PaymentMethod")

    __table_args__ = (
        UniqueConstraint('user_id', 'merchant_id'),
        Index('idx_autopay_user_enabled', 'user_id', 'is_enabled'),
    )


class IncomingPaymentRequest(Base):
    __tablename__ = "incomingpaymentrequests"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    merchant_id = Column(String(36), nullable=False)
    merchant_payment_request_id = Column(String(36), nullable=True)  # Store merchant's original payment request ID
    business_name = Column(Text, nullable=True)  # Store merchant's business name
    amount = Column(BigInteger, nullable=False)  # in cents
    currency = Column(String(3), nullable=False)  # e.g. "USD"
    description = Column(Text, nullable=True)
    face_scan_id = Column(String(36), nullable=False)
    is_auto_paid = Column(Boolean, nullable=False, default=False)
    status = Column(Text, nullable=False)  # 'PENDING', 'COMPLETED', 'FAILED'
    stripe_payment_intent_id = Column(Text, nullable=True)
    created_at = Column(TIMESTAMP, nullable=False, default=func.now())
    updated_at = Column(TIMESTAMP, nullable=False, default=func.now(), onupdate=func.now())
    
    # Relationships
    user = relationship("User", back_populates="incoming_payment_requests")

    __table_args__ = (
        Index('idx_incoming_requests_user_status', 'user_id', 'status'),
    )


class Transaction(Base):
    __tablename__ = "transactions"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    merchant_id = Column(String(36), nullable=False)
    merchant_name = Column(Text, nullable=False)
    amount = Column(BigInteger, nullable=False)  # in cents
    currency = Column(String(3), nullable=False)  # e.g. "USD"
    description = Column(Text, nullable=True)
    timestamp = Column(TIMESTAMP, nullable=False, default=func.now())
    status = Column(Text, nullable=False)  # 'SUCCEEDED' or 'FAILED'
    payment_method_id = Column(String(36), ForeignKey("paymentmethods.id"), nullable=True)
    stripe_transaction_id = Column(Text, nullable=True)  # e.g. Charge or PaymentIntent ID
    is_auto_paid = Column(Boolean, nullable=False, default=False)
    
    # Relationships
    user = relationship("User", back_populates="transactions")
    payment_method = relationship("PaymentMethod", back_populates="transactions")

    __table_args__ = (
        Index('idx_transactions_user_time', 'user_id', 'timestamp'),
    )


# Refresh token model for JWT token management
class RefreshToken(Base):
    __tablename__ = "refresh_tokens"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    token = Column(Text, nullable=False, unique=True)
    expires_at = Column(TIMESTAMP, nullable=False)
    is_revoked = Column(Boolean, nullable=False, default=False)
    created_at = Column(TIMESTAMP, nullable=False, default=func.now())
    
    # Relationships
    user = relationship("User") 