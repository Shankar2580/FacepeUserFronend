"""
Rate Limiting Configuration for Customer Backend API

This module provides rate limiting to protect against abuse while ensuring
normal users have a smooth experience.

Rate Limit Strategy:
- Stricter limits on security-sensitive endpoints (auth, payments)
- Generous limits on general endpoints
- IP-based limiting with fallback to user-based for authenticated requests
"""

from slowapi import Limiter
from slowapi.util import get_remote_address
from fastapi import Request
import logging

logger = logging.getLogger(__name__)


def get_identifier(request: Request) -> str:
    """
    Get identifier for rate limiting.
    Uses IP address as primary identifier.
    For authenticated requests, could be extended to use user_id.
    """
    # Get IP address
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        # Get the first IP in the chain (original client)
        ip = forwarded.split(",")[0].strip()
    else:
        ip = get_remote_address(request)
    
    return ip


# Initialize rate limiter
limiter = Limiter(
    key_func=get_identifier,
    default_limits=["1000/hour"],  # Very generous default - normal users won't hit this
    storage_uri="memory://",  # In-memory storage (simple, no Redis needed)
    headers_enabled=True,  # Add rate limit headers to responses
)


# Rate limit configurations for different endpoint types
# These are designed to be invisible to normal users but stop attackers

# Authentication endpoints - Stricter due to security sensitivity
AUTH_RATE_LIMITS = [
    "5/minute",    # Max 5 login attempts per minute
    "20/hour",     # Max 20 login attempts per hour
]

# Registration endpoints - Prevent mass account creation
REGISTRATION_RATE_LIMITS = [
    "3/minute",    # Max 3 registration attempts per minute
    "10/hour",     # Max 10 registrations per hour per IP
]

# Verification/OTP endpoints - Very strict to prevent SMS spam
VERIFICATION_RATE_LIMITS = [
    "3/minute",    # Max 3 OTP requests per minute
    "10/hour",     # Max 10 OTP requests per hour
]

# Payment endpoints - Strict to prevent fraud
PAYMENT_RATE_LIMITS = [
    "10/minute",   # Max 10 payment operations per minute
    "100/hour",    # Max 100 payment operations per hour
]

# Payment method management - Moderate limits
PAYMENT_METHOD_RATE_LIMITS = [
    "20/minute",   # Max 20 operations per minute
    "200/hour",    # Max 200 operations per hour
]

# Transaction/History endpoints - Generous (read-only)
READ_RATE_LIMITS = [
    "60/minute",   # Max 60 reads per minute
    "500/hour",    # Max 500 reads per hour
]

# Face registration - Moderate (resource intensive)
FACE_REGISTRATION_RATE_LIMITS = [
    "5/minute",    # Max 5 face operations per minute
    "30/hour",     # Max 30 face operations per hour
]

# General API endpoints - Very generous
GENERAL_RATE_LIMITS = [
    "100/minute",  # Max 100 requests per minute
    "1000/hour",   # Max 1000 requests per hour
]


def get_rate_limit_message(endpoint_type: str) -> str:
    """Get user-friendly rate limit message"""
    messages = {
        "auth": "Too many login attempts. Please try again in a few minutes.",
        "registration": "Too many registration attempts. Please try again later.",
        "verification": "Too many verification requests. Please wait before requesting another code.",
        "payment": "Too many payment requests. Please wait a moment before trying again.",
        "face": "Too many face registration attempts. Please try again in a few minutes.",
        "general": "Too many requests. Please slow down and try again shortly."
    }
    return messages.get(endpoint_type, messages["general"])
