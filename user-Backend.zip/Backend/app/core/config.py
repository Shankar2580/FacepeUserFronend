import os
from pydantic_settings import BaseSettings
from typing import List, Optional
from functools import lru_cache
from pydantic import Field, field_validator


class Settings(BaseSettings):
    # Database - Using SQLite for local development, PostgreSQL for production
    database_url: str = Field(default="", env="DATABASE_URL")
    test_database_url: Optional[str] = None
    
    # Expo Push Notifications
    expo_push_url: str = Field(default="", env="EXPO_PUSH_URL")

    # JWT Configuration  
    secret_key: str = Field(default="", env="SECRET_KEY")
    algorithm: str = Field(default="HS256", env="ALGORITHM")
    access_token_expire_minutes: int = Field(default=30, env="ACCESS_TOKEN_EXPIRE_MINUTES")
    refresh_token_expire_days: int = Field(default=10, env="REFRESH_TOKEN_EXPIRE_DAYS")
    
    # Stripe Configuration
    stripe_secret_key: str = Field(default="", env="STRIPE_SECRET_KEY")
    stripe_publishable_key: str = Field(default="", env="STRIPE_PUBLISHABLE_KEY")
    stripe_webhook_secret: str = Field(default="", env="STRIPE_WEBHOOK_SECRET")
    
    # Webhook Security Configuration
    # Hardcoded for in-cluster communication - NOT using Field() to prevent env override
    merchant_webhook_secret: str = 'M9q3iQm1h7F6bYv2wN8cK4rX1pT5zL0dS3uV9yH2eG86'
    merchant_webhook_url: str = 'http://merchant-backend.dev.svc.cluster.local/mb/webhooks/payment-status'
    stripe_receipt_url: str ="https://dashboard.stripe.com/payments/"
    
    # Stripe Connect Configuration (merchants send their own Connect account IDs dynamically)
    stripe_application_fee_percent: float = Field(default=2.9, env="STRIPE_APPLICATION_FEE_PERCENT")
    stripe_application_fee_fixed: int = Field(default=30, env="STRIPE_APPLICATION_FEE_FIXED")
    
    # Prelude.so Configuration (SMS Verification)
    prelude_api_key: str = Field(default="", env="PRELUDE_API_KEY")
    
    # Face Recognition service URL
    face_api_url: str = Field(default="http://localhost:8001")
    
    # Application Configuration
    app_name: str = "Customer Payment API"
    app_version: str = "1.0.0"
    debug: bool = False  # Disable debug mode for production
    cors_origins: List[str] = ["http://localhost:3000", "http://localhost:8080", "http://localhost:19006"]
    

    
    # Development/Testing Configuration
    verification_dev_mode: bool = Field(default=False, env="VERIFICATION_DEV_MODE")  # Disable dev mode
    development_mode: bool = Field(default=False, env="DEVELOPMENT_MODE")  # Development mode for testing
    
    # Logging Configuration
    log_level: str = Field(default="INFO", env="LOG_LEVEL")
    
    # Force hardcoded webhook values to prevent env override
    @field_validator('merchant_webhook_secret', mode='before')
    @classmethod
    def force_webhook_secret(cls, v):
        return 'M9q3iQm1h7F6bYv2wN8cK4rX1pT5zL0dS3uV9yH2eG86'
    
    @field_validator('merchant_webhook_url', mode='before')
    @classmethod
    def force_webhook_url(cls, v):
        return 'http://merchant-backend.dev.svc.cluster.local/mb/webhooks/payment-status'
    
    # Prelude Configuration Helper
    @property
    def is_development(self) -> bool:
        """Check if we're in development/testing mode"""
        return self.debug or self.development_mode or self.verification_dev_mode
    
    class Config:
        env_file = ".env"
        case_sensitive = False
        extra = "ignore"  # Ignore extra environment variables (like old Twilio config)


@lru_cache()
def get_settings() -> Settings:
    return Settings()


# Global settings instance
settings = get_settings() 