"""
Rate Limit Decorators for Easy Application to Endpoints

This module provides convenient decorators to apply rate limits to specific endpoints.
Import these decorators and apply them to your route handlers.

Example Usage:
    from app.core.rate_limit_decorators import auth_rate_limit, payment_rate_limit
    
    @router.post("/auth/login")
    @auth_rate_limit
    async def login(credentials: LoginCredentials):
        # Your login logic here
        pass
"""

from functools import wraps
from app.core.rate_limit import (
    limiter,
    AUTH_RATE_LIMITS,
    REGISTRATION_RATE_LIMITS,
    VERIFICATION_RATE_LIMITS,
    PAYMENT_RATE_LIMITS,
    PAYMENT_METHOD_RATE_LIMITS,
    READ_RATE_LIMITS,
    FACE_REGISTRATION_RATE_LIMITS,
    GENERAL_RATE_LIMITS
)


# Decorator for authentication endpoints
def auth_rate_limit(func):
    """Apply rate limit to authentication endpoints (login, token refresh)"""
    return limiter.limit(AUTH_RATE_LIMITS)(func)


# Decorator for registration endpoints
def registration_rate_limit(func):
    """Apply rate limit to registration endpoints"""
    return limiter.limit(REGISTRATION_RATE_LIMITS)(func)


# Decorator for verification/OTP endpoints
def verification_rate_limit(func):
    """Apply rate limit to verification/OTP endpoints"""
    return limiter.limit(VERIFICATION_RATE_LIMITS)(func)


# Decorator for payment processing endpoints
def payment_rate_limit(func):
    """Apply rate limit to payment processing endpoints"""
    return limiter.limit(PAYMENT_RATE_LIMITS)(func)


# Decorator for payment method management endpoints
def payment_method_rate_limit(func):
    """Apply rate limit to payment method management endpoints"""
    return limiter.limit(PAYMENT_METHOD_RATE_LIMITS)(func)


# Decorator for read-only endpoints (transactions, history)
def read_rate_limit(func):
    """Apply rate limit to read-only endpoints"""
    return limiter.limit(READ_RATE_LIMITS)(func)


# Decorator for face registration endpoints
def face_rate_limit(func):
    """Apply rate limit to face registration endpoints"""
    return limiter.limit(FACE_REGISTRATION_RATE_LIMITS)(func)


# Decorator for general endpoints
def general_rate_limit(func):
    """Apply rate limit to general endpoints"""
    return limiter.limit(GENERAL_RATE_LIMITS)(func)
